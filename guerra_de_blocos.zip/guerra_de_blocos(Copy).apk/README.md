# Guerra de Blocos 3D (Godot 4)

Jogo de guerra 3D em blocos voxel, feito inteiramente em GDScript, sem assets externos
(texturas e sons são gerados por código). Modo offline e multiplayer (ENet).

**Versão testada: Godot 4.3 (stable)**. Abra a pasta no Godot (Importar → `project.godot`) e aperte F5.
Renderizador: Compatibility (OpenGL), escolhido por rodar em celulares modestos.

## Controles
| Ação | Teclado/mouse | Toque |
|---|---|---|
| Mover / olhar | WASD / mouse | joystick esquerdo / arrastar a tela |
| Atirar / usar ferramenta | botão esquerdo | FOGO |
| Recolher bloco (martelo) | botão direito | ALT |
| Pular / recarregar | Espaço / R | PULO / RECAR |
| Trocar arma | 1-4 / roda do mouse | toque na barra / ARMA |
| Material / forma de construção | C / V | MAT / FORMA |
| Entrar/sair de veículo | E (perto do veículo) | USAR |
| Placar / inventário / pausa | Tab / I / Esc | PLACAR / INV / II |

## O que existe
- **Mundo**: chunks 16³ com malha única (ArrayMesh) só com faces visíveis; 3 mapas gerados por seed
  (Cidade Abandonada, Campo de Batalha, Terreno Montanhoso) com bases, 3 pontos de captura, prédios com
  andares/escadas, árvores, trincheiras, crateras, barricadas, ponte e torres.
- **Destruição**: dano por bloco (resistência por material), explosões esféricas, desabamento de estruturas
  que perdem a ligação com o chão, fragmentos e partículas com limite por qualidade.
- **Colisão por demanda**: só os chunks perto de jogadores/veículos têm colisão (trimesh); refeita quando o chunk muda.
- **Construção**: martelo com formas Bloco / Parede / Ponte / Barricada, 7 materiais, inventário, limite de 150 blocos
  por jogador (ilimitado no Sandbox), recolher devolve material.
- **Combate**: 4 classes, 7 equipamentos fictícios (fuzil, pistola, escopeta, metralhadora, lança-foguetes,
  picareta, martelo), vida, respawn, abates, placar, bots com IA simples.
- **Veículos**: Jipe, Caminhão (6 lugares) e Tanque (canhão que destrói blocos); entrar/sair, passageiros.
- **Modos**: Guerra de Equipes, Captura de Território (pontos + bases), Sobrevivência (ondas), Sandbox, Treinamento.
- **Multiplayer**: host/cliente por IP e porta (padrão 24680), `MultiplayerSpawner` para jogadores e veículos,
  `MultiplayerSynchronizer` para estado, entrada com a partida em andamento (o cliente recebe o mapa e todas as
  alterações de blocos já feitas).
- **UI**: menu, seleção de modo/mapa/equipe/classe, HUD, minimapa, placar, inventário, pausa, configurações.

## Estrutura
```
scenes/   main_menu.tscn · maps/game.tscn · player/ · vehicles/ · weapons/ · ui/
scripts/  autoload/ (Settings, Sfx, Game) · voxel/ · combat/ · player/ · vehicles/ · multiplayer/ · ui/
assets/   textures/ models/ sounds/ materials/ shaders/  (vazios: tudo é procedural; ponto de extensão)
tests/    testes automatizados (ver abaixo)
```
Os mapas são definidos em `scripts/voxel/TerrainGen.gd` (não há um `.tscn` por mapa). Para criar um mapa novo,
adicione uma função de geração e uma entrada em `TerrainGen.MAPS`.

## Testes
`tests/run_all.sh /caminho/do/godot` roda: geração dos mapas, integração offline (5 modos), lógica dos modos,
e multiplayer real com dois processos (host + cliente em localhost).

## Limitações conhecidas
- Não foi testado em aparelho Android real; a otimização (colisão por demanda, culling de chunks, limites de
  partículas, qualidade Baixa no primeiro uso em celular) é por projeto, sem medição em hardware.
- Servidor autoritativo para dano, vida, blocos, construção, pontuação e assentos. O **movimento** é do cliente
  (replicado ao servidor), e a **munição** é contada no cliente.
- Multiplayer testado só em localhost (sem NAT/internet). Para jogar pela internet é preciso liberar a porta UDP.
- Reconstrução de malhas roda na thread principal (explosões grandes podem causar pequenos travamentos em aparelhos fracos).
- O minimapa é um retrato do terreno no início da partida (não mostra destruição); não há rachaduras visuais nos blocos.
- Sem LOD de malha: usa descarte por distância. Sons são sintetizados (simples).
