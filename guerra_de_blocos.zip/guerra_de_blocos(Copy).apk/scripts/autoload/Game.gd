extends Node
## Estado global: configuração da partida escolhida nos menus, dados de equipes,
## classes e armas, e troca de cenas.

const TEAM_NAMES := ["Vermelhos", "Azuis"]
const TEAM_COLORS := [Color(0.9, 0.22, 0.2), Color(0.22, 0.45, 0.95)]

const MODES := {
	"team_war": {"name": "Guerra de Equipes", "desc": "Primeira equipe a atingir 30 abates vence."},
	"capture": {"name": "Captura de Território", "desc": "Domine os pontos de captura. 150 pontos vencem."},
	"survival": {"name": "Sobrevivência", "desc": "Ondas de inimigos. Sobreviva o máximo que puder."},
	"sandbox": {"name": "Sandbox", "desc": "Sem inimigos. Construa e destrua livremente."},
	"training": {"name": "Treinamento", "desc": "Alvos de treino e bots parados para testar armas."},
}

## Classes de personagem. `weapons` são ids de WeaponDB.
const CLASSES := {
	"soldier": {"name": "Soldado", "hp": 100.0, "speed": 7.0, "weapons": ["rifle", "pistol", "pickaxe", "builder"]},
	"engineer": {"name": "Engenheiro", "hp": 90.0, "speed": 7.0, "weapons": ["shotgun", "pistol", "pickaxe", "builder"]},
	"heavy": {"name": "Pesado", "hp": 150.0, "speed": 5.5, "weapons": ["launcher", "pistol", "pickaxe", "builder"]},
	"scout": {"name": "Batedor", "hp": 70.0, "speed": 8.8, "weapons": ["smg", "pistol", "pickaxe", "builder"]},
}
const CLASS_IDS := ["soldier", "engineer", "heavy", "scout"]

# Configuração da partida atual
var mode := "team_war"
var map_id := "city"
var seed_value := 1234
var my_team := 0
var my_class := "soldier"
var bots_per_team := 3
var build_limit := 150          # máximo de blocos construídos por jogador
var in_match := false


func _ready() -> void:
	bots_per_team = Settings.bots_per_team


func start_match() -> void:
	seed_value = randi()
	in_match = true
	if Net.online and multiplayer.is_server():
		Net.start_for_all()
	get_tree().change_scene_to_file("res://scenes/maps/game.tscn")


func to_menu() -> void:
	in_match = false
	Net.go_offline()
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
