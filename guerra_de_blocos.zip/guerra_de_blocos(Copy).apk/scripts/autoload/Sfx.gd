extends Node
## Sons gerados proceduralmente (sem arquivos de áudio externos).

const RATE := 22050

var _streams := {}
var _pool2d: Array[AudioStreamPlayer] = []
var _pool3d: Array[AudioStreamPlayer3D] = []
var _i2 := 0
var _i3 := 0


func _ready() -> void:
	_streams["shoot"] = _make(0.10, 700.0, 0.8)
	_streams["shotgun"] = _make(0.22, 300.0, 0.9)
	_streams["rocket"] = _make(0.30, 160.0, 0.6)
	_streams["explosion"] = _make(0.80, 60.0, 0.85)
	_streams["hit"] = _make(0.06, 1200.0, 0.2)
	_streams["break"] = _make(0.14, 220.0, 0.9)
	_streams["place"] = _make(0.07, 420.0, 0.3)
	_streams["jump"] = _make(0.08, 500.0, 0.1)
	_streams["engine"] = _make(0.12, 90.0, 0.4)
	_streams["capture"] = _make(0.30, 880.0, 0.0)
	for i in 8:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_pool2d.append(p)
		var p3 := AudioStreamPlayer3D.new()
		p3.unit_size = 12.0
		p3.max_distance = 90.0
		add_child(p3)
		_pool3d.append(p3)


func _make(duration: float, freq: float, noise: float) -> AudioStreamWAV:
	var n := int(duration * RATE)
	var data := PackedByteArray()
	data.resize(n * 2)
	var rng := RandomNumberGenerator.new()
	rng.seed = int(freq * 31.0) + n
	for i in n:
		var t := float(i) / RATE
		var k := t / duration
		var env := pow(1.0 - k, 2.0)
		var tone := sin(TAU * freq * t * (1.0 - k * 0.5))
		var s := (rng.randf() * 2.0 - 1.0) * noise + tone * (1.0 - noise)
		data.encode_s16(i * 2, int(clampf(s * env, -1.0, 1.0) * 26000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = data
	return w


## Toca um som. Se `pos` for informado, o som é posicional (3D).
func play(sound: String, pos: Vector3 = Vector3.INF) -> void:
	if not _streams.has(sound) or _pool2d.is_empty():
		return
	if pos == Vector3.INF:
		var p := _pool2d[_i2]
		_i2 = (_i2 + 1) % _pool2d.size()
		p.stream = _streams[sound]
		p.play()
	else:
		var p3 := _pool3d[_i3]
		_i3 = (_i3 + 1) % _pool3d.size()
		p3.stream = _streams[sound]
		p3.global_position = pos
		p3.play()
