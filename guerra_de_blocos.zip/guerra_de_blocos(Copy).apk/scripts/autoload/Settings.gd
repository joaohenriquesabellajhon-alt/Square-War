extends Node
## Configurações do jogador (salvas em user://settings.cfg) e mapa de entradas.

signal changed

const PATH := "user://settings.cfg"

var player_name := "Jogador"
var quality := 1            # 0 baixa, 1 média, 2 alta
var shadows := true
var view_distance := 96.0   # distância (em blocos) em que chunks são desenhados
var max_particles := 80     # limite de partículas simultâneas
var sensitivity := 0.25
var invert_y := false
var volume := 0.8
var touch_controls := false
var show_fps := false
var bots_per_team := 3


func _ready() -> void:
	touch_controls = DisplayServer.is_touchscreen_available() or OS.has_feature("mobile")
	_register_inputs()
	if not FileAccess.file_exists(PATH) and OS.has_feature("mobile"):
		set_quality(0)   # primeira execução no celular: qualidade baixa
	load_settings()
	apply()


func set_quality(q: int) -> void:
	quality = clampi(q, 0, 2)
	match quality:
		0:
			shadows = false
			view_distance = 64.0
			max_particles = 30
		1:
			shadows = true
			view_distance = 96.0
			max_particles = 80
		2:
			shadows = true
			view_distance = 150.0
			max_particles = 200


func apply() -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(volume, 0.0001)))
	Engine.max_fps = 60
	get_viewport().msaa_3d = Viewport.MSAA_2X if quality == 2 else Viewport.MSAA_DISABLED
	changed.emit()


func save_settings() -> void:
	var cfg := ConfigFile.new()
	for key in ["player_name", "quality", "shadows", "view_distance", "max_particles",
			"sensitivity", "invert_y", "volume", "touch_controls", "show_fps", "bots_per_team"]:
		cfg.set_value("settings", key, get(key))
	cfg.save(PATH)


func load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	for key in ["player_name", "quality", "shadows", "view_distance", "max_particles",
			"sensitivity", "invert_y", "volume", "touch_controls", "show_fps", "bots_per_team"]:
		if cfg.has_section_key("settings", key):
			set(key, cfg.get_value("settings", key))


func _add_key(action: StringName, key: Key) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var ev := InputEventKey.new()
	ev.physical_keycode = key
	InputMap.action_add_event(action, ev)


func _add_mouse(action: StringName, button: MouseButton) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var ev := InputEventMouseButton.new()
	ev.button_index = button
	InputMap.action_add_event(action, ev)


func _register_inputs() -> void:
	_add_key(&"move_forward", KEY_W)
	_add_key(&"move_back", KEY_S)
	_add_key(&"move_left", KEY_A)
	_add_key(&"move_right", KEY_D)
	_add_key(&"jump", KEY_SPACE)
	_add_key(&"reload", KEY_R)
	_add_key(&"interact", KEY_E)
	_add_key(&"scoreboard", KEY_TAB)
	_add_key(&"inventory", KEY_I)
	_add_key(&"pause", KEY_ESCAPE)
	_add_key(&"build_mode", KEY_B)
	_add_key(&"next_material", KEY_C)
	_add_key(&"next_shape", KEY_V)
	if not OS.has_feature("mobile"):
		# No celular, o toque emula o mouse; por isso o tiro vem só dos botões de toque.
		_add_mouse(&"fire", MOUSE_BUTTON_LEFT)
		_add_mouse(&"alt_fire", MOUSE_BUTTON_RIGHT)
	else:
		_add_key(&"fire", KEY_F)
		_add_key(&"alt_fire", KEY_G)
	var slot_keys := [KEY_1, KEY_2, KEY_3, KEY_4, KEY_5, KEY_6]
	for i in slot_keys.size():
		_add_key(StringName("slot_%d" % (i + 1)), slot_keys[i])
