class_name VoxelWorld
extends Node3D
## Mundo voxel dividido em chunks. Contém acesso a blocos, raycast (DDA),
## reconstrução de malhas sob demanda, dano de blocos e detecção de desabamento.

signal block_changed(pos: Vector3i, id: int)
signal collapsed(positions: Array)

const DIRS6: Array[Vector3i] = [
	Vector3i(1, 0, 0), Vector3i(-1, 0, 0), Vector3i(0, 1, 0),
	Vector3i(0, -1, 0), Vector3i(0, 0, 1), Vector3i(0, 0, -1),
]
const SUPPORT_LIMIT := 700

var size_chunks := Vector3i(8, 3, 8)
var chunks := {}            # Vector3i -> Chunk
var dirty := {}             # Vector3i -> true
var material: StandardMaterial3D
var damage := {}            # Vector3i -> vida restante do bloco
var edits := {}             # Vector3i -> id (registro de alterações; usado pelo servidor)
var heightmap := PackedInt32Array()
var map_info := {}          # preenchido pelo TerrainGen (bases, pontos, spawns)
var rebuild_budget := 2
var _vis_timer := 0.0
var _col_timer := 0.0
const COLLISION_RADIUS := 34.0


func init_world(p_size_chunks: Vector3i) -> void:
	size_chunks = p_size_chunks
	material = Blocks.make_material()
	for cy in size_chunks.y:
		for cz in size_chunks.z:
			for cx in size_chunks.x:
				var c := Chunk.new()
				add_child(c)
				c.setup(self, Vector3i(cx, cy, cz))
				chunks[Vector3i(cx, cy, cz)] = c
	heightmap.resize(size_blocks().x * size_blocks().z)
	heightmap.fill(0)


func size_blocks() -> Vector3i:
	return size_chunks * Chunk.SIZE


func in_bounds(p: Vector3i) -> bool:
	var s := size_blocks()
	return p.x >= 0 and p.y >= 0 and p.z >= 0 and p.x < s.x and p.y < s.y and p.z < s.z


func get_block(p: Vector3i) -> int:
	if p.y < 0:
		return Blocks.BEDROCK
	var c: Chunk = chunks.get(Vector3i(p.x >> 4, p.y >> 4, p.z >> 4))
	if c == null:
		return Blocks.AIR
	return c.data[(p.x & 15) + (p.z & 15) * 16 + (p.y & 15) * 256]


## Altera um bloco sem marcar chunks como sujos (uso na geração do terreno).
func set_block_raw(p: Vector3i, id: int) -> void:
	var c: Chunk = chunks.get(Vector3i(p.x >> 4, p.y >> 4, p.z >> 4))
	if c == null:
		return
	c.data[(p.x & 15) + (p.z & 15) * 16 + (p.y & 15) * 256] = id


func set_block(p: Vector3i, id: int, emit := true) -> bool:
	var cp := Vector3i(p.x >> 4, p.y >> 4, p.z >> 4)
	var c: Chunk = chunks.get(cp)
	if c == null:
		return false
	var lx := p.x & 15
	var ly := p.y & 15
	var lz := p.z & 15
	var i := lx + lz * 16 + ly * 256
	if c.data[i] == id:
		return false
	c.data[i] = id
	damage.erase(p)
	dirty[cp] = true
	if lx == 0: dirty[cp + Vector3i(-1, 0, 0)] = true
	if lx == 15: dirty[cp + Vector3i(1, 0, 0)] = true
	if ly == 0: dirty[cp + Vector3i(0, -1, 0)] = true
	if ly == 15: dirty[cp + Vector3i(0, 1, 0)] = true
	if lz == 0: dirty[cp + Vector3i(0, 0, -1)] = true
	if lz == 15: dirty[cp + Vector3i(0, 0, 1)] = true
	if emit:
		block_changed.emit(p, id)
	return true


func build_all() -> void:
	for cp in chunks:
		(chunks[cp] as Chunk).build()
	dirty.clear()


func _process(delta: float) -> void:
	var n := 0
	for cp in dirty.keys():
		dirty.erase(cp)
		var c: Chunk = chunks.get(cp)
		if c != null:
			c.build()
			n += 1
			if n >= rebuild_budget:
				break
	_vis_timer -= delta
	if _vis_timer <= 0.0:
		_vis_timer = 0.4
		update_visibility()
	_col_timer -= delta
	if _col_timer <= 0.0:
		_col_timer = 0.25
		update_collisions()


## Ativa a colisão apenas dos chunks perto de nós do grupo "focus" (jogadores,
## veículos, projéteis relevantes). Isso evita milhares de triângulos de física.
func update_collisions() -> void:
	var foci: Array[Vector3] = []
	for n in get_tree().get_nodes_in_group("focus"):
		if n is Node3D and (n as Node3D).is_inside_tree():
			foci.append((n as Node3D).global_position)
	for cp in chunks:
		var c: Chunk = chunks[cp]
		var center := c.position + Vector3.ONE * 8.0
		var need := false
		for f in foci:
			if center.distance_to(f) < COLLISION_RADIUS:
				need = true
				break
		c.set_collision(need)


## Chunk em `pos` está com a colisão pronta? (usado para segurar jogadores no spawn)
func collision_ready_at(pos: Vector3) -> bool:
	var cp := Vector3i(floori(pos.x) >> 4, floori(pos.y) >> 4, floori(pos.z) >> 4)
	var c: Chunk = chunks.get(cp)
	if c == null:
		return true
	return c.collision_ready()


## Distance culling: esconde malhas de chunks distantes (colisão permanece).
func update_visibility() -> void:
	var cam := get_viewport().get_camera_3d()
	if cam == null:
		return
	var cpos := cam.global_position
	var maxd := Settings.view_distance + 12.0
	for cp in chunks:
		var c: Chunk = chunks[cp]
		var center := c.position + Vector3.ONE * 8.0
		c.visible = (not c.empty) and center.distance_to(cpos) < maxd


## Raycast por voxels (Amanatides & Woo). Retorna {} se nada for atingido.
func raycast(origin: Vector3, dir: Vector3, max_dist: float) -> Dictionary:
	var d := dir.normalized()
	var p := Vector3i(floori(origin.x), floori(origin.y), floori(origin.z))
	var step := Vector3i(1 if d.x > 0.0 else -1, 1 if d.y > 0.0 else -1, 1 if d.z > 0.0 else -1)
	var tdelta := Vector3(INF, INF, INF)
	var tmax := Vector3(INF, INF, INF)
	for a in 3:
		if d[a] != 0.0:
			tdelta[a] = absf(1.0 / d[a])
			var boundary := float(p[a] + (1 if step[a] > 0 else 0))
			tmax[a] = (boundary - origin[a]) / d[a]
	var normal := Vector3i.ZERO
	var t := 0.0
	if get_block(p) != Blocks.AIR:
		return {"pos": p, "normal": Vector3i.ZERO, "id": get_block(p), "dist": 0.0}
	while true:
		var axis := 0
		if tmax.x <= tmax.y and tmax.x <= tmax.z:
			axis = 0
		elif tmax.y <= tmax.z:
			axis = 1
		else:
			axis = 2
		t = tmax[axis]
		if t > max_dist:
			break
		p[axis] += step[axis]
		tmax[axis] += tdelta[axis]
		normal = Vector3i.ZERO
		normal[axis] = -step[axis]
		var id := get_block(p)
		if id != Blocks.AIR:
			return {"pos": p, "normal": normal, "id": id, "dist": t}
	return {}


## Aplica dano a um bloco. Retorna true se ele deve ser destruído.
func damage_block(p: Vector3i, amount: float) -> bool:
	var id := get_block(p)
	if not Blocks.is_destructible(id):
		return false
	var cur: float = damage.get(p, float(Blocks.HP[id]))
	cur -= amount
	if cur <= 0.0:
		damage.erase(p)
		return true
	damage[p] = cur
	return false


## Dado um conjunto de blocos removidos, devolve blocos vizinhos que ficaram
## sem ligação com o terreno (desabam). Componentes grandes são considerados estáveis.
func find_unsupported(removed: Array) -> Array:
	var result: Array = []
	var seen := {}
	for r in removed:
		for d in DIRS6:
			var s: Vector3i = r + d
			if seen.has(s) or get_block(s) == Blocks.AIR:
				continue
			var comp := _flood(s, seen)
			result.append_array(comp)
	return result


func _flood(start: Vector3i, seen: Dictionary) -> Array:
	var local := {start: true}
	var queue: Array[Vector3i] = [start]
	var head := 0
	var anchored := false
	while head < queue.size():
		var p: Vector3i = queue[head]
		head += 1
		var id := get_block(p)
		if p.y <= 0 or Blocks.is_natural(id):
			anchored = true
			break
		if queue.size() > SUPPORT_LIMIT:
			anchored = true
			break
		for d in DIRS6:
			var q: Vector3i = p + d
			if local.has(q) or seen.has(q):
				continue
			if get_block(q) == Blocks.AIR:
				continue
			local[q] = true
			queue.append(q)
	for k in local:
		seen[k] = true
	if anchored:
		return []
	return queue


## Altura do terreno (y do bloco mais alto) em uma coluna.
func ground_height(x: int, z: int) -> int:
	var s := size_blocks()
	x = clampi(x, 0, s.x - 1)
	z = clampi(z, 0, s.z - 1)
	return heightmap[x + z * s.x]


## Primeira posição livre (y do ar) acima do bloco sólido mais alto da coluna.
func find_ground(x: int, z: int) -> float:
	var s := size_blocks()
	x = clampi(x, 0, s.x - 1)
	z = clampi(z, 0, s.z - 1)
	for y in range(s.y - 1, -1, -1):
		if get_block(Vector3i(x, y, z)) != Blocks.AIR:
			return float(y + 1)
	return 1.0


func clear_all_damage() -> void:
	damage.clear()
