class_name Structures
extends RefCounted
## Construtores de estruturas voxel (casas, torres, pontes, bases...).
## Convenção: `o.y` é o Y do último bloco sólido do terreno; a estrutura começa em o.y.


static func fill(w: VoxelWorld, a: Vector3i, b: Vector3i, id: int) -> void:
	for y in range(mini(a.y, b.y), maxi(a.y, b.y) + 1):
		for z in range(mini(a.z, b.z), maxi(a.z, b.z) + 1):
			for x in range(mini(a.x, b.x), maxi(a.x, b.x) + 1):
				w.set_block_raw(Vector3i(x, y, z), id)


## Remove blocos em uma esfera. Se `keep_natural`, preserva terreno.
static func carve(w: VoxelWorld, c: Vector3, r: float, keep_natural := false) -> void:
	var ri := int(ceil(r))
	for dy in range(-ri, ri + 1):
		for dz in range(-ri, ri + 1):
			for dx in range(-ri, ri + 1):
				if dx * dx + dy * dy + dz * dz > r * r:
					continue
				var p := Vector3i(int(c.x) + dx, int(c.y) + dy, int(c.z) + dz)
				if p.y < 1:
					continue
				var id := w.get_block(p)
				if id == Blocks.AIR or id == Blocks.BEDROCK:
					continue
				if keep_natural and Blocks.is_natural(id):
					continue
				w.set_block_raw(p, Blocks.AIR)


static func building(w: VoxelWorld, o: Vector3i, sx: int, sz: int, floors: int,
		wall_id: int, floor_id: int, rng: RandomNumberGenerator, ruin: float) -> void:
	var fh := 4
	var h := floors * fh
	fill(w, Vector3i(o.x, maxi(o.y - 6, 1), o.z), o + Vector3i(sx - 1, -1, sz - 1), Blocks.STONE)
	fill(w, o, o + Vector3i(sx - 1, 0, sz - 1), floor_id)
	fill(w, o + Vector3i(0, 1, 0), o + Vector3i(sx - 1, h, sz - 1), Blocks.AIR)
	for y in range(1, h + 1):
		for x in sx:
			w.set_block_raw(o + Vector3i(x, y, 0), wall_id)
			w.set_block_raw(o + Vector3i(x, y, sz - 1), wall_id)
		for z in sz:
			w.set_block_raw(o + Vector3i(0, y, z), wall_id)
			w.set_block_raw(o + Vector3i(sx - 1, y, z), wall_id)
	var has_stairs := sx >= 6 and sz >= 8
	for k in range(1, floors + 1):
		for z in sz:
			for x in sx:
				var in_hole := has_stairs and k <= floors - 1 and x >= 1 and x <= 2 and z >= 1 and z <= 3
				if not in_hole:
					w.set_block_raw(o + Vector3i(x, k * fh, z), floor_id)
	if has_stairs:
		for k in range(0, floors - 1):
			for i in 3:
				var p := o + Vector3i(1, k * fh + 1 + i, 1 + i)
				w.set_block_raw(p, floor_id)
				w.set_block_raw(p + Vector3i(1, 0, 0), floor_id)
	# porta e janelas
	var dx := sx / 2
	for y in range(1, 3):
		w.set_block_raw(o + Vector3i(dx, y, 0), Blocks.AIR)
		w.set_block_raw(o + Vector3i(dx - 1, y, 0), Blocks.AIR)
	for k in floors:
		var wy := k * fh + 2
		if wy + 1 > h:
			continue
		var x := 2
		while x < sx - 2:
			w.set_block_raw(o + Vector3i(x, wy + 1, sz - 1), Blocks.AIR)
			if x % 3 == 0:
				w.set_block_raw(o + Vector3i(x, wy + 1, 0), Blocks.AIR)
			x += 3
		var z := 2
		while z < sz - 2:
			w.set_block_raw(o + Vector3i(0, wy + 1, z), Blocks.AIR)
			w.set_block_raw(o + Vector3i(sx - 1, wy + 1, z), Blocks.AIR)
			z += 3
	# ruínas
	var holes := int(ruin * 24.0)
	for i in holes:
		var c := Vector3(o) + Vector3(rng.randf() * sx, 2.0 + rng.randf() * (h - 1), rng.randf() * sz)
		carve(w, c, rng.randf_range(1.2, 2.6), true)


static func tree(w: VoxelWorld, base: Vector3i, rng: RandomNumberGenerator) -> void:
	var th := rng.randi_range(4, 6)
	for y in range(1, th + 1):
		w.set_block_raw(base + Vector3i(0, y, 0), Blocks.WOOD)
	var top := base + Vector3i(0, th, 0)
	for dy in range(-1, 3):
		for dz in range(-2, 3):
			for dx in range(-2, 3):
				var d2 := dx * dx + dz * dz + (dy - 1) * (dy - 1)
				if d2 > 5 or (d2 == 5 and rng.randf() < 0.5):
					continue
				var p := top + Vector3i(dx, dy, dz)
				if w.get_block(p) == Blocks.AIR:
					w.set_block_raw(p, Blocks.LEAVES)


static func pine(w: VoxelWorld, base: Vector3i, rng: RandomNumberGenerator) -> void:
	var th := rng.randi_range(6, 9)
	for y in range(1, th + 1):
		w.set_block_raw(base + Vector3i(0, y, 0), Blocks.WOOD)
	var r := 3
	var y := 3
	while y <= th + 1:
		for dz in range(-r, r + 1):
			for dx in range(-r, r + 1):
				if absi(dx) + absi(dz) <= r + (1 if r > 1 else 0) and w.get_block(base + Vector3i(dx, y, dz)) == Blocks.AIR:
					w.set_block_raw(base + Vector3i(dx, y, dz), Blocks.LEAVES)
		if y % 2 == 0:
			r = maxi(r - 1, 0)
		y += 1


static func wall(w: VoxelWorld, a: Vector3i, b: Vector3i, h: int, id: int) -> void:
	fill(w, a + Vector3i(0, 1, 0), b + Vector3i(0, h, 0), id)


static func ramp(w: VoxelWorld, start: Vector3i, dir: Vector3i, steps: int, wdir: Vector3i, width: int, id: int) -> void:
	for i in steps + 1:
		for k in width:
			var p := start + dir * i + wdir * k
			fill(w, p, p + Vector3i(0, i, 0), id)


static func tower(w: VoxelWorld, o: Vector3i, h: int, id: int, floor_id: int, side := 1) -> void:
	fill(w, Vector3i(o.x, maxi(o.y - 6, 1), o.z), o + Vector3i(4, -1, 4), Blocks.STONE)
	fill(w, o + Vector3i(0, 1, 0), o + Vector3i(4, h, 4), Blocks.AIR)
	for y in range(1, h + 1):
		for i in 5:
			w.set_block_raw(o + Vector3i(i, y, 0), id)
			w.set_block_raw(o + Vector3i(i, y, 4), id)
			w.set_block_raw(o + Vector3i(0, y, i), id)
			w.set_block_raw(o + Vector3i(4, y, i), id)
	fill(w, o + Vector3i(0, h, 0), o + Vector3i(4, h, 4), floor_id)
	for i in 5:
		for p in [Vector3i(i, h + 1, 0), Vector3i(i, h + 1, 4), Vector3i(0, h + 1, i), Vector3i(4, h + 1, i)]:
			w.set_block_raw(o + p, id)
	var edge_x := 4 if side > 0 else 0
	for z in range(3, 5):
		w.set_block_raw(o + Vector3i(edge_x, h + 1, z), Blocks.AIR)
	if side > 0:
		ramp(w, o + Vector3i(5, 0, 4 + h), Vector3i(0, 0, -1), h, Vector3i(1, 0, 0), 2, floor_id)
	else:
		ramp(w, o + Vector3i(-1, 0, 4 + h), Vector3i(0, 0, -1), h, Vector3i(-1, 0, 0), 2, floor_id)
	w.set_block_raw(o + Vector3i(edge_x, 1, 2), Blocks.AIR)
	w.set_block_raw(o + Vector3i(edge_x, 2, 2), Blocks.AIR)


static func bridge(w: VoxelWorld, a: Vector3i, b: Vector3i, width: int, id: int, rail_id: int) -> void:
	var along_x := a.z == b.z
	var lo := mini(a.x, b.x) if along_x else mini(a.z, b.z)
	var hi := maxi(a.x, b.x) if along_x else maxi(a.z, b.z)
	for t in range(lo, hi + 1):
		for k in width:
			var p := Vector3i(t, a.y, a.z + k) if along_x else Vector3i(a.x + k, a.y, t)
			w.set_block_raw(p, id)
			if k == 0 or k == width - 1:
				w.set_block_raw(p + Vector3i(0, 1, 0), rail_id)


static func barricade(w: VoxelWorld, o: Vector3i, length: int, along_x: bool, id: int) -> void:
	for i in length:
		var p := o + (Vector3i(i, 0, 0) if along_x else Vector3i(0, 0, i))
		p.y = w.ground_height(p.x, p.z)
		if w.get_block(p + Vector3i(0, 1, 0)) != Blocks.AIR:
			continue
		w.set_block_raw(p + Vector3i(0, 1, 0), id)
		w.set_block_raw(p + Vector3i(0, 2, 0), id if i % 3 != 1 else Blocks.AIR)


## Base de equipe. `c.y` = topo do terreno já aplainado. Retorna pontos de spawn.
static func base(w: VoxelWorld, c: Vector3i, team: int) -> Array:
	var team_id := Blocks.RED if team == 0 else Blocks.BLUE
	fill(w, c + Vector3i(-7, 0, -7), c + Vector3i(7, 0, 7), Blocks.CONCRETE)
	for i in range(-7, 8):
		for p in [Vector3i(i, 0, -7), Vector3i(i, 0, 7), Vector3i(-7, 0, i), Vector3i(7, 0, i)]:
			w.set_block_raw(c + p, team_id)
	fill(w, c + Vector3i(-7, 1, -7), c + Vector3i(7, 3, 7), Blocks.AIR)
	for i in range(-7, 8):
		if absi(i) <= 1:
			continue
		for y in range(1, 4):
			for p in [Vector3i(i, y, -7), Vector3i(i, y, 7), Vector3i(-7, y, i), Vector3i(7, y, i)]:
				w.set_block_raw(c + p, Blocks.BRICK if y < 3 else team_id)
	fill(w, c + Vector3i(0, 1, 0), c + Vector3i(0, 9, 0), Blocks.METAL)
	fill(w, c + Vector3i(1, 7, 0), c + Vector3i(3, 9, 0), team_id)
	for sx in [-1, 1]:
		for sz in [-1, 1]:
			tower(w, c + Vector3i(sx * 10 - 2, 0, sz * 10 - 2), 6, Blocks.CONCRETE, Blocks.PLANK, sx)
	var spawns: Array = []
	for p in [Vector3i(-4, 1, -4), Vector3i(4, 1, -4), Vector3i(-4, 1, 4), Vector3i(4, 1, 4),
			Vector3i(0, 1, -4), Vector3i(0, 1, 4), Vector3i(-4, 1, 0), Vector3i(4, 1, 0)]:
		spawns.append(Vector3(c + p) + Vector3(0.5, 0.0, 0.5))
	return spawns


static func capture_platform(w: VoxelWorld, c: Vector3i) -> void:
	for dz in range(-5, 6):
		for dx in range(-5, 6):
			if dx * dx + dz * dz > 30:
				continue
			var ring := dx * dx + dz * dz > 20
			w.set_block_raw(c + Vector3i(dx, 0, dz), Blocks.STONE if ring else Blocks.CONCRETE)
			for y in range(1, 4):
				w.set_block_raw(c + Vector3i(dx, y, dz), Blocks.AIR)
	fill(w, c + Vector3i(0, 1, 0), c + Vector3i(0, 4, 0), Blocks.METAL)
	for p in [Vector3i(4, 1, 0), Vector3i(-4, 1, 0), Vector3i(0, 1, 4), Vector3i(0, 1, -4)]:
		w.set_block_raw(c + p, Blocks.PLANK)
		w.set_block_raw(c + p + Vector3i(0, 1, 0), Blocks.PLANK)
