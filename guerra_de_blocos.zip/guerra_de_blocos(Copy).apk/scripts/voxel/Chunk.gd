class_name Chunk
extends MeshInstance3D
## Um chunk 16x16x16 de blocos. Gera uma única ArrayMesh (apenas faces visíveis)
## e um único colisor (trimesh) para todo o chunk.

const SIZE := 16
const VOL := SIZE * SIZE * SIZE

# Vértices de cada face (ordem horária vista de fora = face frontal na Godot).
const FACE_DIRS := [
	Vector3i(0, 1, 0), Vector3i(0, -1, 0), Vector3i(1, 0, 0),
	Vector3i(-1, 0, 0), Vector3i(0, 0, 1), Vector3i(0, 0, -1),
]
const FACE_VERTS := [
	[Vector3(0, 1, 0), Vector3(1, 1, 0), Vector3(1, 1, 1), Vector3(0, 1, 1)],  # topo
	[Vector3(0, 0, 1), Vector3(1, 0, 1), Vector3(1, 0, 0), Vector3(0, 0, 0)],  # base
	[Vector3(1, 1, 1), Vector3(1, 1, 0), Vector3(1, 0, 0), Vector3(1, 0, 1)],  # +X
	[Vector3(0, 1, 0), Vector3(0, 1, 1), Vector3(0, 0, 1), Vector3(0, 0, 0)],  # -X
	[Vector3(0, 1, 1), Vector3(1, 1, 1), Vector3(1, 0, 1), Vector3(0, 0, 1)],  # +Z
	[Vector3(1, 1, 0), Vector3(0, 1, 0), Vector3(0, 0, 0), Vector3(1, 0, 0)],  # -Z
]
const FACE_SHADE := [1.0, 0.55, 0.82, 0.82, 0.7, 0.7]
const FACE_KIND := [0, 1, 2, 2, 2, 2]

var cpos := Vector3i.ZERO
var data := PackedByteArray()
var world: Node
var body: StaticBody3D
var shape_node: CollisionShape3D
var empty := true
var has_collision := false   # colisão só existe perto de jogadores/veículos


func setup(p_world: Node, p_cpos: Vector3i) -> void:
	world = p_world
	cpos = p_cpos
	data.resize(VOL)
	data.fill(0)
	position = Vector3(p_cpos * SIZE)
	body = StaticBody3D.new()
	shape_node = CollisionShape3D.new()
	body.add_child(shape_node)
	add_child(body)
	cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON


static func idx(x: int, y: int, z: int) -> int:
	return x + z * SIZE + y * SIZE * SIZE


func recompute_empty() -> void:
	empty = true
	for i in VOL:
		if data[i] != 0:
			empty = false
			return


func build() -> void:
	recompute_empty()
	if empty:
		mesh = null
		shape_node.shape = null
		has_collision = false
		return
	var verts := PackedVector3Array()
	var normals := PackedVector3Array()
	var colors := PackedColorArray()
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()
	var origin := cpos * SIZE
	for y in SIZE:
		for z in SIZE:
			for x in SIZE:
				var id: int = data[x + z * SIZE + y * SIZE * SIZE]
				if id == 0:
					continue
				for f in 6:
					var d: Vector3i = FACE_DIRS[f]
					var nx := x + d.x
					var ny := y + d.y
					var nz := z + d.z
					var nid: int
					if nx >= 0 and nx < SIZE and ny >= 0 and ny < SIZE and nz >= 0 and nz < SIZE:
						nid = data[nx + nz * SIZE + ny * SIZE * SIZE]
					else:
						nid = world.get_block(origin + Vector3i(nx, ny, nz))
					if nid != 0:
						continue
					_add_face(f, id, Vector3(x, y, z), verts, normals, colors, uvs, indices)
	if verts.is_empty():
		mesh = null
		shape_node.shape = null
		has_collision = false
		return
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_COLOR] = colors
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	var am := ArrayMesh.new()
	am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	am.surface_set_material(0, world.material)
	mesh = am
	# Colisão é gerada sob demanda (ver set_collision); se já estava ativa, atualiza.
	if has_collision:
		shape_node.shape = am.create_trimesh_shape()


## Liga/desliga a colisão do chunk. Desligada = sem custo de física e sem memória.
func set_collision(on: bool) -> void:
	if on == has_collision and (not on or shape_node.shape != null):
		return
	if on and mesh != null:
		shape_node.shape = (mesh as ArrayMesh).create_trimesh_shape()
		has_collision = true
	elif not on:
		shape_node.shape = null
		has_collision = false
	else:
		has_collision = true  # chunk vazio: nada a colidir


## Verdadeiro quando o chunk não precisa de colisão ou ela já está pronta.
func collision_ready() -> bool:
	return mesh == null or shape_node.shape != null


func _add_face(f: int, id: int, o: Vector3, verts: PackedVector3Array, normals: PackedVector3Array,
		colors: PackedColorArray, uvs: PackedVector2Array, indices: PackedInt32Array) -> void:
	var base := verts.size()
	var n := Vector3(FACE_DIRS[f])
	var tile := Blocks.tile_for(id, FACE_KIND[f])
	var shade: float = FACE_SHADE[f]
	var col := Color(shade, shade, shade, 1.0)
	var fv: Array = FACE_VERTS[f]
	for i in 4:
		var v: Vector3 = fv[i]
		verts.append(o + v)
		normals.append(n)
		colors.append(col)
		var u: float
		var w: float
		if f < 2:
			u = v.x
			w = v.z
		elif f < 4:
			u = v.z
			w = 1.0 - v.y
		else:
			u = v.x
			w = 1.0 - v.y
		uvs.append(Vector2((float(tile) + 0.03 + u * 0.94) / 16.0, 0.03 + w * 0.94))
	indices.append(base)
	indices.append(base + 1)
	indices.append(base + 2)
	indices.append(base)
	indices.append(base + 2)
	indices.append(base + 3)
