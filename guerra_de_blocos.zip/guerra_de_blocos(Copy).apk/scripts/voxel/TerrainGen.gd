class_name TerrainGen
extends RefCounted
## Gerador de terreno e dos três mapas. Totalmente determinístico a partir da seed,
## então servidor e clientes geram o mesmo mundo e só as alterações trafegam pela rede.

const MAP_IDS := ["city", "battlefield", "mountain"]
const MAPS := {
	"city": {"name": "Cidade Abandonada", "chunks": Vector3i(8, 3, 8),
		"desc": "Ruas, prédios em ruínas com andares e escadas. Combate urbano a curta distância."},
	"battlefield": {"name": "Campo de Batalha", "chunks": Vector3i(9, 3, 9),
		"desc": "Colinas, trincheiras, crateras e bunkers. Campo aberto com cobertura."},
	"mountain": {"name": "Terreno Montanhoso", "chunks": Vector3i(8, 4, 8),
		"desc": "Picos, mesas conectadas por ponte e vales. Muito desnível."},
}


static func generate(w: VoxelWorld, map_id: String, seed_value: int) -> void:
	var def: Dictionary = MAPS[map_id]
	w.init_world(def["chunks"])
	w.map_info = {"map_id": map_id, "bases": [], "points": [], "spawns": {0: [], 1: []}, "vehicles": []}
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value
	var noise := FastNoiseLite.new()
	noise.seed = seed_value
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	match map_id:
		"city":
			_city(w, rng, noise)
		"battlefield":
			_battlefield(w, rng, noise)
		_:
			_mountain(w, rng, noise)
	w.build_all()


# ---------------------------------------------------------------- utilidades

static func _fill_terrain(w: VoxelWorld, height_fn: Callable, snow_y: int, rock_y: int, sand_y: int) -> void:
	var s := w.size_blocks()
	for z in s.z:
		for x in s.x:
			var h := clampi(int(height_fn.call(x, z)), 3, s.y - 12)
			w.heightmap[x + z * s.x] = h
			w.set_block_raw(Vector3i(x, 0, z), Blocks.BEDROCK)
			for y in range(1, h - 3):
				w.set_block_raw(Vector3i(x, y, z), Blocks.STONE)
			for y in range(maxi(1, h - 3), h):
				w.set_block_raw(Vector3i(x, y, z), Blocks.STONE if h >= rock_y else Blocks.DIRT)
			var top := Blocks.GRASS
			if h >= snow_y:
				top = Blocks.SNOW
			elif h >= rock_y:
				top = Blocks.STONE
			elif h <= sand_y:
				top = Blocks.SAND
			w.set_block_raw(Vector3i(x, h, z), top)


static func flatten(w: VoxelWorld, cx: int, cz: int, r: int, y: int,
		top_id := Blocks.GRASS, fill_id := Blocks.DIRT) -> void:
	var s := w.size_blocks()
	for z in range(maxi(cz - r, 0), mini(cz + r + 1, s.z)):
		for x in range(maxi(cx - r, 0), mini(cx + r + 1, s.x)):
			var h := w.heightmap[x + z * s.x]
			if h > y:
				for yy in range(y + 1, h + 1):
					w.set_block_raw(Vector3i(x, yy, z), Blocks.AIR)
			elif h < y:
				for yy in range(h + 1, y):
					w.set_block_raw(Vector3i(x, yy, z), fill_id)
			w.set_block_raw(Vector3i(x, y, z), top_id)
			w.heightmap[x + z * s.x] = y


static func _excluded(x: int, z: int, sx: int, sz: int, ex: Array) -> bool:
	for e in ex:
		var cx := clampf(e.x, x, x + sx)
		var cz := clampf(e.y, z, z + sz)
		if Vector2(cx, cz).distance_to(Vector2(e.x, e.y)) < e.z:
			return true
	return false


static func _add_base(w: VoxelWorld, team: int, x: int, z: int, y: int) -> void:
	flatten(w, x, z, 14, y)
	var spawns := Structures.base(w, Vector3i(x, y, z), team)
	w.map_info["bases"].append({"team": team, "pos": Vector3(x + 0.5, y + 1.0, z + 0.5)})
	w.map_info["spawns"][team] = spawns


static func _add_point(w: VoxelWorld, x: int, z: int, y: int, fill_id := Blocks.DIRT) -> void:
	flatten(w, x, z, 7, y, Blocks.CONCRETE, fill_id)
	Structures.capture_platform(w, Vector3i(x, y, z))
	w.map_info["points"].append(Vector3(x + 0.5, y + 1.0, z + 0.5))


static func _veh(w: VoxelWorld, kind: String, x: int, z: int, yaw: float) -> void:
	w.map_info["vehicles"].append({"kind": kind, "pos": Vector3(x + 0.5, w.find_ground(x, z) + 1.2, z + 0.5), "yaw": yaw})


static func _trees(w: VoxelWorld, rng: RandomNumberGenerator, count: int, ex: Array, pines := false) -> void:
	var s := w.size_blocks()
	for i in count:
		var x := rng.randi_range(3, s.x - 4)
		var z := rng.randi_range(3, s.z - 4)
		if _excluded(x, z, 1, 1, ex):
			continue
		var h := w.ground_height(x, z)
		if w.get_block(Vector3i(x, h, z)) != Blocks.GRASS or w.get_block(Vector3i(x, h + 1, z)) != Blocks.AIR:
			continue
		if pines:
			Structures.pine(w, Vector3i(x, h, z), rng)
		else:
			Structures.tree(w, Vector3i(x, h, z), rng)


# ---------------------------------------------------------------- cidade

static func _city(w: VoxelWorld, rng: RandomNumberGenerator, noise: FastNoiseLite) -> void:
	noise.frequency = 0.03
	var s := w.size_blocks()
	_fill_terrain(w, func(x, z): return 10 + int(round(noise.get_noise_2d(x, z) * 1.6)), 999, 999, 0)
	for z in s.z:
		for x in s.x:
			var rx := x % 32
			var rz := z % 32
			if (rx >= 13 and rx <= 18) or (rz >= 13 and rz <= 18):
				var h := w.heightmap[x + z * s.x]
				var stripe := (rx == 15 or rx == 16) and rz % 4 < 2 and not (rz >= 13 and rz <= 18)
				w.set_block_raw(Vector3i(x, h, z), Blocks.STONE if stripe else Blocks.CONCRETE)
	var ex: Array = []
	var by := 10
	_add_base(w, 0, 14, 64, by)
	_add_base(w, 1, s.x - 15, 64, by)
	ex.append(Vector3(14, 64, 20))
	ex.append(Vector3(s.x - 15, 64, 20))
	for p in [Vector2i(64, 64), Vector2i(64, 22), Vector2i(64, 106)]:
		_add_point(w, p.x, p.y, by)
		ex.append(Vector3(p.x, p.y, 11))
	var lots_x := [0, 19, 51, 83, 115]
	var widths := [13, 26, 26, 26, 13]
	for ix in 5:
		for iz in 5:
			var x0: int = lots_x[ix]
			var z0: int = lots_x[iz]
			for qx in (2 if widths[ix] > 13 else 1):
				for qz in (2 if widths[iz] > 13 else 1):
					if rng.randf() < 0.2:
						continue
					var sx := rng.randi_range(7, 11)
					var sz := rng.randi_range(8, 11)
					var ox := x0 + qx * 13 + rng.randi_range(0, 1)
					var oz := z0 + qz * 13 + rng.randi_range(0, 1)
					if ox + sx >= s.x - 1 or oz + sz >= s.z - 1:
						continue
					if _excluded(ox, oz, sx, sz, ex):
						continue
					var gy := 0
					for c in [Vector2i(ox, oz), Vector2i(ox + sx, oz), Vector2i(ox, oz + sz), Vector2i(ox + sx, oz + sz)]:
						gy = maxi(gy, w.ground_height(c.x, c.y))
					Structures.fill(w, Vector3i(ox, gy - 3, oz), Vector3i(ox + sx - 1, gy - 1, oz + sz - 1), Blocks.STONE)
					var floors := rng.randi_range(1, 4)
					var wall_id: int = [Blocks.BRICK, Blocks.CONCRETE, Blocks.BRICK, Blocks.STONE][rng.randi_range(0, 3)]
					Structures.building(w, Vector3i(ox, gy, oz), sx, sz, floors, wall_id, Blocks.PLANK, rng, rng.randf_range(0.1, 0.5))
	for i in 14:
		var along_x := rng.randf() < 0.5
		var x := rng.randi_range(8, s.x - 12)
		var z := rng.randi_range(8, s.z - 12)
		if along_x:
			z = 13 + 32 * rng.randi_range(0, 3) + rng.randi_range(0, 3)
		else:
			x = 13 + 32 * rng.randi_range(0, 3) + rng.randi_range(0, 3)
		if _excluded(x, z, 4, 2, ex):
			continue
		var gy := w.ground_height(x, z)
		var size := Vector3i(4, 1, 2) if along_x else Vector3i(2, 1, 4)
		Structures.fill(w, Vector3i(x, gy + 1, z), Vector3i(x, gy + 1, z) + size - Vector3i.ONE, Blocks.METAL)
		Structures.fill(w, Vector3i(x + 1, gy + 2, z), Vector3i(x + 1, gy + 2, z) + Vector3i(1, 0, 1), Blocks.CONCRETE)
	_trees(w, rng, 60, ex)
	_veh(w, "jeep", 14, 52, -PI / 2.0)
	_veh(w, "truck", 20, 76, -PI / 2.0)
	_veh(w, "tank", 28, 64, -PI / 2.0)
	_veh(w, "jeep", s.x - 15, 52, PI / 2.0)
	_veh(w, "truck", s.x - 21, 76, PI / 2.0)
	_veh(w, "tank", s.x - 29, 64, PI / 2.0)


# ---------------------------------------------------------------- campo de batalha

static func _battlefield(w: VoxelWorld, rng: RandomNumberGenerator, noise: FastNoiseLite) -> void:
	noise.frequency = 0.018
	var s := w.size_blocks()
	_fill_terrain(w, func(x, z): return 12 + int(round(noise.get_noise_2d(x, z) * 7.0)), 999, 999, 8)
	var ex: Array = []
	var cz := s.z / 2
	var by := 12
	_add_base(w, 0, 14, cz, by)
	_add_base(w, 1, s.x - 15, cz, by)
	ex.append(Vector3(14, cz, 22))
	ex.append(Vector3(s.x - 15, cz, 22))
	var pts := [Vector2i(s.x / 2, cz), Vector2i(s.x / 2, 30), Vector2i(s.x / 2, s.z - 30)]
	for p in pts:
		var py := clampi(w.ground_height(p.x, p.y), 8, 20)
		_add_point(w, p.x, p.y, py)
		ex.append(Vector3(p.x, p.y, 16))
		var gy := py
		Structures.building(w, Vector3i(p.x + 10, gy, p.y + 8), 9, 9, 1, Blocks.CONCRETE, Blocks.CONCRETE, rng, 0.2)
		Structures.building(w, Vector3i(p.x - 18, gy, p.y - 14), 9, 9, 1, Blocks.BRICK, Blocks.PLANK, rng, 0.2)
	for xt in [s.x / 3 - 4, 2 * s.x / 3 - 2]:
		for z in range(16, s.z - 16):
			if _excluded(xt, z, 3, 1, ex):
				continue
			var h := w.ground_height(xt + 1, z)
			for dx in 3:
				for y in range(h - 2, h + 1):
					w.set_block_raw(Vector3i(xt + dx, y, z), Blocks.AIR)
			for side in [xt - 1, xt + 3]:
				var sh := w.ground_height(side, z)
				if z % 5 != 0 and w.get_block(Vector3i(side, sh + 1, z)) == Blocks.AIR:
					w.set_block_raw(Vector3i(side, sh + 1, z), Blocks.SAND)
	for i in 16:
		var x := rng.randi_range(30, s.x - 30)
		var z := rng.randi_range(10, s.z - 10)
		if _excluded(x, z, 1, 1, ex):
			continue
		Structures.carve(w, Vector3(x, w.ground_height(x, z), z), rng.randf_range(2.5, 4.5))
	for i in 24:
		var x := rng.randi_range(30, s.x - 40)
		var z := rng.randi_range(10, s.z - 20)
		if _excluded(x, z, 8, 2, ex):
			continue
		Structures.barricade(w, Vector3i(x, 0, z), rng.randi_range(4, 8), rng.randf() < 0.5,
				Blocks.SAND if rng.randf() < 0.5 else Blocks.PLANK)
	_trees(w, rng, 55, ex)
	_veh(w, "jeep", 14, cz - 12, -PI / 2.0)
	_veh(w, "truck", 14, cz + 12, -PI / 2.0)
	_veh(w, "tank", 30, cz, -PI / 2.0)
	_veh(w, "jeep", s.x - 15, cz - 12, PI / 2.0)
	_veh(w, "truck", s.x - 15, cz + 12, PI / 2.0)
	_veh(w, "tank", s.x - 31, cz, PI / 2.0)


# ---------------------------------------------------------------- montanhas

static func _mountain(w: VoxelWorld, rng: RandomNumberGenerator, noise: FastNoiseLite) -> void:
	noise.frequency = 0.02
	noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	noise.fractal_octaves = 3
	var s := w.size_blocks()
	var west := Vector2(14, 64)
	var east := Vector2(s.x - 15, 64)
	var height_fn := func(x: int, z: int) -> int:
		var n: float = noise.get_noise_2d(x, z)
		var r: float = 1.0 - absf(n)
		r = r * r
		var h: float = 10.0 + r * 36.0 + n * 6.0
		var d: float = minf(Vector2(x, z).distance_to(west), Vector2(x, z).distance_to(east))
		return int(lerpf(14.0, h, clampf((d - 14.0) / 22.0, 0.0, 1.0)))
	_fill_terrain(w, height_fn, 44, 32, -1)
	var ex: Array = []
	_add_base(w, 0, 14, 64, 14)
	_add_base(w, 1, s.x - 15, 64, 14)
	ex.append(Vector3(14, 64, 22))
	ex.append(Vector3(s.x - 15, 64, 22))
	_add_point(w, 64, 64, 24, Blocks.STONE)
	_add_point(w, 34, 24, 36, Blocks.STONE)
	_add_point(w, 94, 24, 36, Blocks.STONE)
	for p in [Vector2i(64, 64), Vector2i(34, 24), Vector2i(94, 24)]:
		ex.append(Vector3(p.x, p.y, 10))
	Structures.bridge(w, Vector3i(38, 36, 23), Vector3i(90, 36, 23), 3, Blocks.PLANK, Blocks.WOOD)
	Structures.building(w, Vector3i(70, 24, 70), 9, 9, 1, Blocks.STONE, Blocks.PLANK, rng, 0.1)
	Structures.tower(w, Vector3i(56, 24, 56), 7, Blocks.CONCRETE, Blocks.PLANK)
	_trees(w, rng, 90, ex, true)
	_veh(w, "jeep", 14, 52, -PI / 2.0)
	_veh(w, "truck", 14, 78, -PI / 2.0)
	_veh(w, "tank", 30, 64, -PI / 2.0)
	_veh(w, "jeep", s.x - 15, 52, PI / 2.0)
	_veh(w, "truck", s.x - 15, 78, PI / 2.0)
	_veh(w, "tank", s.x - 31, 64, PI / 2.0)
