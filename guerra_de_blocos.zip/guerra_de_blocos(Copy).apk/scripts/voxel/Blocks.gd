class_name Blocks
extends RefCounted
## Definição dos tipos de bloco, resistência e atlas de textura procedural.

const AIR := 0
const GRASS := 1
const DIRT := 2
const STONE := 3
const SAND := 4
const WOOD := 5
const LEAVES := 6
const BRICK := 7
const PLANK := 8
const RED := 9
const BLUE := 10
const METAL := 11
const BEDROCK := 12
const SNOW := 13
const CONCRETE := 14
const COUNT := 15
const GRASS_SIDE_TILE := 15

const NAMES := ["Ar", "Grama", "Terra", "Pedra", "Areia", "Madeira", "Folhas", "Tijolo",
		"Tábua", "Bloco Vermelho", "Bloco Azul", "Metal", "Rocha Base", "Neve", "Concreto"]

const COLORS := [
	Color(0, 0, 0, 0), Color(0.33, 0.62, 0.25), Color(0.46, 0.32, 0.2), Color(0.5, 0.5, 0.52),
	Color(0.85, 0.78, 0.55), Color(0.42, 0.29, 0.15), Color(0.2, 0.5, 0.2), Color(0.7, 0.3, 0.25),
	Color(0.72, 0.55, 0.3), Color(0.85, 0.2, 0.2), Color(0.2, 0.4, 0.88), Color(0.62, 0.66, 0.72),
	Color(0.18, 0.18, 0.2), Color(0.94, 0.96, 1.0), Color(0.68, 0.68, 0.66),
]

## Resistência (pontos de dano para quebrar). -1 = indestrutível.
const HP := [0, 3, 3, 6, 2, 4, 1, 8, 3, 6, 6, 14, -1, 2, 10]

## Materiais que o jogador pode construir (inventário).
const BUILDABLE := [PLANK, WOOD, BRICK, STONE, CONCRETE, METAL, SAND]

static var _atlas: ImageTexture


static func is_solid(id: int) -> bool:
	return id != AIR


static func is_natural(id: int) -> bool:
	return id == GRASS or id == DIRT or id == STONE or id == SAND or id == SNOW or id == BEDROCK


static func is_destructible(id: int) -> bool:
	return id != AIR and HP[id] >= 0


## Índice do tile no atlas. face: 0 = topo, 1 = base, 2 = lateral.
static func tile_for(id: int, face: int) -> int:
	if id == GRASS:
		if face == 0:
			return GRASS
		if face == 1:
			return DIRT
		return GRASS_SIDE_TILE
	return id


static func get_atlas() -> ImageTexture:
	if _atlas == null:
		_atlas = _make_atlas()
	return _atlas


static func _make_atlas() -> ImageTexture:
	var img := Image.create(256, 16, false, Image.FORMAT_RGBA8)
	var rng := RandomNumberGenerator.new()
	rng.seed = 4242
	for t in 16:
		var base: Color = Color.MAGENTA
		if t < COUNT:
			base = COLORS[t]
		if t == GRASS_SIDE_TILE:
			base = COLORS[DIRT]
		for y in 16:
			for x in 16:
				var n := rng.randf_range(-0.06, 0.06)
				var c := Color(clampf(base.r + n, 0.0, 1.0), clampf(base.g + n, 0.0, 1.0),
						clampf(base.b + n, 0.0, 1.0), 1.0)
				match t:
					BRICK:
						var row := y / 4
						var off := 4 if row % 2 == 1 else 0
						if y % 4 == 0 or (x + off) % 8 == 0:
							c = Color(0.78, 0.74, 0.68)
					PLANK:
						if y % 4 == 0:
							c = c.darkened(0.2)
					WOOD:
						if x % 5 == 0:
							c = c.darkened(0.2)
					METAL:
						if x == 0 or y == 0 or x == 15 or y == 15:
							c = c.darkened(0.3)
						elif (x == 3 or x == 12) and (y == 3 or y == 12):
							c = c.darkened(0.45)
					CONCRETE:
						if rng.randf() < 0.05:
							c = c.darkened(0.25)
					STONE:
						if rng.randf() < 0.08:
							c = c.darkened(0.18)
					LEAVES:
						if rng.randf() < 0.2:
							c = c.lightened(0.15)
					GRASS_SIDE_TILE:
						if y < 4 or (y < 6 and rng.randf() < 0.5):
							c = Color(COLORS[GRASS].r + n, COLORS[GRASS].g + n, COLORS[GRASS].b + n)
					RED, BLUE:
						if x == 0 or y == 0:
							c = c.lightened(0.2)
						if x == 15 or y == 15:
							c = c.darkened(0.2)
				img.set_pixel(t * 16 + x, y, c)
	return ImageTexture.create_from_image(img)


static func make_material() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_texture = get_atlas()
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	m.vertex_color_use_as_albedo = true
	m.roughness = 1.0
	m.metallic = 0.0
	return m
