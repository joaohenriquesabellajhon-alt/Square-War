class_name TouchControls
extends Control
## Controles de toque: joystick virtual, área de olhar (arrastar) e botões.
## Gera ações de entrada (Input.action_press) para o Player usar normalmente.

var hud: Node
var _joy_idx := -1
var _joy_center := Vector2.ZERO
var _joy_vec := Vector2.ZERO
var _look_idx := -1
var _btns: Array = []
var _held := {}      # índice do toque -> botão

const JOY_R := 100.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	get_viewport().size_changed.connect(_layout)
	_layout()


func _layout() -> void:
	var s := get_viewport_rect().size
	_joy_center = Vector2(190, s.y - 190)
	_btns = [
		{"id": "fire", "pos": Vector2(s.x - 150, s.y - 160), "r": 80.0, "label": "FOGO", "action": "fire"},
		{"id": "jump", "pos": Vector2(s.x - 300, s.y - 90), "r": 55.0, "label": "PULO", "action": "jump"},
		{"id": "alt", "pos": Vector2(s.x - 310, s.y - 230), "r": 50.0, "label": "ALT", "action": "alt_fire"},
		{"id": "use", "pos": Vector2(s.x - 90, s.y - 330), "r": 45.0, "label": "USAR", "action": "interact"},
		{"id": "reload", "pos": Vector2(s.x - 210, s.y - 340), "r": 42.0, "label": "RECAR", "action": "reload"},
		{"id": "weapon", "pos": Vector2(s.x - 90, s.y - 450), "r": 42.0, "label": "ARMA", "call": "next_weapon"},
		{"id": "mat", "pos": Vector2(s.x - 210, s.y - 450), "r": 38.0, "label": "MAT", "action": "next_material"},
		{"id": "shape", "pos": Vector2(s.x - 320, s.y - 400), "r": 38.0, "label": "FORMA", "action": "next_shape"},
		{"id": "pause", "pos": Vector2(s.x - 60, 60), "r": 36.0, "label": "||", "call": "pause"},
		{"id": "inv", "pos": Vector2(s.x - 150, 60), "r": 36.0, "label": "INV", "call": "inventory"},
		{"id": "score", "pos": Vector2(s.x - 240, 60), "r": 36.0, "label": "PLACAR", "call": "scoreboard"},
	]
	queue_redraw()


func _btn_at(p: Vector2) -> Dictionary:
	for b in _btns:
		if p.distance_to(b["pos"]) <= float(b["r"]) + 8.0:
			return b
	return {}


func _input(event: InputEvent) -> void:
	if not visible:
		return
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		var pos := _to_local(t.position)
		if t.pressed:
			var b := _btn_at(pos)
			if not b.is_empty():
				_held[t.index] = b
				_press(b, true)
			elif pos.x < get_viewport_rect().size.x * 0.4 and _joy_idx < 0:
				_joy_idx = t.index
				_joy_center = pos
				_joy_vec = Vector2.ZERO
			elif _look_idx < 0:
				_look_idx = t.index
		else:
			if _held.has(t.index):
				_press(_held[t.index], false)
				_held.erase(t.index)
			if t.index == _joy_idx:
				_joy_idx = -1
				_joy_vec = Vector2.ZERO
				_apply_move()
			if t.index == _look_idx:
				_look_idx = -1
		queue_redraw()
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		if d.index == _joy_idx:
			_joy_vec = ((_to_local(d.position) - _joy_center) / JOY_R).limit_length(1.0)
			_apply_move()
			queue_redraw()
		elif d.index == _look_idx:
			var lp := get_tree().get_first_node_in_group("local_player")
			if lp != null:
				lp.add_look(d.relative * 1.6)


func _to_local(p: Vector2) -> Vector2:
	return get_viewport().get_canvas_transform().affine_inverse() * p


func _apply_move() -> void:
	var v := _joy_vec
	if v.length() < 0.15:
		v = Vector2.ZERO
	_set_axis("move_left", maxf(-v.x, 0.0))
	_set_axis("move_right", maxf(v.x, 0.0))
	_set_axis("move_forward", maxf(-v.y, 0.0))
	_set_axis("move_back", maxf(v.y, 0.0))


func _set_axis(action: StringName, strength: float) -> void:
	if strength > 0.0:
		Input.action_press(action, strength)
	else:
		Input.action_release(action)


func _press(b: Dictionary, down: bool) -> void:
	if b.has("action"):
		if down:
			Input.action_press(b["action"])
		else:
			Input.action_release(b["action"])
	elif down and hud != null:
		match b["call"]:
			"pause":
				hud.toggle_pause()
			"inventory":
				hud.toggle_inventory()
			"scoreboard":
				hud.toggle_scoreboard()
			"next_weapon":
				var lp := get_tree().get_first_node_in_group("local_player")
				if lp != null:
					lp.cycle_weapon(1)


func _draw() -> void:
	var held_ids := []
	for k in _held:
		held_ids.append(_held[k]["id"])
	# joystick
	draw_circle(_joy_center, JOY_R, Color(1, 1, 1, 0.10))
	draw_arc(_joy_center, JOY_R, 0, TAU, 40, Color(1, 1, 1, 0.35), 3.0)
	draw_circle(_joy_center + _joy_vec * JOY_R, 38.0, Color(1, 1, 1, 0.35))
	var font := ThemeDB.fallback_font
	for b in _btns:
		var down: bool = b["id"] in held_ids
		draw_circle(b["pos"], b["r"], Color(1, 1, 1, 0.32 if down else 0.14))
		draw_arc(b["pos"], b["r"], 0, TAU, 32, Color(1, 1, 1, 0.5), 2.0)
		var fs := 18 if b["r"] > 45.0 else 14
		var sz := font.get_string_size(b["label"], HORIZONTAL_ALIGNMENT_CENTER, -1, fs)
		draw_string(font, b["pos"] + Vector2(-sz.x * 0.5, fs * 0.35), b["label"], HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1, 1, 1, 0.9))
