extends Control
## Menu principal: jogar offline, criar/entrar em partida multiplayer, configurações.
## Inclui seleção de modo, mapa, equipe e classe.

var pages := {}
var _current: Control
var _host_mode := false
var _ip_edit: LineEdit
var _port_edit: LineEdit
var _lobby_label: Label
var _lobby_start: Button
var _status_label: Label
var _bots_label: Label


func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().paused = false
	set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.13, 0.18, 0.28)
	add_child(bg)
	_decor()
	pages["main"] = _make_main()
	pages["setup"] = _make_setup()
	pages["join"] = _make_join()
	pages["lobby"] = _make_lobby()
	pages["settings"] = _make_settings()
	for k in pages:
		pages[k].visible = false
		add_child(pages[k])
	_show("main")
	Net.connected.connect(_on_connected)
	Net.connection_failed.connect(func(): _status("Falha ao conectar. Verifique o endereço e a porta."))
	Net.server_closed.connect(func():
		_status("O host fechou a partida.")
		_show("main"))
	Net.peer_joined.connect(func(_id): _update_lobby())
	Net.peer_left.connect(func(_id): _update_lobby())


func _decor() -> void:
	# blocos decorativos no fundo
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	for i in 26:
		var c := ColorRect.new()
		var s := rng.randf_range(30, 110)
		c.size = Vector2(s, s)
		c.position = Vector2(rng.randf_range(0, 1280), rng.randf_range(0, 720))
		var team := rng.randi() % 3
		c.color = [Color(0.85, 0.25, 0.22, 0.18), Color(0.25, 0.5, 0.95, 0.18), Color(0.7, 0.7, 0.7, 0.10)][team]
		c.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(c)


func _show(name: String) -> void:
	for k in pages:
		pages[k].visible = (k == name)
	_current = pages[name]


func _page() -> VBoxContainer:
	var sc := ScrollContainer.new()
	sc.set_anchors_preset(Control.PRESET_FULL_RECT)
	sc.offset_left = 30
	sc.offset_right = -30
	sc.offset_top = 20
	sc.offset_bottom = -20
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 12)
	sc.add_child(v)
	sc.set_meta("box", v)
	return v


func _wrap(box: VBoxContainer) -> Control:
	return box.get_parent() as Control


func _title(box: VBoxContainer, text: String, size := 40) -> void:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(l)


func _button(box: Control, text: String, cb: Callable, width := 360.0) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(width, 58)
	b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b.pressed.connect(cb)
	box.add_child(b)
	return b


func _status(text: String) -> void:
	if _status_label != null:
		_status_label.text = text


func _choice_row(box: VBoxContainer, title: String, options: Array, current: String, on_select: Callable) -> void:
	var l := Label.new()
	l.text = title
	l.add_theme_font_size_override("font_size", 20)
	box.add_child(l)
	var fl := HFlowContainer.new()
	fl.add_theme_constant_override("h_separation", 8)
	fl.add_theme_constant_override("v_separation", 8)
	box.add_child(fl)
	var group := ButtonGroup.new()
	for o in options:
		var b := Button.new()
		b.text = o[1]
		b.toggle_mode = true
		b.button_group = group
		b.custom_minimum_size = Vector2(170, 52)
		b.button_pressed = (o[0] == current)
		var id: String = o[0]
		b.pressed.connect(func(): on_select.call(id))
		fl.add_child(b)


# ------------------------------------------------------------------ páginas

func _make_main() -> Control:
	var box := _page()
	var sp := Control.new()
	sp.custom_minimum_size = Vector2(0, 60)
	box.add_child(sp)
	_title(box, "GUERRA DE BLOCOS 3D", 54)
	var sub := Label.new()
	sub.text = "Combate voxel • destruição • construção • veículos • multiplayer"
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(sub)
	var sp2 := Control.new()
	sp2.custom_minimum_size = Vector2(0, 30)
	box.add_child(sp2)
	_button(box, "Jogar (offline)", func():
		_host_mode = false
		_refresh_setup_button()
		_show("setup"))
	_button(box, "Criar partida (host)", func():
		_host_mode = true
		_refresh_setup_button()
		_show("setup"))
	_button(box, "Entrar em partida", func(): _show("join"))
	_button(box, "Configurações", func(): _show("settings"))
	if not OS.has_feature("web"):
		_button(box, "Sair", func(): get_tree().quit())
	return _wrap(box)


var _start_btn: Button


func _refresh_setup_button() -> void:
	if _start_btn != null:
		_start_btn.text = "Criar partida e aguardar jogadores" if _host_mode else "Iniciar partida"


func _make_setup() -> Control:
	var box := _page()
	_title(box, "Nova partida", 36)
	var modes: Array = []
	for k in Game.MODES:
		modes.append([k, Game.MODES[k]["name"]])
	var mode_desc := Label.new()
	mode_desc.autowrap_mode = TextServer.AUTOWRAP_WORD
	mode_desc.text = Game.MODES[Game.mode]["desc"]
	_choice_row(box, "Modo de jogo", modes, Game.mode, func(id):
		Game.mode = id
		mode_desc.text = Game.MODES[id]["desc"])
	box.add_child(mode_desc)
	var maps: Array = []
	for k in TerrainGen.MAP_IDS:
		maps.append([k, TerrainGen.MAPS[k]["name"]])
	var map_desc := Label.new()
	map_desc.autowrap_mode = TextServer.AUTOWRAP_WORD
	map_desc.text = TerrainGen.MAPS[Game.map_id]["desc"]
	_choice_row(box, "Mapa", maps, Game.map_id, func(id):
		Game.map_id = id
		map_desc.text = TerrainGen.MAPS[id]["desc"])
	box.add_child(map_desc)
	_loadout(box)
	_bots_label = Label.new()
	_bots_label.text = "Bots por equipe: %d" % Game.bots_per_team
	box.add_child(_bots_label)
	var sl := HSlider.new()
	sl.min_value = 0
	sl.max_value = 8
	sl.step = 1
	sl.value = Game.bots_per_team
	sl.custom_minimum_size = Vector2(300, 36)
	sl.value_changed.connect(func(v):
		Game.bots_per_team = int(v)
		Settings.bots_per_team = int(v)
		_bots_label.text = "Bots por equipe: %d" % int(v))
	box.add_child(sl)
	_start_btn = _button(box, "Iniciar partida", _on_setup_start)
	_button(box, "Voltar", func(): _show("main"))
	_status_label = Label.new()
	_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(_status_label)
	return _wrap(box)


func _loadout(box: VBoxContainer) -> void:
	_choice_row(box, "Equipe", [["0", "Vermelhos"], ["1", "Azuis"]], str(Game.my_team), func(id): Game.my_team = int(id))
	var classes: Array = []
	for c in Game.CLASS_IDS:
		classes.append([c, Game.CLASSES[c]["name"]])
	_choice_row(box, "Classe", classes, Game.my_class, func(id): Game.my_class = id)


func _on_setup_start() -> void:
	Settings.save_settings()
	if _host_mode:
		var err := Net.host()
		if err != OK:
			_status("Não foi possível criar a partida (erro %d). A porta %d está em uso?" % [err, Net.DEFAULT_PORT])
			return
		_update_lobby()
		_show("lobby")
	else:
		Net.go_offline()
		Game.start_match()


func _make_join() -> Control:
	var box := _page()
	_title(box, "Entrar em partida", 36)
	var l1 := Label.new()
	l1.text = "Endereço do host (IP)"
	box.add_child(l1)
	_ip_edit = LineEdit.new()
	_ip_edit.text = "127.0.0.1"
	_ip_edit.custom_minimum_size = Vector2(360, 52)
	box.add_child(_ip_edit)
	var l2 := Label.new()
	l2.text = "Porta"
	box.add_child(l2)
	_port_edit = LineEdit.new()
	_port_edit.text = str(Net.DEFAULT_PORT)
	_port_edit.custom_minimum_size = Vector2(360, 52)
	box.add_child(_port_edit)
	_loadout(box)
	_button(box, "Conectar", func():
		Settings.save_settings()
		_status("Conectando...")
		var err := Net.join(_ip_edit.text, int(_port_edit.text))
		if err != OK:
			_status("Endereço inválido (erro %d)" % err))
	_button(box, "Voltar", func():
		Net.go_offline()
		_show("main"))
	return _wrap(box)


func _make_lobby() -> Control:
	var box := _page()
	_title(box, "Sala de espera", 36)
	_lobby_label = Label.new()
	_lobby_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_lobby_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	box.add_child(_lobby_label)
	_lobby_start = _button(box, "Iniciar partida", func():
		Game.start_match())
	_button(box, "Cancelar", func():
		Net.go_offline()
		_show("main"))
	return _wrap(box)


func _update_lobby() -> void:
	if _lobby_label == null:
		return
	if multiplayer.is_server() and Net.online:
		var ips := ", ".join(Net.local_ips())
		_lobby_label.text = "Você é o host.\nEndereços para os amigos: %s  (porta %d)\nJogadores conectados: %d\nModo: %s • Mapa: %s" % [
			ips if ips != "" else "(sem rede)", Net.DEFAULT_PORT, multiplayer.get_peers().size() + 1,
			Game.MODES[Game.mode]["name"], TerrainGen.MAPS[Game.map_id]["name"]]
		_lobby_start.visible = true
	else:
		_lobby_label.text = "Conectado! Aguardando o host iniciar a partida..."
		_lobby_start.visible = false


func _on_connected() -> void:
	_update_lobby()
	_show("lobby")


func _make_settings() -> Control:
	var wrap := MarginContainer.new()
	wrap.set_anchors_preset(Control.PRESET_FULL_RECT)
	wrap.add_theme_constant_override("margin_left", 120)
	wrap.add_theme_constant_override("margin_right", 120)
	wrap.add_theme_constant_override("margin_top", 20)
	wrap.add_theme_constant_override("margin_bottom", 20)
	var sc := ScrollContainer.new()
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	wrap.add_child(sc)
	var sp := SettingsPanel.new()
	sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sp.closed.connect(func(): _show("main"))
	sc.add_child(sp)
	return wrap
