extends CanvasLayer
## HUD completo montado em código: vida, munição, hotbar, placar de equipes, killfeed,
## minimapa, scoreboard (Tab), inventário (I), menu de pausa e tela de fim de partida.

var ctrl: GameController

var root: Control
var hp_bar: ProgressBar
var hp_label: Label
var ammo_label: Label
var weapon_label: Label
var build_label: Label
var score_label: Label
var info_label: Label
var msg_label: Label
var death_label: Label
var fps_label: Label
var cross: Control
var hit_mark: Control
var vignette: ColorRect
var killfeed_box: VBoxContainer
var hotbar: HBoxContainer
var hotbar_btns: Array[Button] = []
var minimap: Control
var board: PanelContainer
var board_grid: GridContainer
var inv_panel: PanelContainer
var pause_panel: PanelContainer
var settings_panel: SettingsPanel
var over_panel: PanelContainer
var over_label: Label
var touch: TouchControls
var _board_t := 0.0
var _board_pinned := false
var _msg_t := 0.0
var _mm_tex: ImageTexture
var _inv_dirty := true
var _hit_t := 0.0


func _ready() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	add_to_group("hud")
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	_build_hud()
	_build_minimap_texture()
	_build_board()
	_build_inventory()
	_build_pause()
	_build_over()
	if Settings.touch_controls:
		touch = TouchControls.new()
		touch.hud = self
		root.add_child(touch)
	ctrl.killfeed.connect(_on_killfeed)
	ctrl.message.connect(_on_message)
	ctrl.hit_marker.connect(func(): _hit_t = 0.15)
	ctrl.local_damaged.connect(_on_damaged)
	ctrl.match_over.connect(_on_over)
	ctrl.state_changed.connect(func(): _inv_dirty = true)


# ------------------------------------------------------------------ construção

func _label(text: String, size := 20, color := Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 5)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _box_style(color: Color) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = color
	sb.set_corner_radius_all(6)
	sb.content_margin_left = 12
	sb.content_margin_right = 12
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	return sb


func _build_hud() -> void:
	# mira
	cross = Control.new()
	cross.set_anchors_preset(Control.PRESET_CENTER)
	cross.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cross.draw.connect(func():
		var c := Color(1, 1, 1, 0.9)
		cross.draw_line(Vector2(-12, 0), Vector2(-4, 0), c, 2.0)
		cross.draw_line(Vector2(4, 0), Vector2(12, 0), c, 2.0)
		cross.draw_line(Vector2(0, -12), Vector2(0, -4), c, 2.0)
		cross.draw_line(Vector2(0, 4), Vector2(0, 12), c, 2.0))
	root.add_child(cross)
	hit_mark = Control.new()
	hit_mark.set_anchors_preset(Control.PRESET_CENTER)
	hit_mark.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hit_mark.visible = false
	hit_mark.draw.connect(func():
		var c := Color(1, 0.3, 0.3, 1)
		for s in [Vector2(1, 1), Vector2(-1, 1), Vector2(1, -1), Vector2(-1, -1)]:
			hit_mark.draw_line(s * 6.0, s * 14.0, c, 3.0))
	root.add_child(hit_mark)
	# vinheta de dano
	vignette = ColorRect.new()
	vignette.set_anchors_preset(Control.PRESET_FULL_RECT)
	vignette.color = Color(0.8, 0.0, 0.0, 0.0)
	vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(vignette)
	# vida (canto inferior esquerdo; sobe um pouco em telas de toque por causa do joystick)
	var hp_box := VBoxContainer.new()
	hp_box.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	hp_box.position = Vector2(20, -80 if not Settings.touch_controls else -330)
	hp_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(hp_box)
	hp_label = _label("100 / 100", 20)
	hp_box.add_child(hp_label)
	hp_bar = ProgressBar.new()
	hp_bar.custom_minimum_size = Vector2(280, 22)
	hp_bar.show_percentage = false
	hp_bar.add_theme_stylebox_override("fill", _box_style(Color(0.25, 0.8, 0.3)))
	hp_bar.add_theme_stylebox_override("background", _box_style(Color(0, 0, 0, 0.5)))
	hp_box.add_child(hp_bar)
	# arma / munição
	var ab := VBoxContainer.new()
	if Settings.touch_controls:
		# no toque, fica ao lado dos botões do topo para não se sobrepor a eles
		ab.set_anchors_preset(Control.PRESET_TOP_RIGHT)
		ab.grow_horizontal = Control.GROW_DIRECTION_BEGIN
		ab.position = Vector2(-300, 12)
	else:
		ab.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
		ab.grow_horizontal = Control.GROW_DIRECTION_BEGIN
		ab.grow_vertical = Control.GROW_DIRECTION_BEGIN
		ab.position = Vector2(-30, -140)
	ab.alignment = BoxContainer.ALIGNMENT_END
	ab.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(ab)
	weapon_label = _label("", 22)
	weapon_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	ab.add_child(weapon_label)
	ammo_label = _label("", 34, Color(1, 0.9, 0.4))
	ammo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	ab.add_child(ammo_label)
	build_label = _label("", 18, Color(0.7, 1.0, 0.7))
	build_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	ab.add_child(build_label)
	# hotbar
	hotbar = HBoxContainer.new()
	hotbar.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	hotbar.grow_horizontal = Control.GROW_DIRECTION_BOTH
	hotbar.grow_vertical = Control.GROW_DIRECTION_BEGIN
	hotbar.position = Vector2(0, -20)
	hotbar.alignment = BoxContainer.ALIGNMENT_CENTER
	hotbar.add_theme_constant_override("separation", 6)
	root.add_child(hotbar)
	for i in 4:
		var b := Button.new()
		b.custom_minimum_size = Vector2(120, 46)
		b.focus_mode = Control.FOCUS_NONE
		b.add_theme_font_size_override("font_size", 14)
		var idx := i
		b.pressed.connect(func():
			if ctrl.local_player != null:
				ctrl.local_player.select_weapon(idx))
		hotbar.add_child(b)
		hotbar_btns.append(b)
	# placar de equipes + info
	var top := VBoxContainer.new()
	top.set_anchors_preset(Control.PRESET_CENTER_TOP)
	top.grow_horizontal = Control.GROW_DIRECTION_BOTH
	top.position = Vector2(0, 8)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(top)
	score_label = _label("", 30)
	score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	top.add_child(score_label)
	info_label = _label("", 20, Color(1, 0.95, 0.6))
	info_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	top.add_child(info_label)
	msg_label = _label("", 26, Color(1, 1, 0.5))
	msg_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
	msg_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	msg_label.position = Vector2(0, 100)
	msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(msg_label)
	death_label = _label("", 40, Color(1, 0.4, 0.4))
	death_label.set_anchors_preset(Control.PRESET_CENTER)
	death_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	death_label.position = Vector2(0, -120)
	death_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(death_label)
	fps_label = _label("", 14)
	fps_label.position = Vector2(10, 190 if not Settings.touch_controls else 200)
	root.add_child(fps_label)
	# killfeed
	killfeed_box = VBoxContainer.new()
	killfeed_box.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	killfeed_box.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	killfeed_box.position = Vector2(-20, 130 if Settings.touch_controls else 20)
	killfeed_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(killfeed_box)
	# minimapa
	minimap = Control.new()
	minimap.custom_minimum_size = Vector2(170, 170)
	minimap.size = Vector2(170, 170)
	minimap.position = Vector2(12, 12)
	minimap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	minimap.draw.connect(_draw_minimap)
	root.add_child(minimap)


func _build_minimap_texture() -> void:
	var w := ctrl.world
	var s := w.size_blocks()
	var step := 2
	var img := Image.create(s.x / step, s.z / step, false, Image.FORMAT_RGBA8)
	for z in range(0, s.z, step):
		for x in range(0, s.x, step):
			var y := s.y - 1
			while y > 0 and w.get_block(Vector3i(x, y, z)) == Blocks.AIR:
				y -= 1
			var id := w.get_block(Vector3i(x, y, z))
			var c: Color = Blocks.COLORS[id] if id != Blocks.AIR else Color(0.1, 0.1, 0.1)
			c = c.lightened(clampf(float(y) / float(s.y), 0.0, 1.0) * 0.4)
			img.set_pixel(x / step, z / step, c)
	_mm_tex = ImageTexture.create_from_image(img)


func _draw_minimap() -> void:
	var sz := minimap.size
	minimap.draw_rect(Rect2(Vector2.ZERO, sz), Color(0, 0, 0, 0.55))
	if _mm_tex != null:
		minimap.draw_texture_rect(_mm_tex, Rect2(Vector2(3, 3), sz - Vector2(6, 6)), false, Color(1, 1, 1, 0.9))
	var ws := ctrl.world.size_blocks()
	var inner := sz - Vector2(6, 6)
	for pt in ctrl.points:
		var p: Vector3 = pt["pos"]
		var q := Vector2(3 + p.x / ws.x * inner.x, 3 + p.z / ws.z * inner.y)
		var col := Color(0.9, 0.9, 0.9)
		if pt["owner"] >= 0:
			col = Game.TEAM_COLORS[pt["owner"]]
		minimap.draw_rect(Rect2(q - Vector2(4, 4), Vector2(8, 8)), col, false, 2.0)
	var me := ctrl.local_player
	for n in ctrl.all_players():
		var pl := n as Player
		if not pl.alive:
			continue
		if me != null and pl.team != me.team and pl != me and Game.mode != "sandbox":
			# inimigos só aparecem perto
			if pl.global_position.distance_to(me.global_position) > 35.0:
				continue
		var q := Vector2(3 + pl.global_position.x / ws.x * inner.x, 3 + pl.global_position.z / ws.z * inner.y)
		var c: Color = Game.TEAM_COLORS[pl.team]
		if pl == me:
			minimap.draw_circle(q, 4.5, Color.WHITE)
			var d := Vector2(-sin(pl.yaw), -cos(pl.yaw))
			minimap.draw_line(q, q + d * 12.0, Color.WHITE, 2.0)
		else:
			minimap.draw_circle(q, 3.0, c)
	for n in ctrl.vehicles_root.get_children():
		var v := n as Vehicle
		if v.dead:
			continue
		var q := Vector2(3 + v.global_position.x / ws.x * inner.x, 3 + v.global_position.z / ws.z * inner.y)
		minimap.draw_rect(Rect2(q - Vector2(2.5, 2.5), Vector2(5, 5)), Color(1, 0.9, 0.2))


func _build_board() -> void:
	board = PanelContainer.new()
	board.set_anchors_preset(Control.PRESET_CENTER)
	board.grow_horizontal = Control.GROW_DIRECTION_BOTH
	board.grow_vertical = Control.GROW_DIRECTION_BOTH
	board.visible = false
	root.add_child(board)
	var v := VBoxContainer.new()
	board.add_child(v)
	var t := Label.new()
	t.text = "Placar"
	t.add_theme_font_size_override("font_size", 26)
	v.add_child(t)
	board_grid = GridContainer.new()
	board_grid.columns = 4
	board_grid.add_theme_constant_override("h_separation", 30)
	v.add_child(board_grid)


func _refresh_board() -> void:
	for c in board_grid.get_children():
		c.queue_free()
	for h in ["Jogador", "Equipe", "Abates", "Mortes"]:
		var l := Label.new()
		l.text = h
		l.add_theme_color_override("font_color", Color(1, 0.9, 0.5))
		board_grid.add_child(l)
	var list: Array = ctrl.all_players()
	list.sort_custom(func(a, b): return a.kills > b.kills)
	for n in list:
		var p := n as Player
		if p.ai_mode == "zombie" and not p.alive:
			continue
		var cells := [p.display_name, Game.TEAM_NAMES[p.team], str(p.kills), str(p.deaths)]
		for i in 4:
			var l := Label.new()
			l.text = cells[i]
			if i < 2:
				l.add_theme_color_override("font_color", Game.TEAM_COLORS[p.team].lightened(0.35))
			board_grid.add_child(l)


func _build_inventory() -> void:
	inv_panel = PanelContainer.new()
	inv_panel.set_anchors_preset(Control.PRESET_CENTER)
	inv_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	inv_panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	inv_panel.visible = false
	root.add_child(inv_panel)


func _fill_inventory() -> void:
	for c in inv_panel.get_children():
		c.queue_free()
	var lp := ctrl.local_player
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	inv_panel.add_child(v)
	var t := Label.new()
	t.text = "Inventário e construção"
	t.add_theme_font_size_override("font_size", 26)
	v.add_child(t)
	var limit_text := "ilimitado" if ctrl.unlimited_build else "%d / %d" % [int(ctrl.local_inv.get("_built", 0)), Game.build_limit]
	var lb := Label.new()
	lb.text = "Blocos construídos: " + limit_text
	v.add_child(lb)
	var mats := Label.new()
	mats.text = "Material (usado pelo Martelo de Construção):"
	v.add_child(mats)
	var grid := GridContainer.new()
	grid.columns = 4
	v.add_child(grid)
	for i in Blocks.BUILDABLE.size():
		var id: int = Blocks.BUILDABLE[i]
		var b := Button.new()
		var cnt: String = "∞" if ctrl.unlimited_build else str(int(ctrl.local_inv.get(id, 0)))
		b.text = "%s\n%s" % [Blocks.NAMES[id], cnt]
		b.custom_minimum_size = Vector2(120, 56)
		b.toggle_mode = true
		b.button_pressed = lp != null and lp.mat_idx == i
		b.modulate = Blocks.COLORS[id].lightened(0.5)
		var idx := i
		b.pressed.connect(func():
			if lp != null:
				lp.mat_idx = idx
			_inv_dirty = true)
		grid.add_child(b)
	var sl := Label.new()
	sl.text = "Forma:"
	v.add_child(sl)
	var sh := HBoxContainer.new()
	v.add_child(sh)
	for i in WeaponDB.BUILD_SHAPES.size():
		var b := Button.new()
		b.text = WeaponDB.BUILD_SHAPES[i]
		b.toggle_mode = true
		b.custom_minimum_size = Vector2(110, 48)
		b.button_pressed = lp != null and lp.shape_idx == i
		var idx := i
		b.pressed.connect(func():
			if lp != null:
				lp.shape_idx = idx
			_inv_dirty = true)
		sh.add_child(b)
	var cl := Label.new()
	cl.text = "Classe (vale no próximo respawn):"
	v.add_child(cl)
	var ch := HBoxContainer.new()
	v.add_child(ch)
	for cid in Game.CLASS_IDS:
		var b := Button.new()
		b.text = Game.CLASSES[cid]["name"]
		b.custom_minimum_size = Vector2(110, 48)
		var id2: String = cid
		b.pressed.connect(func():
			if lp != null:
				ctrl.request_class(lp.name, id2))
		ch.add_child(b)
	var wl := Label.new()
	wl.text = "Equipamento atual:"
	v.add_child(wl)
	if lp != null:
		for w in lp.weapons:
			var d := WeaponDB.get_def(w)
			var l := Label.new()
			l.text = "• %s" % d["name"]
			v.add_child(l)
	var close := Button.new()
	close.text = "Fechar"
	close.custom_minimum_size = Vector2(0, 52)
	close.pressed.connect(toggle_inventory)
	v.add_child(close)


func _build_pause() -> void:
	pause_panel = PanelContainer.new()
	pause_panel.set_anchors_preset(Control.PRESET_CENTER)
	pause_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	pause_panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	pause_panel.visible = false
	root.add_child(pause_panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	pause_panel.add_child(v)
	var t := Label.new()
	t.text = "Pausado" if not Net.online else "Menu"
	t.add_theme_font_size_override("font_size", 30)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(t)
	for entry in [["Continuar", toggle_pause], ["Configurações", _open_settings], ["Sair para o menu", func(): Game.to_menu()]]:
		var b := Button.new()
		b.text = entry[0]
		b.custom_minimum_size = Vector2(280, 56)
		b.pressed.connect(entry[1])
		v.add_child(b)


func _open_settings() -> void:
	pause_panel.visible = false
	settings_panel = SettingsPanel.new()
	settings_panel.set_anchors_preset(Control.PRESET_CENTER)
	settings_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	settings_panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	root.add_child(settings_panel)
	settings_panel.closed.connect(func():
		settings_panel.queue_free()
		pause_panel.visible = true)


func _build_over() -> void:
	over_panel = PanelContainer.new()
	over_panel.set_anchors_preset(Control.PRESET_CENTER)
	over_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	over_panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	over_panel.visible = false
	root.add_child(over_panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	over_panel.add_child(v)
	over_label = Label.new()
	over_label.add_theme_font_size_override("font_size", 34)
	over_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(over_label)
	var b := Button.new()
	b.text = "Voltar ao menu"
	b.custom_minimum_size = Vector2(260, 60)
	b.pressed.connect(func(): Game.to_menu())
	v.add_child(b)


# ------------------------------------------------------------------ abrir/fechar painéis

func _set_ui_open(open: bool) -> void:
	ctrl.ui_blocking = open or ctrl.finished
	if open or ctrl.finished or Settings.touch_controls:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	else:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func toggle_pause() -> void:
	if ctrl.finished:
		return
	var open := not pause_panel.visible
	if settings_panel != null and is_instance_valid(settings_panel):
		settings_panel.queue_free()
		open = false
	pause_panel.visible = open
	inv_panel.visible = false
	_set_ui_open(open)
	if not Net.online:
		get_tree().paused = open


func toggle_inventory() -> void:
	if ctrl.finished or pause_panel.visible:
		return
	inv_panel.visible = not inv_panel.visible
	if inv_panel.visible:
		_fill_inventory()
	_set_ui_open(inv_panel.visible)


func toggle_scoreboard() -> void:
	_board_pinned = not _board_pinned


func _on_over(text: String) -> void:
	over_label.text = text
	over_panel.visible = true
	pause_panel.visible = false
	inv_panel.visible = false
	get_tree().paused = false


# ------------------------------------------------------------------ eventos

func _on_killfeed(text: String) -> void:
	var l := _label(text, 18)
	killfeed_box.add_child(l)
	if killfeed_box.get_child_count() > 5:
		killfeed_box.get_child(0).queue_free()
	get_tree().create_timer(5.0).timeout.connect(l.queue_free)


func _on_message(text: String) -> void:
	msg_label.text = text
	_msg_t = 3.0


func _on_damaged(amount: float) -> void:
	vignette.color.a = clampf(0.15 + amount / 80.0, 0.15, 0.55)


# ------------------------------------------------------------------ atualização

func _process(delta: float) -> void:
	if vignette.color.a > 0.0:
		vignette.color.a = maxf(vignette.color.a - delta * 0.9, 0.0)
	if _hit_t > 0.0:
		_hit_t -= delta
	hit_mark.visible = _hit_t > 0.0
	if _msg_t > 0.0:
		_msg_t -= delta
		if _msg_t <= 0.0:
			msg_label.text = ""
	fps_label.text = "FPS: %d" % Engine.get_frames_per_second() if Settings.show_fps else ""
	_update_scoreline()
	var lp := ctrl.local_player
	if lp == null or not is_instance_valid(lp):
		death_label.text = "Conectando..."
		return
	hp_bar.max_value = lp.max_hp
	hp_bar.value = lp.hp
	hp_label.text = "%d / %d" % [int(ceil(lp.hp)), int(lp.max_hp)]
	var frac := lp.hp / maxf(lp.max_hp, 1.0)
	(hp_bar.get_theme_stylebox("fill") as StyleBoxFlat).bg_color = Color(0.85, 0.2, 0.2).lerp(Color(0.25, 0.8, 0.3), frac)
	if lp.alive:
		death_label.text = ""
	elif Game.mode == "survival":
		death_label.text = "Você caiu! Reviva na próxima onda"
	else:
		death_label.text = "Você morreu — reaparecendo..."
	cross.visible = lp.alive and lp.seat_vehicle == "" and lp.weapons.size() > 0 and lp.current_weapon() != "builder" or (lp.alive and lp.seat_vehicle != "")
	_update_weapon_info(lp)
	_board_t -= delta
	var show_board := _board_pinned or Input.is_action_pressed("scoreboard")
	if show_board != board.visible:
		board.visible = show_board
		_board_t = 0.0
	if board.visible and _board_t <= 0.0:
		_board_t = 0.5
		_refresh_board()
	if Input.is_action_just_pressed("inventory"):
		toggle_inventory()
	if inv_panel.visible and _inv_dirty:
		_inv_dirty = false
		_fill_inventory()
	minimap.queue_redraw()


func _update_weapon_info(lp: Player) -> void:
	if lp.seat_vehicle != "":
		var v := ctrl.get_vehicle(lp.seat_vehicle)
		weapon_label.text = "%s (banco %d)" % [Vehicle.DEFS[v.kind]["name"], lp.seat_idx + 1] if v != null else ""
		ammo_label.text = "HP %d" % int(v.hp) if v != null else ""
		build_label.text = "USAR: sair do veículo" if Settings.touch_controls else "[E] sair do veículo"
		for i in hotbar_btns.size():
			hotbar_btns[i].visible = false
		return
	var wid := lp.current_weapon()
	var def := WeaponDB.get_def(wid)
	weapon_label.text = def["name"]
	if def["mag"] > 0:
		if lp.reload_left > 0.0:
			ammo_label.text = "recarregando..."
		else:
			ammo_label.text = "∞" if ctrl.infinite_ammo else "%d / %d" % [lp.ammo[wid], def["mag"]]
			if ctrl.infinite_ammo:
				ammo_label.text = "%d / ∞" % lp.ammo[wid]
	else:
		ammo_label.text = ""
	if def["kind"] == "build":
		var id: int = Blocks.BUILDABLE[lp.mat_idx]
		var cnt := "∞" if ctrl.unlimited_build else str(int(ctrl.local_inv.get(id, 0)))
		var hint := "MAT / FORMA / ALT: recolher" if Settings.touch_controls else "[C] material  [V] forma  botão direito: recolher"
		build_label.text = "%s • %s x%s\n%s" % [WeaponDB.BUILD_SHAPES[lp.shape_idx], Blocks.NAMES[id], cnt, hint]
	elif ctrl.world.collision_ready_at(lp.global_position):
		var use_txt := "USAR" if Settings.touch_controls else "[E]"
		build_label.text = (use_txt + " entrar em veículo próximo") if _near_vehicle(lp) else ""
	for i in hotbar_btns.size():
		var b := hotbar_btns[i]
		b.visible = i < lp.weapons.size()
		if i < lp.weapons.size():
			b.text = "%d  %s" % [i + 1, WeaponDB.get_def(lp.weapons[i])["name"].get_slice(" ", 0)]
			b.modulate = Color(1, 0.9, 0.4) if i == lp.weapon_idx else Color(1, 1, 1, 0.75)


func _near_vehicle(lp: Player) -> bool:
	for v in get_tree().get_nodes_in_group("vehicles"):
		if not (v as Vehicle).dead and (v as Node3D).global_position.distance_to(lp.global_position) < 6.0:
			return true
	return false


func _update_scoreline() -> void:
	var t := ""
	var info := ""
	match Game.mode:
		"team_war":
			t = "%d  ×  %d" % [ctrl.team_scores[0], ctrl.team_scores[1]]
			info = "Guerra de Equipes — primeiro a %d" % GameController.WIN_KILLS
		"capture":
			t = "%d  ×  %d" % [ctrl.team_scores[0], ctrl.team_scores[1]]
			var o := [0, 0, 0]
			for pt in ctrl.points:
				o[int(pt["owner"]) + 1] += 1
			info = "Pontos: %d vermelhos • %d neutros • %d azuis  (meta %d)" % [o[1], o[0], o[2], GameController.WIN_POINTS]
		"survival":
			t = "Onda %d" % ctrl.wave
			info = ctrl.wave_info
		"training":
			t = "Acertos: %d" % ctrl.training_hits
			info = "Treinamento — alvos reaparecem; munição infinita"
		"sandbox":
			t = "Sandbox"
			info = "Construção ilimitada • sem dano entre jogadores"
	score_label.text = t
	info_label.text = info
