class_name SettingsPanel
extends PanelContainer
## Painel de configurações (usado no menu principal e no menu de pausa).

signal closed


func _ready() -> void:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	add_child(box)
	var title := Label.new()
	title.text = "Configurações"
	title.add_theme_font_size_override("font_size", 28)
	box.add_child(title)
	var name_edit := LineEdit.new()
	name_edit.text = Settings.player_name
	name_edit.max_length = 16
	name_edit.placeholder_text = "Seu nome"
	name_edit.text_changed.connect(func(t): Settings.player_name = t if t != "" else "Jogador")
	_row(box, "Nome", name_edit)
	var q := OptionButton.new()
	q.add_item("Baixa (celular modesto)")
	q.add_item("Média")
	q.add_item("Alta")
	q.selected = Settings.quality
	q.item_selected.connect(func(i):
		Settings.set_quality(i)
		Settings.apply())
	_row(box, "Qualidade gráfica", q)
	var sh := CheckButton.new()
	sh.button_pressed = Settings.shadows
	sh.toggled.connect(func(v): Settings.shadows = v)
	_row(box, "Sombras (vale na próxima partida)", sh)
	var vd := HSlider.new()
	vd.min_value = 48
	vd.max_value = 200
	vd.step = 8
	vd.value = Settings.view_distance
	vd.custom_minimum_size = Vector2(200, 36)
	vd.value_changed.connect(func(v): Settings.view_distance = v)
	_row(box, "Distância de visão", vd)
	var pc := HSlider.new()
	pc.min_value = 10
	pc.max_value = 300
	pc.step = 10
	pc.value = Settings.max_particles
	pc.custom_minimum_size = Vector2(200, 36)
	pc.value_changed.connect(func(v): Settings.max_particles = int(v))
	_row(box, "Limite de partículas", pc)
	var sens := HSlider.new()
	sens.min_value = 0.05
	sens.max_value = 1.0
	sens.step = 0.05
	sens.value = Settings.sensitivity
	sens.custom_minimum_size = Vector2(200, 36)
	sens.value_changed.connect(func(v): Settings.sensitivity = v)
	_row(box, "Sensibilidade", sens)
	var vol := HSlider.new()
	vol.min_value = 0.0
	vol.max_value = 1.0
	vol.step = 0.05
	vol.value = Settings.volume
	vol.custom_minimum_size = Vector2(200, 36)
	vol.value_changed.connect(func(v):
		Settings.volume = v
		Settings.apply())
	_row(box, "Volume", vol)
	var inv := CheckButton.new()
	inv.button_pressed = Settings.invert_y
	inv.toggled.connect(func(v): Settings.invert_y = v)
	_row(box, "Inverter eixo Y", inv)
	var tc := CheckButton.new()
	tc.button_pressed = Settings.touch_controls
	tc.toggled.connect(func(v): Settings.touch_controls = v)
	_row(box, "Controles de toque", tc)
	var fps := CheckButton.new()
	fps.button_pressed = Settings.show_fps
	fps.toggled.connect(func(v): Settings.show_fps = v)
	_row(box, "Mostrar FPS", fps)
	var back := Button.new()
	back.text = "Salvar e voltar"
	back.custom_minimum_size = Vector2(0, 56)
	back.pressed.connect(func():
		Settings.save_settings()
		closed.emit())
	box.add_child(back)


func _row(box: VBoxContainer, text: String, ctl: Control) -> void:
	var h := HBoxContainer.new()
	var l := Label.new()
	l.text = text
	l.custom_minimum_size = Vector2(300, 0)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(l)
	ctl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(ctl)
	box.add_child(h)
