class_name Player
extends CharacterBody3D
## Personagem em blocos. Usado por humanos (local/remoto) e bots.
## - O dono (cliente) simula o movimento e replica net_pos/net_yaw/...
## - Dano, vida, mortes e blocos são decididos pelo servidor (GameController).

const GRAVITY := 24.0
const JUMP_V := 8.2
const EYE_H := 1.55

# ---- dados definidos no spawn
var owner_id := 1
var is_bot := false
var team := 0
var class_id := "soldier"
var display_name := "Jogador"
var ai_mode := "fight"
var ctrl: Node          # GameController
var world: VoxelWorld

# ---- replicado pelo servidor (synchronizer "ServerState")
var hp := 100.0
var max_hp := 100.0
var alive := true
var kills := 0
var deaths := 0
var seat_vehicle := ""
var seat_idx := -1

# ---- replicado pelo dono (synchronizer "OwnerState")
var net_pos := Vector3.ZERO
var net_yaw := 0.0
var net_pitch := 0.0
var net_speed := 0.0
var net_weapon := 0

# ---- comandos (preenchidos por input ou IA)
var cmd_move := Vector2.ZERO
var cmd_jump := false
var cmd_fire := false
var cmd_alt := false

var yaw := 0.0
var pitch := 0.0
var weapons: Array = []
var weapon_idx := 0
var ammo := {}
var cooldown := 0.0
var reload_left := 0.0
var shape_idx := 0
var mat_idx := 0
var brain: Node = null
var look_sens := 1.0

var _col: CollisionShape3D
var _model: Node3D
var _head: Node3D
var _arm_r: Node3D
var _arm_l: Node3D
var _leg_r: Node3D
var _leg_l: Node3D
var _held: MeshInstance3D
var _tag: Label3D
var _cam: Camera3D
var _view: MeshInstance3D
var _view_base := Vector3(0.26, -0.26, -0.5)
var _hl: MeshInstance3D
var _anim_t := 0.0
var _was_alive := true
var _fire_prev := false
var _alt_prev := false
var _body_mat: StandardMaterial3D
var _dead_tilt := 0.0
var shake := 0.0


func is_local() -> bool:
	return (not is_bot) and owner_id == multiplayer.get_unique_id()


func is_controlled_here() -> bool:
	if is_bot:
		return multiplayer.is_server()
	return owner_id == multiplayer.get_unique_id()


func setup_data(d: Dictionary) -> void:
	name = d["name"]
	owner_id = d["owner_id"]
	is_bot = d.get("bot", false)
	team = d["team"]
	class_id = d["class_id"]
	display_name = d["display_name"]
	ai_mode = d.get("ai_mode", "fight")
	position = d["pos"]
	yaw = d.get("yaw", 0.0)
	net_pos = position
	net_yaw = yaw
	_apply_class()


func _apply_class() -> void:
	var c: Dictionary = Game.CLASSES[class_id]
	max_hp = c["hp"]
	hp = max_hp
	weapons = c["weapons"].duplicate()
	ammo.clear()
	for w in weapons:
		ammo[w] = WeaponDB.get_def(w)["mag"]
	weapon_idx = 0
	net_weapon = 0


func _enter_tree() -> void:
	# Autoridade dos synchronizers precisa ser definida aqui (não em _ready).
	_build_sync()


func _ready() -> void:
	add_to_group("players")
	add_to_group("focus")
	floor_snap_length = 0.55
	floor_max_angle = deg_to_rad(50.0)
	_build_body()
	if is_local():
		add_to_group("local_player")
		_build_local_view()
	if multiplayer.is_server() and is_bot:
		var BotBrain := preload("res://scripts/player/BotBrain.gd")
		brain = BotBrain.new()
		brain.player = self
		add_child(brain)
	global_position = position
	net_pos = position


func _build_body() -> void:
	_col = CollisionShape3D.new()
	var cs := CapsuleShape3D.new()
	cs.radius = 0.33
	cs.height = 1.7
	_col.shape = cs
	_col.position = Vector3(0, 0.85, 0)
	add_child(_col)
	_model = Node3D.new()
	add_child(_model)
	_body_mat = StandardMaterial3D.new()
	_body_mat.albedo_color = Game.TEAM_COLORS[team]
	var skin := StandardMaterial3D.new()
	skin.albedo_color = Color(0.95, 0.78, 0.6)
	var dark := StandardMaterial3D.new()
	dark.albedo_color = Color(0.18, 0.2, 0.28)
	_box(_model, Vector3(0.5, 0.65, 0.28), Vector3(0, 1.05, 0), _body_mat)
	_head = Node3D.new()
	_head.position = Vector3(0, 1.55, 0)
	_model.add_child(_head)
	_box(_head, Vector3(0.36, 0.36, 0.36), Vector3.ZERO, skin)
	_box(_head, Vector3(0.38, 0.12, 0.38), Vector3(0, 0.16, 0), _body_mat)
	_arm_r = _limb(Vector3(0.33, 1.34, 0), Vector3(0.16, 0.6, 0.16), _body_mat)
	_arm_l = _limb(Vector3(-0.33, 1.34, 0), Vector3(0.16, 0.6, 0.16), _body_mat)
	_leg_r = _limb(Vector3(0.13, 0.72, 0), Vector3(0.2, 0.72, 0.2), dark)
	_leg_l = _limb(Vector3(-0.13, 0.72, 0), Vector3(0.2, 0.72, 0.2), dark)
	_held = MeshInstance3D.new()
	_arm_r.add_child(_held)
	_tag = Label3D.new()
	_tag.text = display_name
	_tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_tag.position = Vector3(0, 2.15, 0)
	_tag.pixel_size = 0.006
	_tag.no_depth_test = true
	_tag.modulate = Game.TEAM_COLORS[team].lightened(0.3)
	_tag.outline_size = 6
	add_child(_tag)
	_update_held()


func _box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi


func _limb(pivot_pos: Vector3, size: Vector3, mat: Material) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = pivot_pos
	_model.add_child(pivot)
	_box(pivot, size, Vector3(0, -size.y * 0.5 + 0.08, 0), mat)
	return pivot


func _update_held() -> void:
	if weapons.is_empty():
		return
	var def := WeaponDB.get_def(weapons[weapon_idx])
	var bm := BoxMesh.new()
	bm.size = Vector3(0.08, 0.1, float(def["len"]))
	_held.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = def["color"]
	_held.material_override = m
	_held.position = Vector3(0, -0.45, -float(def["len"]) * 0.5 + 0.1)
	if _view != null:
		var vb := BoxMesh.new()
		vb.size = Vector3(0.07, 0.09, float(def["len"]) * 0.7)
		_view.mesh = vb
		_view.material_override = m
		_view_base = Vector3(0.24, -0.24, -0.42 - float(def["len"]) * 0.35)
		_view.position = _view_base


func _build_sync() -> void:
	var s1 := MultiplayerSynchronizer.new()
	s1.name = "ServerState"
	var c1 := SceneReplicationConfig.new()
	for p in ["hp", "max_hp", "alive", "kills", "deaths", "seat_vehicle", "seat_idx"]:
		var np := NodePath(".:" + p)
		c1.add_property(np)
		c1.property_set_replication_mode(np, SceneReplicationConfig.REPLICATION_MODE_ON_CHANGE)
	s1.replication_config = c1
	s1.root_path = NodePath("..")
	s1.set_multiplayer_authority(1)
	add_child(s1)
	var s2 := MultiplayerSynchronizer.new()
	s2.name = "OwnerState"
	var c2 := SceneReplicationConfig.new()
	for p in ["net_pos", "net_yaw", "net_pitch", "net_speed", "net_weapon"]:
		var np := NodePath(".:" + p)
		c2.add_property(np)
		c2.property_set_replication_mode(np, SceneReplicationConfig.REPLICATION_MODE_ALWAYS)
	s2.replication_config = c2
	s2.root_path = NodePath("..")
	s2.replication_interval = 0.05
	s2.set_multiplayer_authority(1 if is_bot else owner_id)
	add_child(s2)


func _build_local_view() -> void:
	_cam = Camera3D.new()
	_cam.top_level = true
	_cam.fov = 78.0
	_cam.near = 0.05
	_cam.far = 400.0
	add_child(_cam)
	_cam.make_current()
	_view = MeshInstance3D.new()
	_cam.add_child(_view)
	_view.position = _view_base
	_model.visible = false
	_tag.visible = false
	_hl = MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3.ONE * 1.02
	_hl.mesh = bm
	var hm := StandardMaterial3D.new()
	hm.albedo_color = Color(1, 1, 1, 0.3)
	hm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	hm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_hl.material_override = hm
	_hl.top_level = true
	_hl.visible = false
	_hl.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_hl)
	_update_held()


# ------------------------------------------------------------------ entrada

func _unhandled_input(event: InputEvent) -> void:
	if not is_local() or not alive:
		return
	if ctrl != null and ctrl.ui_blocking:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		var m := event as InputEventMouseMotion
		add_look(m.relative)
	elif event is InputEventMouseButton and (event as InputEventMouseButton).pressed:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			cycle_weapon(-1)
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			cycle_weapon(1)


func add_look(rel: Vector2) -> void:
	var s := Settings.sensitivity * 0.012
	yaw -= rel.x * s
	var inv := -1.0 if Settings.invert_y else 1.0
	pitch = clampf(pitch - rel.y * s * inv, deg_to_rad(-85.0), deg_to_rad(85.0))


func cycle_weapon(dir: int) -> void:
	select_weapon(posmod(weapon_idx + dir, weapons.size()))


func select_weapon(i: int) -> void:
	if i < 0 or i >= weapons.size() or i == weapon_idx:
		return
	weapon_idx = i
	net_weapon = i
	reload_left = 0.0
	_update_held()


func _gather_input() -> void:
	if ctrl != null and ctrl.ui_blocking:
		cmd_move = Vector2.ZERO
		cmd_jump = false
		cmd_fire = false
		cmd_alt = false
		return
	cmd_move = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	cmd_jump = Input.is_action_pressed("jump")
	cmd_fire = Input.is_action_pressed("fire")
	cmd_alt = Input.is_action_pressed("alt_fire")
	for i in 4:
		if Input.is_action_just_pressed("slot_%d" % (i + 1)):
			select_weapon(i)
	if Input.is_action_just_pressed("build_mode"):
		select_weapon(weapons.size() - 1)
	if Input.is_action_just_pressed("reload"):
		start_reload()
	if Input.is_action_just_pressed("next_material"):
		mat_idx = (mat_idx + 1) % Blocks.BUILDABLE.size()
	if Input.is_action_just_pressed("next_shape"):
		shape_idx = (shape_idx + 1) % WeaponDB.BUILD_SHAPES.size()
	if Input.is_action_just_pressed("interact"):
		interact()


# ------------------------------------------------------------------ física

func _physics_process(delta: float) -> void:
	if alive != _was_alive:
		_was_alive = alive
		_on_alive_changed()
	if not alive:
		_dead_tilt = minf(_dead_tilt + delta * 3.0, 1.0)
		_model.rotation.x = -_dead_tilt * PI * 0.5
		if is_controlled_here():
			velocity = Vector3.ZERO
		_remote_follow(delta)
		_update_camera()
		return
	_model.rotation.x = 0.0
	if seat_vehicle != "":
		_seated(delta)
		return
	_col.disabled = false
	if is_controlled_here():
		if is_local():
			_gather_input()
		elif brain != null:
			brain.think(delta)
		_simulate(delta)
		_handle_weapon(delta)
		net_pos = global_position
		net_yaw = yaw
		net_pitch = pitch
		net_speed = Vector2(velocity.x, velocity.z).length()
	else:
		_remote_follow(delta)
	_animate(delta)
	_update_camera()


func _remote_follow(delta: float) -> void:
	if is_controlled_here():
		return
	if global_position.distance_to(net_pos) > 8.0:
		global_position = net_pos
	else:
		global_position = global_position.lerp(net_pos, clampf(delta * 14.0, 0.0, 1.0))
	yaw = lerp_angle(yaw, net_yaw, clampf(delta * 14.0, 0.0, 1.0))
	pitch = lerpf(pitch, net_pitch, clampf(delta * 14.0, 0.0, 1.0))
	if net_weapon != weapon_idx and net_weapon < weapons.size():
		weapon_idx = net_weapon
		_update_held()


func _simulate(delta: float) -> void:
	if world != null and not world.collision_ready_at(global_position):
		velocity = Vector3.ZERO
		return
	var spd: float = Game.CLASSES[class_id]["speed"]
	var basis_y := Basis(Vector3.UP, yaw)
	var wish := basis_y * Vector3(cmd_move.x, 0, cmd_move.y)
	if wish.length() > 1.0:
		wish = wish.normalized()
	var accel := 40.0 if is_on_floor() else 12.0
	var target := wish * spd
	velocity.x = move_toward(velocity.x, target.x, accel * delta)
	velocity.z = move_toward(velocity.z, target.z, accel * delta)
	if is_on_floor():
		if cmd_jump:
			velocity.y = JUMP_V
			if is_local():
				Sfx.play("jump")
		else:
			velocity.y = -1.0
	else:
		velocity.y -= GRAVITY * delta
	# subir degraus de 1 bloco sem precisar pular
	if is_on_floor() and wish.length() > 0.1:
		var probe := wish.normalized() * 0.3
		if test_move(global_transform, probe) and not test_move(global_transform.translated(Vector3(0, 1.02, 0)), probe):
			global_position.y += 1.0
	move_and_slide()
	if global_position.y < -15.0 and multiplayer.is_server():
		ctrl.server_damage(name, 9999.0, "", "void")


func _seated(delta: float) -> void:
	_col.disabled = true
	velocity = Vector3.ZERO
	var v: Node3D = ctrl.get_vehicle(seat_vehicle) if ctrl != null else null
	if v == null:
		return
	global_position = v.call("seat_global", seat_idx)
	net_pos = global_position
	if is_controlled_here() and is_local():
		_gather_input()
		if seat_idx == 0:
			v.call("set_inputs", Vector2(cmd_move.x, -cmd_move.y), yaw, pitch, cmd_fire)
	_head.rotation = Vector3.ZERO
	_model.rotation.y = v.rotation.y if seat_idx >= 0 else yaw
	if is_local():
		net_yaw = yaw
		net_pitch = pitch
	_arm_r.rotation.x = -0.4
	_arm_l.rotation.x = -0.4
	_leg_r.rotation.x = -1.4
	_leg_l.rotation.x = -1.4
	_update_camera()


func _on_alive_changed() -> void:
	if alive:
		_dead_tilt = 0.0
		_model.rotation.x = 0.0
		_tag.visible = not is_local()
		if is_local():
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if not Settings.touch_controls else Input.MOUSE_MODE_VISIBLE
		_apply_class()
		_update_held()
	else:
		cmd_fire = false
		_tag.visible = false


func teleport(pos: Vector3, new_yaw: float) -> void:
	global_position = pos
	position = pos
	net_pos = pos
	velocity = Vector3.ZERO
	yaw = new_yaw
	net_yaw = new_yaw


# ------------------------------------------------------------------ câmera / animação

func eye_pos() -> Vector3:
	return global_position + Vector3(0, EYE_H, 0)


func aim_dir() -> Vector3:
	return Basis(Vector3.UP, yaw) * Basis(Vector3.RIGHT, pitch) * Vector3(0, 0, -1)


func _update_camera() -> void:
	if _cam == null:
		return
	var b := Basis(Vector3.UP, yaw) * Basis(Vector3.RIGHT, pitch)
	if seat_vehicle != "" and alive:
		var v: Node3D = ctrl.get_vehicle(seat_vehicle)
		if v != null:
			var back: Vector3 = b * Vector3(0, 0, 1)
			var focus: Vector3 = v.global_position + Vector3(0, 2.2, 0)
			var dist := 9.0
			var want := focus + back * dist
			var hit := world.raycast(focus, back, dist)
			if not hit.is_empty():
				want = focus + back * maxf(float(hit["dist"]) - 0.5, 1.0)
			_cam.global_transform = Transform3D(b, want)
			_view.visible = false
			return
	_view.visible = alive and weapons.size() > 0
	if not alive:
		var look := Basis(Vector3.UP, yaw) * Basis(Vector3.RIGHT, -0.9)
		_cam.global_transform = Transform3D(look, global_position + Vector3(0, 3.5, 0) + look * Vector3(0, 0, 3.0))
		return
	var cam_pos := eye_pos()
	if shake > 0.01:
		shake = lerpf(shake, 0.0, 0.08)
		cam_pos += Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)) * shake * 0.25
	_cam.global_transform = Transform3D(b, cam_pos)


func _animate(delta: float) -> void:
	_model.rotation.y = yaw
	_head.rotation.x = pitch
	var spd := net_speed if not is_controlled_here() else Vector2(velocity.x, velocity.z).length()
	_anim_t += delta * (4.0 + spd * 1.2)
	var sw := sin(_anim_t) * clampf(spd / 6.0, 0.0, 1.0) * 0.9
	_leg_r.rotation.x = sw
	_leg_l.rotation.x = -sw
	_arm_l.rotation.x = -sw * 0.6
	var kind: String = WeaponDB.get_def(weapons[weapon_idx])["kind"] if weapons.size() > 0 else "melee"
	if kind == "melee" or kind == "build":
		_arm_r.rotation.x = sw * 0.6 - (0.8 if cooldown > 0.0 else 0.0)
	else:
		_arm_r.rotation.x = -1.35 + pitch
	if _view != null:
		_view.position = _view.position.lerp(_view_base + Vector3(0, sin(_anim_t * 2.0) * 0.01 * clampf(spd, 0, 1), 0), delta * 12.0)


# ------------------------------------------------------------------ armas / construção

func current_weapon() -> String:
	return weapons[weapon_idx]


func start_reload() -> void:
	var def := WeaponDB.get_def(current_weapon())
	if def["mag"] <= 0 or reload_left > 0.0 or ammo[current_weapon()] >= def["mag"]:
		return
	reload_left = def["reload"]


func _handle_weapon(delta: float) -> void:
	cooldown -= delta
	var wid := current_weapon()
	var def := WeaponDB.get_def(wid)
	if reload_left > 0.0:
		reload_left -= delta
		if reload_left <= 0.0:
			ammo[wid] = def["mag"]
		_fire_prev = cmd_fire
		_alt_prev = cmd_alt
		return
	var kind: String = def["kind"]
	if kind == "build":
		_handle_build()
	else:
		if _hl != null:
			_hl.visible = false
		if cmd_fire and cooldown <= 0.0:
			_fire(wid, def)
	_fire_prev = cmd_fire
	_alt_prev = cmd_alt


func _fire(wid: String, def: Dictionary) -> void:
	if def["mag"] > 0:
		if ammo[wid] <= 0:
			start_reload()
			return
		if not ctrl.infinite_ammo and not is_bot:
			ammo[wid] -= 1
	cooldown = def["rate"]
	var origin := eye_pos()
	var dir := aim_dir()
	if is_bot:
		dir = brain.aim_with_error(dir) if brain != null else dir
	ctrl.request_fire(name, wid, origin, dir)
	Sfx.play(def["sound"], global_position)
	ctrl.fx.muzzle(origin + dir * 0.8)
	if _view != null:
		_view.position += Vector3(0, 0.02, 0.12)
		if def["kind"] == "projectile":
			_view.position += Vector3(0, 0.0, 0.1)


func _handle_build() -> void:
	var def := WeaponDB.get_def("builder")
	var hit := world.raycast(eye_pos(), aim_dir(), def["range"])
	if _hl != null:
		_hl.visible = not hit.is_empty()
		if not hit.is_empty():
			var cell: Vector3i = hit["pos"] + hit["normal"]
			_hl.global_position = Vector3(cell) + Vector3(0.5, 0.5, 0.5)
			_hl.global_basis = Basis.IDENTITY
	if hit.is_empty() or cooldown > 0.0:
		return
	if cmd_fire:
		var cell: Vector3i = hit["pos"] + hit["normal"]
		cooldown = def["rate"]
		ctrl.request_build(name, shape_idx, Blocks.BUILDABLE[mat_idx], cell, yaw)
		_view.position += Vector3(0, -0.03, 0.08)
	elif cmd_alt:
		cooldown = def["rate"]
		ctrl.request_unbuild(name, hit["pos"])


func interact() -> void:
	if not alive:
		return
	if seat_vehicle != "":
		ctrl.request_exit(name)
		return
	var best: Node3D = null
	var bd := 6.0
	for v in get_tree().get_nodes_in_group("vehicles"):
		if (v as Vehicle).dead:
			continue
		var d := (v as Node3D).global_position.distance_to(global_position)
		if d < bd:
			bd = d
			best = v
	if best != null:
		ctrl.request_enter(name, best.name)
