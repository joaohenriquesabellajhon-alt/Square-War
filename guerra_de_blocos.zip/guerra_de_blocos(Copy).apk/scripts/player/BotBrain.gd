extends Node
## IA simples dos bots (roda só no servidor). Escolhe alvo, persegue, atira e
## abre caminho atirando em paredes quando fica preso.

var player: Player
var target: Player = null
var _think_t := 0.0
var _strafe := 1.0
var _strafe_t := 0.0
var _stuck_t := 0.0
var _last_pos := Vector3.ZERO
var _goal := Vector3.ZERO
var _has_los := false
var skill := 0.6   # 0..1, afeta a precisão


func _ready() -> void:
	skill = randf_range(0.4, 0.8)
	_last_pos = player.global_position


func aim_with_error(dir: Vector3) -> Vector3:
	var err := (1.0 - skill) * 0.06
	return (dir + Vector3(randf_range(-err, err), randf_range(-err, err), randf_range(-err, err))).normalized()


func think(delta: float) -> void:
	var p := player
	p.cmd_move = Vector2.ZERO
	p.cmd_jump = false
	p.cmd_fire = false
	if p.ai_mode == "dummy" or not p.alive:
		return
	_think_t -= delta
	if _think_t <= 0.0:
		_think_t = 0.25
		_pick_target()
	_strafe_t -= delta
	if _strafe_t <= 0.0:
		_strafe_t = randf_range(0.8, 2.2)
		_strafe = -_strafe if randf() < 0.5 else _strafe
	var kind: String = WeaponDB.get_def(p.current_weapon())["kind"]
	var move_to := _goal
	var desired_dist := 14.0
	if p.ai_mode == "zombie":
		desired_dist = 1.8
	var aim_pos := Vector3.INF
	if target != null and is_instance_valid(target) and target.alive:
		aim_pos = target.global_position + Vector3(0, 1.2, 0)
		move_to = target.global_position
	var to_goal := move_to - p.global_position
	to_goal.y = 0.0
	var dist := to_goal.length()
	if aim_pos != Vector3.INF:
		var d := aim_pos - p.eye_pos()
		p.yaw = lerp_angle(p.yaw, atan2(-d.x, -d.z), clampf(delta * 8.0, 0.0, 1.0))
		p.pitch = lerpf(p.pitch, asin(clampf(d.normalized().y, -1.0, 1.0)), clampf(delta * 8.0, 0.0, 1.0))
		var aligned := absf(angle_difference(p.yaw, atan2(-d.x, -d.z))) < 0.25
		var rng: float = WeaponDB.get_def(p.current_weapon())["range"]
		if _has_los and aligned and d.length() < minf(rng, 55.0):
			p.cmd_fire = true
		if p.ai_mode == "zombie" and d.length() < 3.0:
			p.cmd_fire = true
	elif dist > 1.0:
		p.yaw = lerp_angle(p.yaw, atan2(-to_goal.x, -to_goal.z), clampf(delta * 5.0, 0.0, 1.0))
	if dist > desired_dist or aim_pos == Vector3.INF:
		p.cmd_move = Vector2(0, -1)
	elif dist < desired_dist * 0.5 and p.ai_mode != "zombie":
		p.cmd_move = Vector2(_strafe, 0.6)
	else:
		p.cmd_move = Vector2(_strafe, 0)
	# preso? pula e abre caminho atirando
	if p.cmd_move.length() > 0.1:
		var moved := p.global_position.distance_to(_last_pos)
		_stuck_t += delta
		if _stuck_t > 0.4:
			if moved < 0.25:
				p.cmd_jump = true
				if _stuck_t > 1.2:
					p.pitch = lerpf(p.pitch, -0.05, 0.3)
					p.cmd_fire = true
			else:
				_stuck_t = 0.0
			_last_pos = p.global_position
			if moved >= 0.25:
				_stuck_t = 0.0
		if _stuck_t > 3.0:
			_stuck_t = 0.0
			_strafe = -_strafe
	if p.is_on_wall():
		p.cmd_jump = true
	# troca para a arma principal com munição
	if p.weapon_idx != 0 and kind != "hitscan" and p.ai_mode != "zombie":
		p.select_weapon(0)
	if p.ai_mode == "zombie" and p.weapon_idx != 2:
		p.select_weapon(2)


func _pick_target() -> void:
	var p := player
	var best: Player = null
	var bd := 70.0
	_has_los = false
	for o in get_tree().get_nodes_in_group("players"):
		var q := o as Player
		if q == p or not q.alive or q.team == p.team or q.seat_vehicle != "" and false:
			continue
		var d := q.global_position.distance_to(p.global_position)
		if d < bd:
			bd = d
			best = q
	target = best
	if target != null:
		var from := p.eye_pos()
		var to := target.global_position + Vector3(0, 1.2, 0)
		var hit := p.world.raycast(from, to - from, from.distance_to(to))
		_has_los = hit.is_empty()
	_goal = p.ctrl.bot_goal(p)
