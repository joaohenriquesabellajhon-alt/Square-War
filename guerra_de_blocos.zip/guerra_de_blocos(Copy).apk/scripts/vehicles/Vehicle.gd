class_name Vehicle
extends CharacterBody3D
## Veículos terrestres com física arcade (jipe, caminhão de transporte e tanque).
## A autoridade de movimento é do motorista; sem motorista, do servidor.

const DEFS := {
	"jeep": {"name": "Jipe", "size": Vector3(2.0, 1.0, 3.6), "speed": 17.0, "accel": 20.0, "turn": 1.9, "hp": 160.0,
		"seats": [Vector3(-0.5, 0.5, 0.3), Vector3(0.5, 0.5, 0.3)], "color": Color(0.35, 0.45, 0.25)},
	"truck": {"name": "Caminhão", "size": Vector3(2.4, 1.4, 5.4), "speed": 12.0, "accel": 12.0, "turn": 1.4, "hp": 260.0,
		"seats": [Vector3(-0.6, 0.9, -1.4), Vector3(0.6, 0.9, -1.4), Vector3(-0.7, 0.9, 0.8), Vector3(0.7, 0.9, 0.8),
			Vector3(-0.7, 0.9, 1.9), Vector3(0.7, 0.9, 1.9)], "color": Color(0.5, 0.42, 0.25)},
	"tank": {"name": "Tanque", "size": Vector3(2.8, 1.3, 4.2), "speed": 8.0, "accel": 10.0, "turn": 1.3, "hp": 520.0,
		"seats": [Vector3(0, 1.2, 0.5), Vector3(0, 1.9, 1.5)], "color": Color(0.3, 0.38, 0.3)},
}

var kind := "jeep"
var ctrl: Node
var world: VoxelWorld
var home_pos := Vector3.ZERO
var home_yaw := 0.0

# replicado pelo servidor
var hp := 100.0
var dead := false
var driver_peer := 0

# replicado pelo motorista/servidor
var net_pos := Vector3.ZERO
var net_yaw := 0.0
var net_turret := 0.0
var net_barrel := 0.0

var yaw := 0.0
var speed := 0.0
var in_steer := 0.0
var in_throttle := 0.0
var in_aim_yaw := 0.0
var in_aim_pitch := 0.0
var in_fire := false
var _fire_cd := 0.0
var _last_input_t := 0.0
var _turret: Node3D
var _barrel: Node3D
var _model: Node3D
var _col: CollisionShape3D
var _sync_pos: MultiplayerSynchronizer
var _def: Dictionary
var _wheels: Array[Node3D] = []


func setup_data(d: Dictionary) -> void:
	name = d["name"]
	kind = d["vkind"]
	_def = DEFS[kind]
	hp = _def["hp"]
	position = d["pos"]
	home_pos = d["pos"]
	yaw = d["yaw"]
	home_yaw = yaw
	rotation.y = yaw
	net_pos = position
	net_yaw = yaw


func _enter_tree() -> void:
	# Autoridade dos synchronizers precisa ser definida aqui (não em _ready).
	_build_sync()


func _ready() -> void:
	add_to_group("vehicles")
	add_to_group("focus")
	floor_snap_length = 0.6
	floor_max_angle = deg_to_rad(50.0)
	var size: Vector3 = _def["size"]
	_col = CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	_col.shape = bs
	_col.position = Vector3(0, size.y * 0.5 + 0.15, 0)
	add_child(_col)
	_build_model(size)


func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	return m


func _bx(parent: Node3D, size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi


func _build_model(size: Vector3) -> void:
	_model = Node3D.new()
	add_child(_model)
	var body: Color = _def["color"]
	var bm := _mat(body)
	var dark := _mat(Color(0.12, 0.12, 0.14))
	var glass := _mat(Color(0.5, 0.75, 0.9))
	match kind:
		"jeep":
			_bx(_model, Vector3(2.0, 0.5, 3.6), Vector3(0, 0.6, 0), bm)
			_bx(_model, Vector3(1.8, 0.1, 1.2), Vector3(0, 1.3, 0.5), bm)
			_bx(_model, Vector3(1.8, 0.5, 0.1), Vector3(0, 1.05, -0.6), glass)
			_bx(_model, Vector3(0.1, 0.5, 1.2), Vector3(-0.95, 1.05, 0.5), bm)
			_bx(_model, Vector3(0.1, 0.5, 1.2), Vector3(0.95, 1.05, 0.5), bm)
			_add_wheels(1.0, 1.2, 0.35, dark)
		"truck":
			_bx(_model, Vector3(2.2, 1.4, 1.6), Vector3(0, 1.1, -1.8), bm)
			_bx(_model, Vector3(2.0, 0.6, 0.1), Vector3(0, 1.5, -2.6), glass)
			_bx(_model, Vector3(2.4, 0.3, 3.4), Vector3(0, 0.55, 1.0), dark)
			_bx(_model, Vector3(2.4, 1.0, 0.15), Vector3(0, 1.2, 2.65), bm)
			_bx(_model, Vector3(0.15, 1.0, 3.4), Vector3(-1.15, 1.2, 1.0), bm)
			_bx(_model, Vector3(0.15, 1.0, 3.4), Vector3(1.15, 1.2, 1.0), bm)
			_add_wheels(1.1, 1.8, 0.45, dark)
		"tank":
			_bx(_model, Vector3(2.4, 0.8, 4.0), Vector3(0, 0.75, 0), bm)
			_bx(_model, Vector3(0.5, 0.8, 4.2), Vector3(-1.3, 0.55, 0), dark)
			_bx(_model, Vector3(0.5, 0.8, 4.2), Vector3(1.3, 0.55, 0), dark)
			_turret = Node3D.new()
			_turret.position = Vector3(0, 1.5, 0.2)
			_model.add_child(_turret)
			_bx(_turret, Vector3(1.7, 0.7, 2.0), Vector3.ZERO, bm)
			_barrel = Node3D.new()
			_barrel.position = Vector3(0, 0.1, -1.0)
			_turret.add_child(_barrel)
			_bx(_barrel, Vector3(0.22, 0.22, 2.6), Vector3(0, 0, -1.3), dark)
	_bx(_model, Vector3(0.5, 0.25, 0.1), Vector3(0, 1.0 if kind != "tank" else 1.25, -size.z * 0.5 + 0.02), _mat(Color(0.9, 0.9, 0.2)))


func _add_wheels(x: float, z: float, r: float, mat: Material) -> void:
	for sx in [-1, 1]:
		for sz in [-1, 1]:
			var w := _bx(_model, Vector3(0.3, r * 2.0, r * 2.0), Vector3(sx * x, r, sz * z), mat)
			_wheels.append(w)


func seat_global(i: int) -> Vector3:
	var seats: Array = _def["seats"]
	return global_transform * (seats[clampi(i, 0, seats.size() - 1)] as Vector3)


func seat_count() -> int:
	return (_def["seats"] as Array).size()


func set_inputs(move: Vector2, aim_yaw: float, aim_pitch: float, fire: bool) -> void:
	in_steer = move.x
	in_throttle = move.y
	in_aim_yaw = aim_yaw
	in_aim_pitch = aim_pitch
	in_fire = fire
	_last_input_t = 0.0


func _controlled_here() -> bool:
	if driver_peer > 0:
		return driver_peer == multiplayer.get_unique_id()
	return multiplayer.is_server()


func _physics_process(delta: float) -> void:
	var want := driver_peer if driver_peer > 0 else 1
	if _sync_pos.get_multiplayer_authority() != want:
		_sync_pos.set_multiplayer_authority(want)
	_model.visible = not dead
	_col.disabled = dead
	if dead:
		return
	_last_input_t += delta
	if _controlled_here():
		_simulate(delta)
		net_pos = global_position
		net_yaw = yaw
		net_turret = _turret_world_yaw()
		net_barrel = in_aim_pitch if driver_peer > 0 else net_barrel
	else:
		if global_position.distance_to(net_pos) > 10.0:
			global_position = net_pos
		else:
			global_position = global_position.lerp(net_pos, clampf(delta * 12.0, 0.0, 1.0))
		yaw = lerp_angle(yaw, net_yaw, clampf(delta * 12.0, 0.0, 1.0))
		rotation.y = yaw
	_update_turret(delta)
	_spin_wheels(delta)


func _turret_world_yaw() -> float:
	if _turret == null:
		return yaw
	return yaw + _turret.rotation.y


func _simulate(delta: float) -> void:
	if world != null and not world.collision_ready_at(global_position):
		velocity = Vector3.ZERO
		return
	var driven := driver_peer > 0 and _last_input_t < 0.5
	var throttle := in_throttle if driven else 0.0
	var steer := in_steer if driven else 0.0
	var max_s: float = _def["speed"]
	var acc: float = _def["accel"]
	var target := throttle * (max_s if throttle > 0.0 else max_s * 0.5)
	speed = move_toward(speed, target, (acc if absf(throttle) > 0.01 else acc * 1.6) * delta)
	var turn: float = _def["turn"]
	yaw -= steer * turn * delta * clampf(absf(speed) / 4.0, 0.0, 1.0) * signf(speed)
	rotation.y = yaw
	var fwd := Vector3(-sin(yaw), 0.0, -cos(yaw))
	velocity.x = fwd.x * speed
	velocity.z = fwd.z * speed
	if is_on_floor():
		velocity.y = -1.0
	else:
		velocity.y -= 24.0 * delta
	if is_on_floor() and absf(speed) > 0.5:
		var probe := fwd * signf(speed) * 0.5
		if test_move(global_transform, probe) and not test_move(global_transform.translated(Vector3(0, 1.05, 0)), probe):
			global_position.y += 1.0
	move_and_slide()
	var real := Vector3(get_real_velocity().x, 0.0, get_real_velocity().z)
	speed = clampf(real.dot(fwd), -max_s, max_s) if absf(speed) > 0.1 else speed
	# tanque: disparo
	_fire_cd -= delta
	if kind == "tank" and driven and in_fire and _fire_cd <= 0.0 and driver_peer == multiplayer.get_unique_id():
		_fire_cd = WeaponDB.TANK_GUN["rate"]
		var dir := Basis(Vector3.UP, in_aim_yaw) * Basis(Vector3.RIGHT, in_aim_pitch) * Vector3(0, 0, -1)
		var muzzle := _turret.global_position + dir * 3.2
		ctrl.request_tank_fire(name, muzzle, dir)
		Sfx.play("rocket", muzzle)


func _update_turret(delta: float) -> void:
	if _turret == null:
		return
	var tgt_yaw := in_aim_yaw if (_controlled_here() and driver_peer > 0) else net_turret
	var tgt_pitch := in_aim_pitch if (_controlled_here() and driver_peer > 0) else net_barrel
	var local_yaw := angle_difference(yaw, tgt_yaw)
	_turret.rotation.y = lerp_angle(_turret.rotation.y, local_yaw, clampf(delta * 6.0, 0.0, 1.0))
	_barrel.rotation.x = lerpf(_barrel.rotation.x, clampf(tgt_pitch, -0.2, 0.6), clampf(delta * 6.0, 0.0, 1.0))


func _spin_wheels(delta: float) -> void:
	for w in _wheels:
		w.rotation.x += speed * delta * 1.5


func reset_home() -> void:
	dead = false
	hp = _def["hp"]
	driver_peer = 0
	speed = 0.0
	velocity = Vector3.ZERO
	yaw = home_yaw
	rotation.y = yaw
	global_position = home_pos
	net_pos = home_pos
	net_yaw = yaw


func _build_sync() -> void:
	var s1 := MultiplayerSynchronizer.new()
	s1.name = "ServerState"
	var c1 := SceneReplicationConfig.new()
	for p in ["hp", "dead", "driver_peer"]:
		var np := NodePath(".:" + p)
		c1.add_property(np)
		c1.property_set_replication_mode(np, SceneReplicationConfig.REPLICATION_MODE_ON_CHANGE)
	s1.replication_config = c1
	s1.root_path = NodePath("..")
	s1.set_multiplayer_authority(1)
	add_child(s1)
	_sync_pos = MultiplayerSynchronizer.new()
	_sync_pos.name = "MoveState"
	var c2 := SceneReplicationConfig.new()
	for p in ["net_pos", "net_yaw", "net_turret", "net_barrel"]:
		var np := NodePath(".:" + p)
		c2.add_property(np)
		c2.property_set_replication_mode(np, SceneReplicationConfig.REPLICATION_MODE_ALWAYS)
	_sync_pos.replication_config = c2
	_sync_pos.root_path = NodePath("..")
	_sync_pos.replication_interval = 0.05
	_sync_pos.set_multiplayer_authority(1)
	add_child(_sync_pos)


