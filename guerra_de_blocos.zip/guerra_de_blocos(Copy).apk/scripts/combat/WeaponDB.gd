class_name WeaponDB
extends RefCounted
## Banco de dados de armas e equipamentos (todos fictícios).
## kind: "hitscan" | "projectile" | "melee" | "build"

const W := {
	"rifle": {"name": "Fuzil Pulsar", "kind": "hitscan", "damage": 22.0, "rate": 0.12, "mag": 30,
		"reload": 1.6, "range": 90.0, "spread": 0.012, "pellets": 1, "block_damage": 1.0,
		"sound": "shoot", "color": Color(0.25, 0.25, 0.3), "len": 0.7},
	"pistol": {"name": "Pistola Faísca", "kind": "hitscan", "damage": 18.0, "rate": 0.28, "mag": 12,
		"reload": 1.1, "range": 60.0, "spread": 0.01, "pellets": 1, "block_damage": 1.0,
		"sound": "shoot", "color": Color(0.4, 0.4, 0.45), "len": 0.4},
	"shotgun": {"name": "Escopeta Estilhaço", "kind": "hitscan", "damage": 9.0, "rate": 0.8, "mag": 6,
		"reload": 2.2, "range": 28.0, "spread": 0.07, "pellets": 8, "block_damage": 0.7,
		"sound": "shotgun", "color": Color(0.35, 0.22, 0.12), "len": 0.75},
	"smg": {"name": "Metralhadora Zumbi", "kind": "hitscan", "damage": 12.0, "rate": 0.065, "mag": 40,
		"reload": 1.4, "range": 50.0, "spread": 0.03, "pellets": 1, "block_damage": 0.6,
		"sound": "shoot", "color": Color(0.2, 0.3, 0.2), "len": 0.55},
	"launcher": {"name": "Lança-Foguetes Trovão", "kind": "projectile", "damage": 70.0, "rate": 1.2, "mag": 2,
		"reload": 2.8, "range": 120.0, "spread": 0.0, "pellets": 1, "block_damage": 3.0,
		"radius": 3.6, "speed": 38.0, "sound": "rocket", "color": Color(0.5, 0.2, 0.15), "len": 0.9},
	"pickaxe": {"name": "Picareta", "kind": "melee", "damage": 28.0, "rate": 0.35, "mag": 0,
		"reload": 0.0, "range": 5.0, "spread": 0.0, "pellets": 1, "block_damage": 2.0,
		"sound": "break", "color": Color(0.55, 0.45, 0.3), "len": 0.6},
	"builder": {"name": "Martelo de Construção", "kind": "build", "damage": 0.0, "rate": 0.18, "mag": 0,
		"reload": 0.0, "range": 8.0, "spread": 0.0, "pellets": 1, "block_damage": 0.0,
		"sound": "place", "color": Color(0.9, 0.7, 0.2), "len": 0.5},
}

## Formas de construção.
const BUILD_SHAPES := ["Bloco", "Parede", "Ponte", "Barricada"]

## Armas dos veículos.
const TANK_GUN := {"name": "Canhão do Tanque", "damage": 110.0, "radius": 4.8, "speed": 55.0,
	"block_damage": 6.0, "rate": 1.6}


static func get_def(id: String) -> Dictionary:
	return W[id]
