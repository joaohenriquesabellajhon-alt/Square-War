class_name Rocket
extends Node3D
## Projétil de foguete/obus. Simulado de forma idêntica em todos os peers
## (mesma posição e velocidade inicial), mas só o servidor decide a explosão.

var rid := 0
var velocity := Vector3.ZERO
var shooter := ""
var weapon := "launcher"
var gravity := 4.0
var life := 6.0
var world: VoxelWorld
var ctrl: Node
var exploded := false


func _ready() -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.18, 0.18, 0.6)
	mi.mesh = bm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1.0, 0.6, 0.2)
	mat.emission_enabled = true
	mat.emission = Color(1.0, 0.45, 0.1)
	mi.material_override = mat
	add_child(mi)
	var l := OmniLight3D.new()
	l.light_color = Color(1.0, 0.6, 0.2)
	l.omni_range = 6.0
	l.light_energy = 1.2
	add_child(l)


func _physics_process(delta: float) -> void:
	if exploded:
		return
	var step := velocity * delta
	var dist := step.length()
	velocity.y -= gravity * delta
	life -= delta
	var hit_pos := Vector3.INF
	if world != null and dist > 0.0:
		var r := world.raycast(global_position, step, dist + 0.05)
		if not r.is_empty():
			hit_pos = global_position + step.normalized() * maxf(float(r["dist"]) - 0.1, 0.0)
	if hit_pos == Vector3.INF and multiplayer.is_server() and ctrl != null:
		var victim: Node3D = ctrl.rocket_hits_entity(global_position, step, shooter)
		if victim != null:
			hit_pos = victim.global_position + Vector3.UP
	if hit_pos != Vector3.INF:
		if multiplayer.is_server() and ctrl != null:
			exploded = true
			ctrl.server_explosion(rid, hit_pos, weapon, shooter)
		else:
			global_position = hit_pos
			set_physics_process(false)  # espera a explosão chegar do servidor
		return
	global_position += step
	if step.length() > 0.001:
		look_at(global_position + step, Vector3.UP)
	if life <= 0.0 and multiplayer.is_server() and ctrl != null:
		exploded = true
		ctrl.server_explosion(rid, global_position, weapon, shooter)
