class_name Effects
extends Node3D
## Efeitos visuais com pool: partículas de quebra, explosões, faíscas e fragmentos
## de blocos. Respeita o limite de partículas das configurações (Android).

const POOL := 24

var _bursts: Array[CPUParticles3D] = []
var _bi := 0
var _debris_mesh: BoxMesh
var _debris_mats := {}
var _flash: OmniLight3D
var _flash_t := 0.0
var active_debris := 0


func _ready() -> void:
	_debris_mesh = BoxMesh.new()
	_debris_mesh.size = Vector3.ONE * 0.9
	for i in POOL:
		var p := CPUParticles3D.new()
		p.emitting = false
		p.one_shot = true
		p.explosiveness = 1.0
		p.lifetime = 0.7
		p.direction = Vector3.UP
		p.spread = 90.0
		p.gravity = Vector3(0, -14, 0)
		p.initial_velocity_min = 2.0
		p.initial_velocity_max = 6.0
		p.scale_amount_min = 0.5
		p.scale_amount_max = 1.0
		var m := BoxMesh.new()
		m.size = Vector3.ONE * 0.18
		p.mesh = m
		var mat := StandardMaterial3D.new()
		mat.vertex_color_use_as_albedo = true
		mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.material = mat
		add_child(p)
		_bursts.append(p)
	_flash = OmniLight3D.new()
	_flash.light_energy = 0.0
	_flash.omni_range = 14.0
	_flash.light_color = Color(1.0, 0.7, 0.3)
	_flash.shadow_enabled = false
	add_child(_flash)


func _process(delta: float) -> void:
	if _flash_t > 0.0:
		_flash_t -= delta
		_flash.light_energy = maxf(_flash_t, 0.0) * 12.0


func _burst(pos: Vector3, color: Color, amount: int, vmin: float, vmax: float, life: float, spread := 180.0, size := 1.0) -> void:
	var p := _bursts[_bi]
	_bi = (_bi + 1) % POOL
	var cap := maxi(4, int(Settings.max_particles * 0.25))
	p.amount = mini(amount, cap)
	p.global_position = pos
	p.color = color
	p.lifetime = life
	p.initial_velocity_min = vmin
	p.initial_velocity_max = vmax
	p.spread = spread
	p.scale_amount_min = 0.6 * size
	p.scale_amount_max = 1.0 * size
	p.restart()
	p.emitting = true


func block_break(pos: Vector3, id: int) -> void:
	_burst(pos + Vector3(0.5, 0.5, 0.5), Blocks.COLORS[id], 12, 2.0, 6.0, 0.7)


func hit_spark(pos: Vector3, color := Color(1, 0.9, 0.5)) -> void:
	_burst(pos, color, 5, 1.0, 3.0, 0.25)


func explosion(pos: Vector3, radius: float) -> void:
	_burst(pos, Color(1.0, 0.55, 0.15), 26, 4.0, 11.0, 0.8, 180.0, 3.0)
	_burst(pos, Color(0.35, 0.35, 0.35), 18, 1.0, 5.0, 1.1, 180.0, 3.5)
	_fireball(pos, radius)
	_flash.global_position = pos + Vector3.UP
	_flash.light_energy = 12.0
	_flash_t = 0.5
	Sfx.play("explosion", pos)


## Bola de fogo estilizada: esfera emissiva que cresce e some (1 nó por explosão).
func _fireball(pos: Vector3, radius: float) -> void:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 1.0
	sm.height = 2.0
	sm.radial_segments = 10
	sm.rings = 6
	mi.mesh = sm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1.0, 0.65, 0.2, 0.9)
	mat.emission_enabled = true
	mat.emission = Color(1.0, 0.5, 0.1)
	mat.emission_energy_multiplier = 2.0
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	mi.global_position = pos
	mi.scale = Vector3.ONE * 0.4
	var tw := mi.create_tween()
	tw.set_parallel(true)
	tw.tween_property(mi, "scale", Vector3.ONE * radius * 0.9, 0.35).set_ease(Tween.EASE_OUT)
	tw.tween_property(mat, "albedo_color:a", 0.0, 0.4)
	tw.chain().tween_callback(mi.queue_free)


func muzzle(pos: Vector3) -> void:
	_flash.global_position = pos
	_flash.light_energy = 4.0
	_flash_t = 0.08


## Fragmentos de blocos caindo (desabamento / explosão). Limitados por qualidade.
func debris(cells: Array, from_pos: Vector3) -> void:
	var max_debris := int(Settings.max_particles * 0.4)
	var step := maxi(1, cells.size() / maxi(max_debris, 1))
	var i := 0
	for c in cells:
		i += 1
		if i % step != 0 or active_debris >= max_debris:
			continue
		var cell: Dictionary = c
		var mi := MeshInstance3D.new()
		mi.mesh = _debris_mesh
		var id: int = cell["id"]
		if not _debris_mats.has(id):
			var mat := StandardMaterial3D.new()
			mat.albedo_color = Blocks.COLORS[id]
			_debris_mats[id] = mat
		mi.material_override = _debris_mats[id]
		add_child(mi)
		var p: Vector3 = cell["pos"] + Vector3(0.5, 0.5, 0.5)
		mi.global_position = p
		active_debris += 1
		var away := (p - from_pos).normalized() * randf_range(1.0, 4.0)
		var end := p + away + Vector3(0, -randf_range(3.0, 9.0), 0)
		var tw := mi.create_tween()
		tw.set_parallel(true)
		tw.tween_property(mi, "global_position", end, 0.8).set_ease(Tween.EASE_IN)
		tw.tween_property(mi, "scale", Vector3.ONE * 0.1, 0.8)
		tw.tween_property(mi, "rotation", Vector3(randf() * 6.0, randf() * 6.0, randf() * 6.0), 0.8)
		tw.chain().tween_callback(func():
			active_debris -= 1
			mi.queue_free())
