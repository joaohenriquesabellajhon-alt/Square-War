class_name GameController
extends Node3D
## Controlador da partida. Roda em todos os peers; o servidor (ou o jogador offline,
## que é o próprio servidor) é a autoridade de: dano, mortes, blocos, construção,
## veículos, pontuação e modos de jogo. Clientes enviam pedidos (_srv_*) e recebem
## eventos (_cl_*).

signal killfeed(text: String)
signal hit_marker()
signal local_damaged(amount: float)
signal message(text: String)
signal match_over(text: String)
signal state_changed()

const WIN_KILLS := 30
const WIN_POINTS := 150
const CAPTURE_RADIUS := 6.5
const SYNC_BATCH := 1500

var world: VoxelWorld
var fx: Effects
var players_root: Node3D
var vehicles_root: Node3D
var rockets_root: Node3D
var p_spawner: MultiplayerSpawner
var v_spawner: MultiplayerSpawner
var sun: DirectionalLight3D
var env: Environment
var ui_blocking := false
var infinite_ammo := false
var unlimited_build := false
var friendly_fire := false
var finished := false

# estado replicado (_cl_state)
var team_scores := [0, 0]
var points: Array = []          # {pos, owner, prog, node, flag}
var wave := 0
var wave_info := ""
var training_hits := 0
var elapsed := 0.0

# inventário (cliente: cópia local; servidor: de todos)
var inv := {}
var local_inv := {}
var peer_info := {}             # peer id -> {name, team, class}

# servidor
var built := {}                 # Vector3i -> nome do dono
var built_count := {}
var respawn_at := {}            # nome -> tempo
var pending_class := {}         # nome -> classe
var fire_cd := {}
var veh_seats := {}             # nome do veículo -> Array de nomes
var veh_respawn := {}           # nome do veículo -> tempo
var rockets := {}
var _rocket_id := 1
var _bot_counter := 0
var _state_t := 0.0
var _point_tick := 0.0
var _score_tick := 0.0
var _wave_timer := 3.0
var _wave_alive := false
var _bots_spawned := false
var _t_started := false
var homes := {}                 # nome -> posição fixa de respawn (alvos de treino)
var local_player: Player = null


func _ready() -> void:
	name = "Match"
	finished = false
	infinite_ammo = Game.mode in ["sandbox", "training"]
	unlimited_build = Game.mode == "sandbox"
	_build_world()
	_build_environment()
	fx = Effects.new()
	fx.name = "Effects"
	add_child(fx)
	players_root = Node3D.new()
	players_root.name = "Players"
	add_child(players_root)
	vehicles_root = Node3D.new()
	vehicles_root.name = "Vehicles"
	add_child(vehicles_root)
	rockets_root = Node3D.new()
	rockets_root.name = "Rockets"
	add_child(rockets_root)
	p_spawner = MultiplayerSpawner.new()
	p_spawner.name = "PlayerSpawner"
	add_child(p_spawner)
	p_spawner.spawn_path = NodePath("../Players")
	p_spawner.spawn_function = Callable(self, "_spawn_player")
	v_spawner = MultiplayerSpawner.new()
	v_spawner.name = "VehicleSpawner"
	add_child(v_spawner)
	v_spawner.spawn_path = NodePath("../Vehicles")
	v_spawner.spawn_function = Callable(self, "_spawn_vehicle")
	_build_points()
	var hud := preload("res://scenes/ui/hud.tscn").instantiate()
	hud.name = "HUD"
	hud.ctrl = self
	add_child(hud)
	Net.peer_left.connect(_on_peer_left)
	Net.server_closed.connect(func(): Game.to_menu())
	if multiplayer.is_server():
		_server_start()
	else:
		Net.to_server(self, &"_srv_client_ready", [Settings.player_name, Game.my_team, Game.my_class])
	if not Settings.touch_controls:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _build_world() -> void:
	world = VoxelWorld.new()
	world.name = "World"
	add_child(world)
	TerrainGen.generate(world, Game.map_id, Game.seed_value)
	world.rebuild_budget = 2 if Settings.quality < 2 else 4


func _build_environment() -> void:
	var sky_top := Color(0.35, 0.6, 0.95)
	var sky_hor := Color(0.75, 0.85, 0.95)
	var sun_col := Color(1.0, 0.96, 0.88)
	var sun_rot := Vector3(-55, 35, 0)
	var fog_col := Color(0.7, 0.8, 0.9)
	match Game.map_id:
		"city":
			sky_top = Color(0.45, 0.5, 0.58)
			sky_hor = Color(0.68, 0.7, 0.72)
			sun_col = Color(0.95, 0.92, 0.88)
			fog_col = Color(0.62, 0.64, 0.67)
		"battlefield":
			sky_top = Color(0.35, 0.45, 0.75)
			sky_hor = Color(0.98, 0.7, 0.45)
			sun_col = Color(1.0, 0.8, 0.6)
			sun_rot = Vector3(-24, -60, 0)
			fog_col = Color(0.85, 0.72, 0.6)
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = sky_top
	sky_mat.sky_horizon_color = sky_hor
	sky_mat.ground_horizon_color = sky_hor
	sky_mat.ground_bottom_color = sky_hor.darkened(0.3)
	var sky := Sky.new()
	sky.sky_material = sky_mat
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.55
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = fog_col
	env.fog_density = 0.004 if Settings.quality > 0 else 0.007
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = sun_rot
	sun.light_color = sun_col
	sun.light_energy = 0.85
	sun.shadow_enabled = Settings.shadows
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL if Settings.quality == 0 else DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.directional_shadow_max_distance = 55.0 if Settings.quality < 2 else 90.0
	add_child(sun)


func _process(delta: float) -> void:
	elapsed += delta
	if Game.mode == "sandbox":
		# ciclo de dia/noite lento (iluminação dinâmica)
		var t := fmod(elapsed / 240.0, 1.0)
		sun.rotation_degrees.x = -20.0 - 60.0 * sin(t * PI)
		sun.light_energy = clampf(0.25 + sin(t * PI) * 0.9, 0.25, 1.1)
	if multiplayer.is_server():
		_server_process(delta)
	for pt in points:
		_update_point_visual(pt, delta)


func _unhandled_input(event: InputEvent) -> void:
	if finished:
		return
	if event.is_action_pressed("pause"):
		var hud := get_node_or_null("HUD")
		if hud != null:
			hud.toggle_pause()


# ------------------------------------------------------------------ helpers

func get_player(pname: String) -> Player:
	return players_root.get_node_or_null(pname) as Player


func get_vehicle(vname: String) -> Vehicle:
	return vehicles_root.get_node_or_null(vname) as Vehicle


func all_players() -> Array:
	return players_root.get_children()


func team_has_friendly_fire() -> bool:
	return friendly_fire


func _spawn_player(d: Dictionary) -> Node:
	var p := preload("res://scenes/player/player.tscn").instantiate() as Player
	p.ctrl = self
	p.world = world
	p.setup_data(d)
	if d.get("owner_id", 1) == multiplayer.get_unique_id() and not d.get("bot", false):
		local_player = p
	return p


func _spawn_vehicle(d: Dictionary) -> Node:
	var v := preload("res://scenes/vehicles/vehicle.tscn").instantiate() as Vehicle
	v.ctrl = self
	v.world = world
	v.setup_data(d)
	return v


func spawn_pos_for(team: int) -> Vector3:
	var sp: Array = world.map_info["spawns"][team]
	if sp.is_empty():
		return Vector3(64, 40, 64)
	var s: Vector3 = sp[randi() % sp.size()]
	return s + Vector3(randf_range(-1, 1), 0.2, randf_range(-1, 1))


func spawn_yaw_for(team: int) -> float:
	# vira em direção ao centro do mapa
	var s := world.size_blocks()
	var p := spawn_pos_for(team)
	var d := Vector3(s.x * 0.5, 0, s.z * 0.5) - p
	return atan2(-d.x, -d.z)


func _build_points() -> void:
	points.clear()
	for p in world.map_info["points"]:
		points.append({"pos": p, "owner": -1, "prog": 0.0, "base": false})
	if Game.mode == "capture":
		for b in world.map_info["bases"]:
			points.append({"pos": b["pos"], "owner": b["team"], "prog": -1.0 if b["team"] == 0 else 1.0, "base": true})
	if Game.mode != "capture" and Game.mode != "team_war":
		# nos outros modos os pontos continuam como decoração neutra
		pass
	for pt in points:
		var flag := Node3D.new()
		flag.position = pt["pos"]
		var pole := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(0.2, 6.0, 0.2)
		pole.mesh = bm
		pole.position = Vector3(0, 3.0, 0)
		var pm := StandardMaterial3D.new()
		pm.albedo_color = Color(0.7, 0.7, 0.7)
		pole.material_override = pm
		flag.add_child(pole)
		var cloth := MeshInstance3D.new()
		var cm := BoxMesh.new()
		cm.size = Vector3(1.6, 1.0, 0.1)
		cloth.mesh = cm
		cloth.position = Vector3(0.9, 5.2, 0)
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.8, 0.8, 0.8)
		mat.emission_enabled = true
		mat.emission_energy_multiplier = 0.4
		cloth.material_override = mat
		flag.add_child(cloth)
		add_child(flag)
		pt["node"] = flag
		pt["cloth_mat"] = mat
		pt["cloth"] = cloth


func _update_point_visual(pt: Dictionary, delta: float) -> void:
	var mat: StandardMaterial3D = pt["cloth_mat"]
	var col := Color(0.8, 0.8, 0.8)
	var o: int = pt["owner"]
	if o >= 0:
		col = Game.TEAM_COLORS[o]
	mat.albedo_color = mat.albedo_color.lerp(col, clampf(delta * 5.0, 0.0, 1.0))
	mat.emission = mat.albedo_color
	var cloth: Node3D = pt["cloth"]
	var h := 5.2 - 3.6 * (1.0 - absf(float(pt["prog"])))
	if o < 0:
		h = 5.2 - 3.6 * (1.0 - absf(float(pt["prog"])))
	cloth.position.y = lerpf(cloth.position.y, clampf(h, 1.6, 5.2), clampf(delta * 4.0, 0.0, 1.0))


# ------------------------------------------------------------------ início (servidor)

func _server_start() -> void:
	peer_info[1] = {"name": Settings.player_name, "team": _pick_team(Game.my_team), "class": Game.my_class}
	for v in world.map_info["vehicles"]:
		_spawn_vehicle_server(v["kind"], v["pos"], v["yaw"])
	_spawn_human(1)
	_spawn_mode_entities()
	_t_started = true


func _pick_team(want: int) -> int:
	if Game.mode == "survival":
		return 0
	if Game.mode in ["sandbox", "training"]:
		return clampi(want, 0, 1)
	var c := [0, 0]
	for p in all_players():
		if not (p as Player).is_bot:
			c[(p as Player).team] += 1
	if want >= 0 and c[want] <= c[1 - want]:
		return want
	return 0 if c[0] <= c[1] else 1


func _spawn_vehicle_server(kind: String, pos: Vector3, yaw: float) -> void:
	_bot_counter += 1
	v_spawner.spawn({"name": "veh_%d" % _bot_counter, "vkind": kind, "pos": pos, "yaw": yaw})


func _spawn_human(peer: int) -> void:
	var info: Dictionary = peer_info[peer]
	var team: int = info["team"]
	var nm := str(peer)
	if get_player(nm) != null:
		return
	p_spawner.spawn({"name": nm, "owner_id": peer, "team": team, "class_id": info["class"],
		"display_name": info["name"], "pos": spawn_pos_for(team), "yaw": spawn_yaw_for(team), "bot": false})
	_reset_inventory(nm)


func spawn_bot(team: int, ai_mode: String, label: String, class_id := "", at := Vector3.INF) -> Player:
	_bot_counter += 1
	var nm := "bot_%d" % _bot_counter
	if class_id == "":
		class_id = Game.CLASS_IDS[randi() % Game.CLASS_IDS.size()]
	var pos := spawn_pos_for(team) if at == Vector3.INF else at
	if ai_mode == "dummy":
		homes[nm] = pos
	p_spawner.spawn({"name": nm, "owner_id": 1, "team": team, "class_id": class_id,
		"display_name": label, "pos": pos, "yaw": spawn_yaw_for(team), "bot": true, "ai_mode": ai_mode})
	return get_player(nm)


func _reset_inventory(nm: String) -> void:
	var d := {}
	for m in Blocks.BUILDABLE:
		d[m] = 60
	inv[nm] = d
	_send_inv(nm)


func _send_inv(nm: String) -> void:
	var p := get_player(nm)
	if p == null or p.is_bot:
		return
	if p.owner_id == 1:
		_cl_inv(inv[nm], built_count.get(nm, 0))
	elif Net.online:
		rpc_id(p.owner_id, "_cl_inv", inv[nm], built_count.get(nm, 0))


func _on_peer_left(id: int) -> void:
	if not multiplayer.is_server():
		return
	var nm := str(id)
	var p := get_player(nm)
	if p != null:
		if p.seat_vehicle != "":
			_free_seat(p)
		p.queue_free()
	peer_info.erase(id)
	inv.erase(nm)
	respawn_at.erase(nm)


@rpc("any_peer", "call_remote", "reliable")
func _srv_client_ready(pname: String, team: int, class_id: String) -> void:
	if not multiplayer.is_server():
		return
	var id := Net.sender()
	if id == 1:
		return
	if not Game.CLASSES.has(class_id):
		class_id = "soldier"
	peer_info[id] = {"name": pname.substr(0, 16), "team": _pick_team(team), "class": class_id}
	# envia todas as alterações de blocos feitas até agora
	var keys: Array = world.edits.keys()
	var i := 0
	while i < keys.size():
		var packed := PackedInt32Array()
		for j in range(i, mini(i + SYNC_BATCH, keys.size())):
			var k: Vector3i = keys[j]
			packed.append_array(PackedInt32Array([k.x, k.y, k.z, world.edits[k], 0]))
		rpc_id(id, "_cl_apply_blocks", packed, Vector3.ZERO, 0)
		i += SYNC_BATCH
	_spawn_human(id)
	rpc_id(id, "_cl_state", _state_dict())
	Net.bcast(self, &"_cl_message", [peer_info[id]["name"] + " entrou na partida"])


# ------------------------------------------------------------------ geometria

static func ray_aabb(o: Vector3, d: Vector3, bmin: Vector3, bmax: Vector3) -> float:
	var tmin := 0.0
	var tmax := INF
	for a in 3:
		if absf(d[a]) < 0.000001:
			if o[a] < bmin[a] or o[a] > bmax[a]:
				return -1.0
		else:
			var t1: float = (bmin[a] - o[a]) / d[a]
			var t2: float = (bmax[a] - o[a]) / d[a]
			if t1 > t2:
				var tmp := t1
				t1 = t2
				t2 = tmp
			tmin = maxf(tmin, t1)
			tmax = minf(tmax, t2)
			if tmin > tmax:
				return -1.0
	return tmin


func can_hurt(shooter_team: int, target: Player) -> bool:
	if Game.mode == "sandbox":
		return false
	if shooter_team < 0:
		return true
	return shooter_team != target.team or friendly_fire


## Primeiro jogador/veículo atingido pelo raio dentro de `max_d`.
func _ray_entities(o: Vector3, d: Vector3, max_d: float, shooter: Player) -> Dictionary:
	var best := {}
	var bd := max_d
	var steam := shooter.team if shooter != null else -1
	for n in all_players():
		var p := n as Player
		if p == shooter or not p.alive or p.seat_vehicle != "":
			continue
		if not can_hurt(steam, p):
			continue
		var c := p.global_position
		var t := ray_aabb(o, d, c + Vector3(-0.38, 0.0, -0.38), c + Vector3(0.38, 1.8, 0.38))
		if t >= 0.0 and t < bd:
			bd = t
			best = {"kind": "player", "node": p, "dist": t}
	for n in vehicles_root.get_children():
		var v := n as Vehicle
		if v.dead:
			continue
		if shooter != null and shooter.seat_vehicle == v.name:
			continue
		var inv_t := v.global_transform.affine_inverse()
		var lo := inv_t * o
		var ld := inv_t.basis * d
		var sz: Vector3 = Vehicle.DEFS[v.kind]["size"]
		var t := ray_aabb(lo, ld, Vector3(-sz.x * 0.5, 0.1, -sz.z * 0.5), Vector3(sz.x * 0.5, sz.y + 0.3, sz.z * 0.5))
		if t >= 0.0 and t < bd:
			bd = t
			best = {"kind": "vehicle", "node": v, "dist": t}
	return best


func rocket_hits_entity(pos: Vector3, step: Vector3, shooter_name: String) -> Node3D:
	var shooter := get_player(shooter_name)
	var len := step.length()
	if len < 0.0001:
		return null
	var hit := _ray_entities(pos, step / len, len + 0.3, shooter)
	if hit.is_empty():
		return null
	return hit["node"]


# ------------------------------------------------------------------ tiros

func request_fire(pname: String, wid: String, origin: Vector3, dir: Vector3) -> void:
	Net.to_server(self, &"_srv_fire", [pname, wid, origin, dir])


@rpc("any_peer", "call_remote", "reliable")
func _srv_fire(pname: String, wid: String, origin: Vector3, dir: Vector3) -> void:
	if not multiplayer.is_server() or finished:
		return
	var p := get_player(pname)
	if p == null or not p.alive or p.seat_vehicle != "" or p.owner_id != Net.sender():
		return
	if not (wid in p.weapons):
		return
	var def := WeaponDB.get_def(wid)
	if def["kind"] == "build":
		return
	var now := Time.get_ticks_msec() / 1000.0
	if now < float(fire_cd.get(pname, 0.0)):
		return
	fire_cd[pname] = now + float(def["rate"]) * 0.85
	var eye := p.global_position + Vector3(0, Player.EYE_H, 0)
	if origin.distance_to(eye) > 3.0:
		origin = eye
	dir = dir.normalized()
	if def["kind"] == "projectile":
		_spawn_rocket(origin + dir * 1.0, dir * float(def["speed"]), pname, wid)
		return
	var ends := PackedVector3Array()
	var dead_blocks: Array[Vector3i] = []
	var spread: float = def["spread"]
	for i in int(def["pellets"]):
		var d := dir
		if spread > 0.0:
			d = (dir + Vector3(randf_range(-spread, spread), randf_range(-spread, spread), randf_range(-spread, spread))).normalized()
		var rng: float = def["range"]
		var vhit := world.raycast(origin, d, rng)
		var vdist := float(vhit["dist"]) if not vhit.is_empty() else rng
		var ent := _ray_entities(origin, d, vdist, p)
		if not ent.is_empty():
			var dist: float = ent["dist"]
			ends.append(origin + d * dist)
			if ent["kind"] == "player":
				server_damage((ent["node"] as Node).name, def["damage"], pname, wid)
			else:
				damage_vehicle((ent["node"] as Node).name, def["damage"], pname)
		elif not vhit.is_empty():
			ends.append(origin + d * vdist)
			var cell: Vector3i = vhit["pos"]
			if world.damage_block(cell, def["block_damage"]):
				dead_blocks.append(cell)
		else:
			ends.append(origin + d * rng)
	if not dead_blocks.is_empty():
		_server_remove_blocks(dead_blocks, pname, origin, def["kind"] == "melee")
	if def["kind"] != "melee":
		Net.bcast(self, &"_cl_shot", [pname, wid, origin, ends])
	else:
		Net.bcast(self, &"_cl_shot", [pname, wid, origin, PackedVector3Array()])


func _spawn_rocket(pos: Vector3, vel: Vector3, shooter: String, wid: String) -> void:
	var rid := _rocket_id
	_rocket_id += 1
	Net.bcast(self, &"_cl_spawn_rocket", [rid, pos, vel, shooter, wid])


func request_tank_fire(vname: String, muzzle: Vector3, dir: Vector3) -> void:
	Net.to_server(self, &"_srv_tank_fire", [vname, muzzle, dir])


@rpc("any_peer", "call_remote", "reliable")
func _srv_tank_fire(vname: String, muzzle: Vector3, dir: Vector3) -> void:
	if not multiplayer.is_server() or finished:
		return
	var v := get_vehicle(vname)
	if v == null or v.dead or v.kind != "tank" or v.driver_peer != Net.sender():
		return
	var now := Time.get_ticks_msec() / 1000.0
	if now < float(fire_cd.get(vname, 0.0)):
		return
	fire_cd[vname] = now + float(WeaponDB.TANK_GUN["rate"]) * 0.85
	if muzzle.distance_to(v.global_position) > 7.0:
		muzzle = v.global_position + Vector3(0, 2.0, 0)
	_spawn_rocket(muzzle, dir.normalized() * float(WeaponDB.TANK_GUN["speed"]), str(v.driver_peer), "tank_gun")


# ------------------------------------------------------------------ dano

func server_damage(victim_name: String, amount: float, killer_name: String, weapon: String) -> void:
	var v := get_player(victim_name)
	if v == null or not v.alive or finished:
		return
	v.hp -= amount
	if Game.mode == "training":
		var k := get_player(killer_name)
		if k != null and not k.is_bot and v.ai_mode == "dummy":
			training_hits += 1
	Net.bcast(self, &"_cl_hit", [victim_name, amount, killer_name])
	if v.hp <= 0.0:
		_kill_player(v, killer_name, weapon)


func _kill_player(v: Player, killer_name: String, weapon: String) -> void:
	v.hp = 0.0
	v.alive = false
	v.deaths += 1
	if v.seat_vehicle != "":
		_free_seat(v)
	var k := get_player(killer_name)
	var text := "%s morreu" % v.display_name
	if k != null and k != v:
		k.kills += 1
		text = "%s eliminou %s" % [k.display_name, v.display_name]
		if Game.mode == "team_war" and k.team != v.team:
			team_scores[k.team] += 1
	Net.bcast(self, &"_cl_kill", [text])
	var now := Time.get_ticks_msec() / 1000.0
	if v.ai_mode == "zombie":
		get_tree().create_timer(3.0).timeout.connect(v.queue_free)
		return
	if Game.mode == "survival" and not v.is_bot:
		return
	var delay := 4.0
	if v.ai_mode == "dummy":
		delay = 3.0
	elif v.is_bot:
		delay = 6.0
	elif Game.mode == "sandbox":
		delay = 1.0
	respawn_at[v.name] = now + delay


func _respawn(nm: String) -> void:
	var p := get_player(nm)
	if p == null or p.alive:
		return
	var cls: String = pending_class.get(nm, p.class_id)
	p.class_id = cls
	var pos: Vector3 = homes.get(nm, spawn_pos_for(p.team))
	p.hp = float(Game.CLASSES[cls]["hp"])
	p.alive = true
	Net.bcast(self, &"_cl_teleport", [nm, pos, spawn_yaw_for(p.team), cls])
	if not p.is_bot:
		_reset_inventory(nm)


func damage_vehicle(vname: String, amount: float, killer_name: String) -> void:
	var v := get_vehicle(vname)
	if v == null or v.dead:
		return
	v.hp -= amount
	if v.hp > 0.0:
		return
	v.dead = true
	v.driver_peer = 0
	var seats: Array = veh_seats.get(vname, [])
	for pn in seats:
		if pn != "":
			var p := get_player(pn)
			if p != null:
				_free_seat(p)
				Net.bcast(self, &"_cl_teleport", [pn, v.global_position + Vector3(0, 2.5, 0), p.yaw, ""])
				server_damage(pn, 35.0, killer_name, "explosion")
	veh_seats.erase(vname)
	veh_respawn[vname] = Time.get_ticks_msec() / 1000.0 + 25.0
	Net.bcast(self, &"_cl_explode", [0, v.global_position + Vector3.UP, 4.5])
	for n in all_players():
		var q := n as Player
		if q.alive and q.global_position.distance_to(v.global_position) < 5.0:
			server_damage(q.name, 40.0, killer_name, "explosion")


func server_explosion(rid: int, pos: Vector3, weapon: String, shooter_name: String) -> void:
	var radius: float
	var dmg: float
	var bdmg: float
	if weapon == "tank_gun":
		radius = WeaponDB.TANK_GUN["radius"]
		dmg = WeaponDB.TANK_GUN["damage"]
		bdmg = WeaponDB.TANK_GUN["block_damage"]
	else:
		var def := WeaponDB.get_def(weapon)
		radius = def["radius"]
		dmg = def["damage"]
		bdmg = def["block_damage"]
	var shooter := get_player(shooter_name)
	var steam := shooter.team if shooter != null else -1
	var cells: Array[Vector3i] = []
	var base := Vector3i(floori(pos.x), floori(pos.y), floori(pos.z))
	var ri := int(ceil(radius))
	for dz in range(-ri, ri + 1):
		for dy in range(-ri, ri + 1):
			for dx in range(-ri, ri + 1):
				var cell := base + Vector3i(dx, dy, dz)
				var id := world.get_block(cell)
				if not Blocks.is_destructible(id):
					continue
				var d := (Vector3(cell) + Vector3(0.5, 0.5, 0.5)).distance_to(pos)
				if d > radius:
					continue
				if world.damage_block(cell, bdmg * 4.0 * (1.0 - d / radius)):
					cells.append(cell)
	if not cells.is_empty():
		_server_remove_blocks(cells, shooter_name, pos, false)
	for n in all_players():
		var p := n as Player
		if not p.alive:
			continue
		var d := (p.global_position + Vector3(0, 0.9, 0)).distance_to(pos)
		if d > radius + 0.8:
			continue
		var amount := dmg * (1.0 - d / (radius + 0.8))
		if p.name == shooter_name:
			amount *= 0.5
		elif not can_hurt(steam, p):
			continue
		elif Game.mode == "sandbox":
			continue
		server_damage(p.name, amount, shooter_name, weapon)
	for n in vehicles_root.get_children():
		var v := n as Vehicle
		if v.dead:
			continue
		var d := v.global_position.distance_to(pos)
		if d < radius + 1.5:
			damage_vehicle(v.name, dmg * 1.5 * (1.0 - d / (radius + 1.5)), shooter_name)
	Net.bcast(self, &"_cl_explode", [rid, pos, radius])


const GATHER := {Blocks.STONE: Blocks.STONE, Blocks.WOOD: Blocks.WOOD, Blocks.BRICK: Blocks.BRICK,
	Blocks.PLANK: Blocks.PLANK, Blocks.CONCRETE: Blocks.CONCRETE, Blocks.METAL: Blocks.METAL,
	Blocks.SAND: Blocks.SAND}


## Remove blocos (servidor), detecta desabamento e replica tudo em um único pacote.
func _server_remove_blocks(cells: Array, who: String, from_pos: Vector3, gather: bool) -> void:
	var removed: Array = []
	var packed := PackedInt32Array()
	var gained := {}
	for c in cells:
		var cell: Vector3i = c
		var old := world.get_block(cell)
		if old == Blocks.AIR or not Blocks.is_destructible(old):
			continue
		world.set_block(cell, Blocks.AIR)
		removed.append(cell)
		packed.append_array(PackedInt32Array([cell.x, cell.y, cell.z, 0, old]))
		_untrack_built(cell)
		if gather and GATHER.has(old):
			gained[GATHER[old]] = int(gained.get(GATHER[old], 0)) + 1
	if removed.is_empty():
		return
	var n_broken := removed.size()
	for c in world.find_unsupported(removed):
		var cell: Vector3i = c
		var old := world.get_block(cell)
		if old == Blocks.AIR or not Blocks.is_destructible(old):
			continue
		world.set_block(cell, Blocks.AIR)
		packed.append_array(PackedInt32Array([cell.x, cell.y, cell.z, 0, old]))
		_untrack_built(cell)
	if gather and not gained.is_empty() and inv.has(who):
		for m in gained:
			inv[who][m] = int(inv[who].get(m, 0)) + int(gained[m])
		_send_inv(who)
	Net.bcast(self, &"_cl_apply_blocks", [packed, from_pos, n_broken])


func _untrack_built(cell: Vector3i) -> void:
	if built.has(cell):
		var owner_name: String = built[cell]
		built_count[owner_name] = maxi(int(built_count.get(owner_name, 1)) - 1, 0)
		built.erase(cell)


# ------------------------------------------------------------------ construção

func request_build(pname: String, shape: int, mat: int, cell: Vector3i, yaw: float) -> void:
	Net.to_server(self, &"_srv_build", [pname, shape, mat, cell, yaw])


func request_unbuild(pname: String, pos: Vector3i) -> void:
	Net.to_server(self, &"_srv_unbuild", [pname, pos])


static func yaw_to_dir(yaw: float) -> Vector3i:
	var fx_ := -sin(yaw)
	var fz_ := -cos(yaw)
	if absf(fx_) > absf(fz_):
		return Vector3i(1 if fx_ > 0.0 else -1, 0, 0)
	return Vector3i(0, 0, 1 if fz_ > 0.0 else -1)


func _msg_to(pname: String, text: String) -> void:
	var p := get_player(pname)
	if p == null or p.is_bot:
		return
	if p.owner_id == 1:
		_cl_message(text)
	elif Net.online:
		rpc_id(p.owner_id, "_cl_message", text)


func _shape_cells(shape: int, cell: Vector3i, yaw: float) -> Array:
	var dirv := yaw_to_dir(yaw)
	var side := Vector3i(dirv.z, 0, -dirv.x)
	var out: Array = []
	match shape:
		1:  # parede 3x3
			for h in 3:
				for w in range(-1, 2):
					out.append(cell + side * w + Vector3i(0, h, 0))
		2:  # ponte de 7 blocos
			for i in 7:
				out.append(cell + dirv * i)
		3:  # barricada com ameias
			for h in 2:
				for w in range(-2, 3):
					if h == 1 and w % 2 != 0:
						continue
					out.append(cell + side * w + Vector3i(0, h, 0))
		_:
			out.append(cell)
	return out


@rpc("any_peer", "call_remote", "reliable")
func _srv_build(pname: String, shape: int, mat: int, cell: Vector3i, yaw: float) -> void:
	if not multiplayer.is_server() or finished:
		return
	var p := get_player(pname)
	if p == null or not p.alive or p.owner_id != Net.sender() or not (mat in Blocks.BUILDABLE):
		return
	if "builder" not in p.weapons:
		return
	var cells := _shape_cells(clampi(shape, 0, 3), cell, yaw)
	var valid: Array[Vector3i] = []
	var eye := p.global_position + Vector3(0, Player.EYE_H, 0)
	for c in cells:
		var cc: Vector3i = c
		if not world.in_bounds(cc) or cc.y < 1 or world.get_block(cc) != Blocks.AIR:
			continue
		if (Vector3(cc) + Vector3(0.5, 0.5, 0.5)).distance_to(eye) > 14.0:
			continue
		var blocked := false
		for n in all_players():
			var q := n as Player
			if q.alive and q.seat_vehicle == "":
				var pc := q.global_position
				if absf(cc.x + 0.5 - pc.x) < 0.9 and absf(cc.z + 0.5 - pc.z) < 0.9 and cc.y + 1.0 > pc.y and cc.y < pc.y + 1.8:
					blocked = true
					break
		if not blocked:
			valid.append(cc)
	if valid.is_empty():
		return
	var allowed := valid.size()
	if not unlimited_build:
		allowed = mini(allowed, Game.build_limit - int(built_count.get(pname, 0)))
		if allowed <= 0:
			_msg_to(pname, "Limite de construção atingido (%d blocos)" % Game.build_limit)
			return
		var have := int(inv.get(pname, {}).get(mat, 0))
		if have <= 0:
			_msg_to(pname, "Sem material: %s" % Blocks.NAMES[mat])
			return
		allowed = mini(allowed, have)
	var packed := PackedInt32Array()
	for i in allowed:
		var c: Vector3i = valid[i]
		world.set_block(c, mat)
		packed.append_array(PackedInt32Array([c.x, c.y, c.z, mat, 0]))
		built[c] = pname
	built_count[pname] = int(built_count.get(pname, 0)) + allowed
	if not unlimited_build:
		inv[pname][mat] = int(inv[pname][mat]) - allowed
	_send_inv(pname)
	Net.bcast(self, &"_cl_apply_blocks", [packed, p.global_position, 0])


@rpc("any_peer", "call_remote", "reliable")
func _srv_unbuild(pname: String, pos: Vector3i) -> void:
	if not multiplayer.is_server() or finished:
		return
	var p := get_player(pname)
	if p == null or not p.alive or p.owner_id != Net.sender():
		return
	if (Vector3(pos) + Vector3(0.5, 0.5, 0.5)).distance_to(p.global_position + Vector3(0, 1.5, 0)) > 12.0:
		return
	var id := world.get_block(pos)
	if id == Blocks.AIR or not Blocks.is_destructible(id):
		return
	var owner_name: String = built.get(pos, "")
	if owner_name != pname and not unlimited_build:
		_msg_to(pname, "Só dá para recolher blocos que você construiu (use a picareta)")
		return
	if owner_name == pname and inv.has(pname) and GATHER.has(id):
		inv[pname][id] = int(inv[pname].get(id, 0)) + 1
	_server_remove_blocks([pos], pname, p.global_position, false)
	_send_inv(pname)


# ------------------------------------------------------------------ veículos

func request_enter(pname: String, vname: String) -> void:
	Net.to_server(self, &"_srv_enter", [pname, vname])


func request_exit(pname: String) -> void:
	Net.to_server(self, &"_srv_exit", [pname])


@rpc("any_peer", "call_remote", "reliable")
func _srv_enter(pname: String, vname: String) -> void:
	if not multiplayer.is_server() or finished:
		return
	var p := get_player(pname)
	var v := get_vehicle(vname)
	if p == null or v == null or not p.alive or v.dead or p.seat_vehicle != "" or p.owner_id != Net.sender():
		return
	if p.global_position.distance_to(v.global_position) > 9.0:
		return
	var seats: Array = veh_seats.get(vname, [])
	if seats.is_empty():
		seats.resize(v.seat_count())
		seats.fill("")
	var idx := -1
	for i in seats.size():
		if seats[i] == "" and not (i == 0 and p.is_bot):
			idx = i
			break
	if idx < 0:
		_msg_to(pname, "Veículo lotado")
		return
	seats[idx] = pname
	veh_seats[vname] = seats
	p.seat_vehicle = vname
	p.seat_idx = idx
	if idx == 0:
		v.driver_peer = p.owner_id


func _free_seat(p: Player) -> void:
	var vname := p.seat_vehicle
	if vname == "":
		return
	var seats: Array = veh_seats.get(vname, [])
	if p.seat_idx >= 0 and p.seat_idx < seats.size():
		seats[p.seat_idx] = ""
	var v := get_vehicle(vname)
	if v != null and p.seat_idx == 0:
		v.driver_peer = 0
	p.seat_vehicle = ""
	p.seat_idx = -1


@rpc("any_peer", "call_remote", "reliable")
func _srv_exit(pname: String) -> void:
	if not multiplayer.is_server():
		return
	var p := get_player(pname)
	if p == null or p.seat_vehicle == "" or p.owner_id != Net.sender():
		return
	var v := get_vehicle(p.seat_vehicle)
	var pos := p.global_position + Vector3(0, 0.5, 0)
	if v != null:
		var sz: Vector3 = Vehicle.DEFS[v.kind]["size"]
		var right := v.global_transform.basis.x
		for sgn in [1.0, -1.0]:
			var cand: Vector3 = v.global_position + right * sgn * (sz.x * 0.5 + 1.0)
			var cell := Vector3i(floori(cand.x), floori(v.global_position.y + 0.4), floori(cand.z))
			if world.get_block(cell) == Blocks.AIR and world.get_block(cell + Vector3i.UP) == Blocks.AIR:
				pos = Vector3(cand.x, v.global_position.y + 0.3, cand.z)
				break
	_free_seat(p)
	Net.bcast(self, &"_cl_teleport", [pname, pos, p.yaw, ""])


# ------------------------------------------------------------------ eventos do servidor -> clientes

@rpc("authority", "call_remote", "reliable")
func _cl_apply_blocks(data: PackedInt32Array, from: Vector3, n_broken: int) -> void:
	var count := data.size() / 5
	var shown := 0
	var falling: Array = []
	for k in count:
		var p := Vector3i(data[k * 5], data[k * 5 + 1], data[k * 5 + 2])
		var nid := data[k * 5 + 3]
		var old := data[k * 5 + 4]
		world.set_block(p, nid, false)
		world.edits[p] = nid
		if nid == 0 and old != 0:
			if k < n_broken:
				if shown < 10:
					fx.block_break(Vector3(p), old)
					shown += 1
			else:
				falling.append({"pos": Vector3(p), "id": old})
	if not falling.is_empty():
		fx.debris(falling, from)
	if count > 0 and data[3] == 0 and data[4] != 0:
		Sfx.play("break", from if from != Vector3.ZERO else Vector3.INF)
	elif count > 0 and data[3] != 0:
		Sfx.play("place", Vector3(data[0], data[1], data[2]))


var _tracer_mesh: BoxMesh
var _tracer_mat: StandardMaterial3D


func _tracer(a: Vector3, b: Vector3) -> void:
	var len := a.distance_to(b)
	if len < 0.5:
		return
	if _tracer_mesh == null:
		_tracer_mesh = BoxMesh.new()
		_tracer_mesh.size = Vector3(0.03, 0.03, 1.0)
		_tracer_mat = StandardMaterial3D.new()
		_tracer_mat.albedo_color = Color(1.0, 0.9, 0.5)
		_tracer_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	var mi := MeshInstance3D.new()
	mi.mesh = _tracer_mesh
	mi.material_override = _tracer_mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	mi.global_position = (a + b) * 0.5
	mi.look_at(b, Vector3.UP if absf((b - a).normalized().y) < 0.99 else Vector3.RIGHT)
	mi.scale = Vector3(1, 1, len)
	get_tree().create_timer(0.05).timeout.connect(mi.queue_free)


@rpc("authority", "call_remote", "reliable")
func _cl_shot(pname: String, wid: String, origin: Vector3, ends: PackedVector3Array) -> void:
	var def := WeaponDB.get_def(wid)
	var mine := local_player != null and local_player.name == pname
	if not mine:
		Sfx.play(def["sound"], origin)
		fx.muzzle(origin)
	var start := origin + Vector3(0, -0.15, 0)
	for e in ends:
		_tracer(start, e)
		fx.hit_spark(e)


@rpc("authority", "call_remote", "reliable")
func _cl_hit(victim: String, amount: float, killer: String) -> void:
	if local_player == null:
		return
	if killer == local_player.name and victim != killer:
		hit_marker.emit()
		Sfx.play("hit")
	if victim == local_player.name:
		local_damaged.emit(amount)


@rpc("authority", "call_remote", "reliable")
func _cl_kill(text: String) -> void:
	killfeed.emit(text)


@rpc("authority", "call_remote", "reliable")
func _cl_message(text: String) -> void:
	message.emit(text)


@rpc("authority", "call_remote", "reliable")
func _cl_teleport(pname: String, pos: Vector3, yaw: float, class_id: String) -> void:
	var p := get_player(pname)
	if p == null:
		return
	if class_id != "" and Game.CLASSES.has(class_id):
		p.class_id = class_id
		p.call("_apply_class")
		p.call("_update_held")
	p.teleport(pos, yaw)


@rpc("authority", "call_remote", "reliable")
func _cl_spawn_rocket(rid: int, pos: Vector3, vel: Vector3, shooter: String, wid: String) -> void:
	var r := preload("res://scenes/weapons/rocket.tscn").instantiate() as Rocket
	r.rid = rid
	r.velocity = vel
	r.shooter = shooter
	r.weapon = wid
	r.gravity = 2.0 if wid == "tank_gun" else 4.0
	r.world = world
	r.ctrl = self
	rockets_root.add_child(r)
	r.global_position = pos
	rockets[rid] = r
	Sfx.play("rocket", pos)


@rpc("authority", "call_remote", "reliable")
func _cl_explode(rid: int, pos: Vector3, radius: float) -> void:
	if rockets.has(rid):
		if is_instance_valid(rockets[rid]):
			(rockets[rid] as Node).queue_free()
		rockets.erase(rid)
	fx.explosion(pos, radius)
	if local_player != null:
		var d := local_player.global_position.distance_to(pos)
		if d < radius * 6.0:
			local_player.shake = maxf(local_player.shake, (1.0 - d / (radius * 6.0)) * 0.5)


@rpc("authority", "call_remote", "reliable")
func _cl_inv(d: Dictionary, count: int) -> void:
	local_inv = d
	local_inv["_built"] = count
	state_changed.emit()


func _state_dict() -> Dictionary:
	var pts: Array = []
	for pt in points:
		pts.append([pt["owner"], pt["prog"]])
	return {"scores": team_scores, "wave": wave, "info": wave_info, "hits": training_hits, "pts": pts}


@rpc("authority", "call_remote", "reliable")
func _cl_state(d: Dictionary) -> void:
	team_scores = d["scores"]
	wave = d["wave"]
	wave_info = d["info"]
	training_hits = d["hits"]
	var pts: Array = d["pts"]
	for i in mini(pts.size(), points.size()):
		points[i]["owner"] = pts[i][0]
		points[i]["prog"] = pts[i][1]
	state_changed.emit()


@rpc("authority", "call_remote", "reliable")
func _cl_over(text: String) -> void:
	finished = true
	ui_blocking = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	match_over.emit(text)


func _end_match(text: String) -> void:
	if finished:
		return
	finished = true
	if Net.online:
		rpc("_cl_state", _state_dict())
	Net.bcast(self, &"_cl_over", [text])


# ------------------------------------------------------------------ modos de jogo (servidor)

func _spawn_mode_entities() -> void:
	match Game.mode:
		"team_war", "capture":
			for team in 2:
				for i in Game.bots_per_team:
					spawn_bot(team, "fight", "Bot %s %d" % [Game.TEAM_NAMES[team], i + 1])
		"training":
			var base := spawn_pos_for(0)
			var s := world.size_blocks()
			var toward := Vector3(s.x * 0.5 - base.x, 0, 0).normalized()
			if toward.length() < 0.5:
				toward = Vector3.RIGHT
			var side := Vector3(-toward.z, 0, toward.x)
			for i in 6:
				var d := 14.0 + float(i % 3) * 9.0
				var off := (float(i / 3) - 0.5) * 12.0
				var at := base + toward * d + side * off
				at.y = world.find_ground(int(at.x), int(at.z)) + 0.1
				spawn_bot(1, "dummy", "Alvo %d" % (i + 1), "soldier", at)
		"survival":
			wave = 0
			_wave_alive = false
			_wave_timer = 5.0


func bot_goal(p: Player) -> Vector3:
	var best := Vector3.ZERO
	var bd := INF
	if Game.mode == "capture":
		for pt in points:
			if pt["owner"] == p.team:
				continue
			var d := (pt["pos"] as Vector3).distance_to(p.global_position)
			if d < bd:
				bd = d
				best = pt["pos"]
		if bd < INF:
			return best
	for b in world.map_info["bases"]:
		if b["team"] != p.team:
			return b["pos"]
	return p.global_position


func _server_process(delta: float) -> void:
	if finished or not _t_started:
		return
	var now := Time.get_ticks_msec() / 1000.0
	for nm in respawn_at.keys():
		if now >= float(respawn_at[nm]):
			respawn_at.erase(nm)
			_respawn(nm)
	for vn in veh_respawn.keys():
		if now >= float(veh_respawn[vn]):
			veh_respawn.erase(vn)
			var v := get_vehicle(vn)
			if v != null:
				v.reset_home()
	match Game.mode:
		"team_war":
			for t in 2:
				if team_scores[t] >= WIN_KILLS:
					_end_match("Equipe %s venceu!" % Game.TEAM_NAMES[t])
		"capture":
			_capture_tick(delta)
		"survival":
			_survival_tick(delta)
	_state_t -= delta
	if _state_t <= 0.0:
		_state_t = 0.5
		state_changed.emit()
		if Net.online:
			rpc("_cl_state", _state_dict())


func _capture_tick(delta: float) -> void:
	_point_tick -= delta
	if _point_tick <= 0.0:
		var dt := 0.2 - _point_tick
		_point_tick = 0.2
		for pt in points:
			var c := [0, 0]
			for n in all_players():
				var p := n as Player
				if not p.alive or p.seat_vehicle != "":
					continue
				var dv: Vector3 = p.global_position - (pt["pos"] as Vector3)
				if Vector2(dv.x, dv.z).length() < CAPTURE_RADIUS and absf(dv.y) < 5.0:
					c[p.team] += 1
			var prog: float = pt["prog"]
			if c[0] > 0 and c[1] == 0:
				prog = maxf(prog - dt / 5.0, -1.0)
			elif c[1] > 0 and c[0] == 0:
				prog = minf(prog + dt / 5.0, 1.0)
			pt["prog"] = prog
			var old_owner: int = pt["owner"]
			if prog <= -1.0:
				pt["owner"] = 0
			elif prog >= 1.0:
				pt["owner"] = 1
			if pt["owner"] != old_owner and pt["owner"] >= 0:
				Net.bcast(self, &"_cl_message", ["%s capturaram um ponto!" % Game.TEAM_NAMES[pt["owner"]]])
				Sfx.play("capture")
	_score_tick -= delta
	if _score_tick <= 0.0:
		_score_tick = 2.0
		for pt in points:
			if pt["owner"] >= 0:
				team_scores[pt["owner"]] += 1
		for t in 2:
			if team_scores[t] >= WIN_POINTS:
				_end_match("Equipe %s dominou o território!" % Game.TEAM_NAMES[t])


func _survival_tick(delta: float) -> void:
	var humans := 0
	var humans_alive := 0
	var zombies := 0
	for n in all_players():
		var p := n as Player
		if p.ai_mode == "zombie":
			if p.alive:
				zombies += 1
		elif not p.is_bot:
			humans += 1
			if p.alive:
				humans_alive += 1
	if humans > 0 and humans_alive == 0:
		_end_match("Fim de jogo! Você chegou à onda %d" % wave)
		return
	if not _wave_alive:
		_wave_timer -= delta
		wave_info = "Onda %d em %d s" % [wave + 1, maxi(ceili(_wave_timer), 0)]
		if _wave_timer <= 0.0:
			wave += 1
			_spawn_wave()
			_wave_alive = true
			for n in all_players():
				var p := n as Player
				if not p.is_bot and not p.alive:
					_respawn(p.name)
	else:
		wave_info = "Onda %d — zumbis: %d" % [wave, zombies]
		if zombies == 0:
			_wave_alive = false
			_wave_timer = 8.0
			Net.bcast(self, &"_cl_message", ["Onda %d superada!" % wave])


func _spawn_wave() -> void:
	var count := mini(3 + wave * 2, 22)
	var humans: Array = []
	for n in all_players():
		var p := n as Player
		if not p.is_bot and p.alive:
			humans.append(p)
	var s := world.size_blocks()
	for i in count:
		var pos := Vector3.ZERO
		for attempt in 12:
			var x := randi_range(8, s.x - 9)
			var z := randi_range(8, s.z - 9)
			pos = Vector3(x + 0.5, world.find_ground(x, z) + 0.2, z + 0.5)
			var ok := true
			for h in humans:
				if (h as Player).global_position.distance_to(pos) < 28.0:
					ok = false
			if ok:
				break
		var cls: String = ["soldier", "scout", "heavy"][randi() % 3]
		var z := spawn_bot(1, "zombie", "Zumbi", cls, pos)
		if z != null:
			z.max_hp = 40.0 + wave * 10.0
			z.hp = z.max_hp
	Net.bcast(self, &"_cl_message", ["Onda %d começou!" % wave])


func request_class(pname: String, class_id: String) -> void:
	Net.to_server(self, &"_srv_set_class", [pname, class_id])


@rpc("any_peer", "call_remote", "reliable")
func _srv_set_class(pname: String, class_id: String) -> void:
	if not multiplayer.is_server() or not Game.CLASSES.has(class_id):
		return
	var p := get_player(pname)
	if p == null or p.owner_id != Net.sender():
		return
	pending_class[pname] = class_id
	_msg_to(pname, "Classe %s no próximo respawn" % Game.CLASSES[class_id]["name"])
