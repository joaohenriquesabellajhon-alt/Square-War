extends Node
## Camada de rede (ENetMultiplayerPeer). Modo offline usa OfflineMultiplayerPeer:
## nesse caso o jogador local é o "servidor" (id 1) e todo o código funciona igual.

signal connected
signal connection_failed
signal server_closed
signal peer_joined(id: int)
signal peer_left(id: int)

const DEFAULT_PORT := 24680
const MAX_PLAYERS := 8

var online := false


func _ready() -> void:
	multiplayer.connected_to_server.connect(func(): connected.emit())
	multiplayer.connection_failed.connect(func(): connection_failed.emit())
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(func(id): peer_left.emit(id))
	go_offline()


func host(port: int = DEFAULT_PORT, max_players: int = MAX_PLAYERS) -> Error:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(port, max_players)
	if err != OK:
		return err
	multiplayer.multiplayer_peer = peer
	online = true
	return OK


func join(address: String, port: int = DEFAULT_PORT) -> Error:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(address.strip_edges(), port)
	if err != OK:
		return err
	multiplayer.multiplayer_peer = peer
	online = true
	return OK


func go_offline() -> void:
	if multiplayer.multiplayer_peer != null:
		multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	online = false


func is_server() -> bool:
	return multiplayer.is_server()


func my_id() -> int:
	return multiplayer.get_unique_id()


func local_ips() -> PackedStringArray:
	var out := PackedStringArray()
	for ip in IP.get_local_addresses():
		if ip.count(".") == 3 and not ip.begins_with("127.") and not ip.begins_with("169.254."):
			out.append(ip)
	return out


func _on_server_disconnected() -> void:
	go_offline()
	server_closed.emit()


func _on_peer_connected(id: int) -> void:
	peer_joined.emit(id)
	# Quem entra com a partida em andamento recebe a configuração e carrega o mapa.
	if multiplayer.is_server() and Game.in_match:
		client_load_match.rpc_id(id, Game.map_id, Game.seed_value, Game.mode, Game.bots_per_team, Game.build_limit)


## O host avisa todos os clientes conectados para carregarem a partida.
func start_for_all() -> void:
	for id in multiplayer.get_peers():
		client_load_match.rpc_id(id, Game.map_id, Game.seed_value, Game.mode, Game.bots_per_team, Game.build_limit)


@rpc("authority", "call_remote", "reliable")
func client_load_match(map_id: String, seed_value: int, mode: String, bots: int, limit: int) -> void:
	Game.map_id = map_id
	Game.seed_value = seed_value
	Game.mode = mode
	Game.bots_per_team = bots
	Game.build_limit = limit
	Game.in_match = true
	get_tree().change_scene_to_file("res://scenes/maps/game.tscn")


## Executa `method` no servidor (direto se já formos o servidor / offline).
func to_server(node: Node, method: StringName, args: Array = []) -> void:
	if multiplayer.is_server():
		node.callv(method, args)
	else:
		node.callv(&"rpc_id", [1, method] + args)


## Executa `method` localmente e em todos os clientes (apenas o servidor chama).
func bcast(node: Node, method: StringName, args: Array = []) -> void:
	node.callv(method, args)
	if online and multiplayer.is_server():
		node.callv(&"rpc", [method] + args)


## Id do remetente de um RPC (0 local => servidor).
func sender() -> int:
	var s := multiplayer.get_remote_sender_id()
	return 1 if s == 0 else s
