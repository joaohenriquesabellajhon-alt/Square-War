extends Node
class Runner extends Node:
	func _save(path: String) -> void:
		get_viewport().get_texture().get_image().save_png(path)
		print("salvo ", path)
	func run(out: String) -> void:
		# 1) menu principal e página de nova partida
		var menu: Node = load("res://scenes/main_menu.tscn").instantiate()
		get_tree().root.add_child(menu)
		await get_tree().create_timer(0.6).timeout
		_save(out + "_menu.png")
		menu.call("_refresh_setup_button")
		menu.call("_show", "setup")
		await get_tree().create_timer(0.4).timeout
		_save(out + "_setup.png")
		menu.queue_free()
		# 2) partida com controles de toque + inventário + placar
		Settings.touch_controls = true
		Game.mode = "sandbox"
		Game.map_id = "city"
		Game.seed_value = 4321
		Game.in_match = true
		var scene: Node = load("res://scenes/maps/game.tscn").instantiate()
		get_tree().root.add_child(scene)
		await get_tree().create_timer(3.5).timeout
		var lp: Player = (scene as GameController).local_player
		lp.select_weapon(3)
		lp.pitch = -0.3
		await get_tree().create_timer(0.5).timeout
		_save(out + "_touch_build.png")
		var hud := scene.get_node("HUD")
		hud.toggle_inventory()
		await get_tree().create_timer(0.4).timeout
		_save(out + "_inventory.png")
		hud.toggle_inventory()
		hud.toggle_scoreboard()
		await get_tree().create_timer(0.8).timeout
		_save(out + "_scoreboard.png")
		get_tree().quit()
func _ready() -> void:
	var a := OS.get_cmdline_user_args()
	var r := Runner.new()
	get_tree().root.add_child.call_deferred(r)
	r.ready.connect(func(): r.run(a[0]), CONNECT_ONE_SHOT)
