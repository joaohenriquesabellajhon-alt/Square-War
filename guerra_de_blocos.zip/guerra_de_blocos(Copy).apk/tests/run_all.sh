#!/bin/bash
# Uso: tests/run_all.sh /caminho/para/godot
G=${1:-godot}
cd "$(dirname "$0")/.."
F='mesh_get_surface_count|Parameter "m" is null|^Godot Engine|leaked|cleanup'
echo "### mundo";      $G --headless --path . res://tests/world_test.tscn 2>&1 | grep -vE "$F"
echo "### integração"; $G --headless --path . res://tests/game_test.tscn  2>&1 | grep -vE "$F" | grep -E "FALHA|TOTAL"
echo "### modos";      $G --headless --path . res://tests/modes_test.tscn 2>&1 | grep -vE "$F" | grep -E "FALHA|TOTAL"
echo "### multiplayer"
($G --headless --path . res://tests/mp_test.tscn -- host > /tmp/mp_host.log 2>&1 &)
sleep 2
$G --headless --path . res://tests/mp_test.tscn -- client > /tmp/mp_client.log 2>&1
sleep 8
grep -hE "FALHA|TOTAL|ERROR" /tmp/mp_host.log /tmp/mp_client.log | grep -vE "$F"
