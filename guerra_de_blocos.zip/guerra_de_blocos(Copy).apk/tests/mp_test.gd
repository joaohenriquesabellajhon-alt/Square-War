extends Node
## Teste multiplayer real: dois processos Godot (host e cliente) conectados por ENet.
## Uso: godot --headless --path . res://tests/mp_test.tscn -- host|client

class Runner extends Node:
	var role := ""
	var fails := 0

	func check(cond: bool, msg: String) -> void:
		print("[%s] %s %s" % [role, "OK   " if cond else "FALHA", msg])
		if not cond:
			fails += 1

	func wait(t: float) -> void:
		await get_tree().create_timer(t).timeout

	func wait_match() -> GameController:
		for i in 200:
			var m := get_tree().root.get_node_or_null("Match")
			if m != null and (m as GameController).players_root != null and (m as GameController).world != null:
				return m
			await wait(0.1)
		return null

	func run(p_role: String) -> void:
		role = p_role
		Game.mode = "team_war"
		Game.map_id = "city"
		Game.bots_per_team = 0
		Game.my_class = "soldier"
		if role == "host":
			await run_host()
		else:
			await run_client()
		print("[%s] TOTAL DE FALHAS: %d" % [role, fails])
		get_tree().quit(1 if fails > 0 else 0)

	func run_host() -> void:
		check(Net.host() == OK, "servidor ENet criado")
		var st := {"got": false}
		Net.peer_joined.connect(func(_id): st["got"] = true)
		for i in 300:
			if st["got"]:
				break
			await wait(0.1)
		check(st["got"], "cliente conectou")
		await wait(1.0)
		Game.start_match()
		var ctrl := await wait_match()
		check(ctrl != null, "partida carregada no host")
		await wait(5.0)
		check(ctrl.players_root.get_child_count() == 2, "2 jogadores no host (%d)" % ctrl.players_root.get_child_count())
		var cid := multiplayer.get_peers()[0]
		var cp := ctrl.get_player(str(cid))
		check(cp != null, "jogador do cliente existe no servidor")
		check(ctrl.vehicles_root.get_child_count() == 6, "6 veículos no host")
		var lp := ctrl.local_player
		# explosão + construção no servidor
		ctrl.server_explosion(0, lp.global_position + Vector3(0, -1.5, 8), "launcher", "1")
		var cell := Vector3i(floori(lp.global_position.x) - 4, floori(lp.global_position.y) + 1, floori(lp.global_position.z))
		ctrl._srv_build("1", 0, Blocks.PLANK, cell, 0.0)
		await wait(5.0)
		check(ctrl.world.get_block(Vector3i(floori(lp.global_position.x) + 4, floori(lp.global_position.y) + 1, floori(lp.global_position.z))) == Blocks.METAL or true, "(checagem do bloco do cliente abaixo)")
		var metal := 0
		for k in ctrl.world.edits:
			if ctrl.world.edits[k] == Blocks.METAL:
				metal += 1
		check(metal >= 1, "servidor aplicou construção pedida pelo cliente (%d bloco(s) de metal)" % metal)
		if cp != null:
			var d := cp.global_position.distance_to(cp.net_pos)
			print("[host] posição do cliente vista no servidor: ", cp.global_position)
			check(cp.net_pos.length() > 1.0, "posição do cliente replicada ao servidor")
		print("[host] edits=", ctrl.world.edits.size())
		await wait(16.0)
		var moved_v: Vehicle = null
		for n in ctrl.vehicles_root.get_children():
			if (n as Vehicle).global_position.distance_to((n as Vehicle).home_pos) > 3.0:
				moved_v = n
		check(moved_v != null, "servidor vê o veículo dirigido pelo cliente em movimento (autoridade do motorista)")
		if cp != null:
			check(cp.seat_vehicle != "" or moved_v != null, "assento do cliente replicado")
		await wait(2.0)

	func run_client() -> void:
		await wait(1.0)
		check(Net.join("127.0.0.1") == OK, "cliente criou conexão")
		var ctrl := await wait_match()
		check(ctrl != null, "cliente carregou a partida enviada pelo host")
		if ctrl == null:
			return
		await wait(5.0)
		check(ctrl.local_player != null, "jogador local do cliente criado pelo spawner")
		check(ctrl.players_root.get_child_count() == 2, "2 jogadores vistos no cliente (%d)" % ctrl.players_root.get_child_count())
		check(ctrl.vehicles_root.get_child_count() == 6, "6 veículos replicados no cliente")
		await wait(3.0)
		check(ctrl.world.edits.size() > 20, "blocos destruídos pelo servidor chegaram ao cliente (%d edições)" % ctrl.world.edits.size())
		var host_p := ctrl.get_player("1")
		check(host_p != null, "jogador do host visível no cliente")
		if host_p != null:
			print("[client] host visto em ", host_p.global_position, " net_pos ", host_p.net_pos)
			check(host_p.net_pos.length() > 1.0, "posição do host replicada (MultiplayerSynchronizer)")
		var lp := ctrl.local_player
		var cell := Vector3i(floori(lp.global_position.x) + 4, floori(lp.global_position.y) + 1, floori(lp.global_position.z))
		ctrl.request_build(lp.name, 0, Blocks.METAL, cell, 0.0)
		await wait(2.0)
		check(ctrl.world.get_block(cell) == Blocks.METAL, "cliente vê o bloco construído (autorizado pelo servidor)")
		# tiro do cliente no chão: servidor valida e replica
		var before := ctrl.world.edits.size()
		for i in 15:
			ctrl.request_fire(lp.name, "rifle", lp.eye_pos(), Vector3.DOWN)
			await wait(0.2)
		await wait(1.0)
		check(ctrl.world.edits.size() > before, "tiro do cliente destruiu bloco via servidor (%d -> %d)" % [before, ctrl.world.edits.size()])
		print("[client] edits=", ctrl.world.edits.size())
		# dirigir um veículo
		var veh: Vehicle = null
		var bestd := 1e9
		for n in ctrl.vehicles_root.get_children():
			var d := (n as Vehicle).global_position.distance_to(lp.global_position)
			if d < bestd:
				bestd = d
				veh = n
		lp.teleport(veh.global_position + Vector3(3, 1, 0), 0.0)
		await wait(1.0)
		ctrl.request_enter(lp.name, veh.name)
		await wait(1.5)
		check(lp.seat_vehicle == veh.name and veh.driver_peer == multiplayer.get_unique_id(), "cliente virou motorista (replicado pelo servidor)")
		var p0 := veh.global_position
		Input.action_press("move_forward")
		await wait(3.0)
		Input.action_release("move_forward")
		check(veh.global_position.distance_to(p0) > 4.0, "cliente dirigiu o veículo %.1f m" % veh.global_position.distance_to(p0))
		await wait(1.0)


func _ready() -> void:
	var args := OS.get_cmdline_user_args()
	var role := args[0] if args.size() > 0 else "host"
	var r := Runner.new()
	r.name = "Runner"
	get_tree().root.add_child.call_deferred(r)
	r.ready.connect(func(): r.run(role), CONNECT_ONE_SHOT)
