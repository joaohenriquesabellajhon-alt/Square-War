extends Node
## Testa a lógica dos modos: captura de ponto, ondas de sobrevivência, fim de partida e treino.
var fails := 0
func check(c: bool, m: String) -> void:
	print(("  OK   " if c else "  FALHA ") + m)
	if not c: fails += 1

func start(mode: String, map_id: String) -> GameController:
	Game.mode = mode; Game.map_id = map_id; Game.seed_value = 99; Game.bots_per_team = 0; Game.in_match = true
	var s: Node = load("res://scenes/maps/game.tscn").instantiate()
	add_child(s)
	await get_tree().create_timer(2.0).timeout
	return s as GameController

func zombies(c: GameController) -> Array:
	var out := []
	for n in c.all_players():
		if (n as Player).ai_mode == "zombie" and (n as Player).alive: out.append(n)
	return out

func _ready() -> void:
	await get_tree().process_frame
	print("== captura de território")
	var c := await start("capture", "battlefield")
	var pt: Dictionary = c.points[0]
	c.local_player.teleport(pt["pos"] + Vector3(2, 0.3, 2), 0.0)
	await get_tree().create_timer(7.0).timeout
	check(pt["owner"] == 0, "ponto capturado pela equipe do jogador (owner=%d prog=%.2f)" % [pt["owner"], pt["prog"]])
	check(c.team_scores[0] > 0, "pontuação sobe por ponto dominado (%d)" % c.team_scores[0])
	c.team_scores[0] = GameController.WIN_POINTS
	await get_tree().create_timer(2.5).timeout
	check(c.finished, "partida termina ao atingir a meta de pontos")
	c.queue_free(); await get_tree().process_frame

	print("== guerra de equipes: fim por abates")
	c = await start("team_war", "city")
	c.team_scores[1] = GameController.WIN_KILLS
	await get_tree().create_timer(1.0).timeout
	check(c.finished, "fim de partida ao atingir %d abates" % GameController.WIN_KILLS)
	c.queue_free(); await get_tree().process_frame

	print("== sobrevivência")
	c = await start("survival", "battlefield")
	await get_tree().create_timer(6.0).timeout
	check(c.wave == 1, "onda 1 iniciou (wave=%d)" % c.wave)
	var z := zombies(c)
	check(z.size() == 5, "5 zumbis na onda 1 (%d)" % z.size())
	await get_tree().create_timer(4.0).timeout
	var moved := 0
	for n in zombies(c):
		if c.local_player.global_position.distance_to(n.global_position) < 80.0: moved += 1
	print("  zumbis a menos de 80 m do jogador: ", moved)
	for n in z: c.server_damage(n.name, 9999.0, c.local_player.name, "rifle")
	await get_tree().create_timer(1.0).timeout
	check(zombies(c).size() == 0, "zumbis eliminados")
	check(c.local_player.kills == 5, "abates contados (%d)" % c.local_player.kills)
	await get_tree().create_timer(9.0).timeout
	check(c.wave == 2, "onda 2 iniciou após limpar a onda 1 (wave=%d)" % c.wave)
	c.server_damage(c.local_player.name, 9999.0, "", "void")
	await get_tree().create_timer(1.0).timeout
	check(c.finished, "fim de jogo quando todos os jogadores caem")
	c.queue_free(); await get_tree().process_frame

	print("== treinamento")
	c = await start("training", "mountain")
	var dummy: Player = null
	for n in c.all_players():
		if (n as Player).ai_mode == "dummy": dummy = n
	check(dummy != null, "alvos de treino criados")
	var hp0 := dummy.hp
	c.server_damage(dummy.name, 30.0, c.local_player.name, "rifle")
	check(c.training_hits == 1 and dummy.hp == hp0 - 30.0, "acerto contabilizado (hits=%d)" % c.training_hits)
	c.server_damage(dummy.name, 9999.0, c.local_player.name, "rifle")
	check(not dummy.alive, "alvo derrubado")
	var home: Vector3 = c.homes[dummy.name]
	await get_tree().create_timer(4.5).timeout
	check(dummy.alive and dummy.global_position.distance_to(home) < 2.0, "alvo reaparece no mesmo lugar")
	c.queue_free(); await get_tree().process_frame

	print("== sandbox: sem dano entre jogadores")
	c = await start("sandbox", "city")
	check(c.infinite_ammo and c.unlimited_build, "munição e construção ilimitadas")
	print("TOTAL DE FALHAS: ", fails)
	get_tree().quit(1 if fails > 0 else 0)
