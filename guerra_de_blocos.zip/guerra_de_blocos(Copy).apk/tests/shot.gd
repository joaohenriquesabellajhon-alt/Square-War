extends Node
## Captura de tela para inspeção visual (precisa de renderizador: xvfb + opengl3).
class Runner extends Node:
	func run(map_id: String, mode: String, out: String) -> void:
		Game.mode = mode
		Game.map_id = map_id
		Game.seed_value = 4321
		Game.bots_per_team = 3
		Game.in_match = true
		var scene: Node = load("res://scenes/maps/game.tscn").instantiate()
		get_tree().root.add_child(scene)
		var ctrl := scene as GameController
		await get_tree().create_timer(4.0).timeout
		var lp := ctrl.local_player
		# visão do jogador
		lp.pitch = -0.15
		await get_tree().create_timer(0.7).timeout
		_save(out + "_player.png")
		# visão geral (câmera aérea sobre a base do time 0)
		var cam := Camera3D.new()
		cam.far = 500.0
		scene.add_child(cam)
		var base: Vector3 = ctrl.world.map_info["bases"][0]["pos"]
		cam.global_position = base + Vector3(38, 30, 20)
		cam.look_at(base + Vector3(10, 0, 0), Vector3.UP)
		cam.make_current()
		await get_tree().create_timer(1.0).timeout
		_save(out + "_overview.png")
		# explosão para ver partículas
		var pos := base + Vector3(18, 2, 0)
		ctrl.server_explosion(0, pos, "launcher", "1")
		await get_tree().create_timer(0.25).timeout
		_save(out + "_explosion.png")
		get_tree().quit()

	func _save(path: String) -> void:
		var img := get_viewport().get_texture().get_image()
		img.save_png(path)
		print("salvo ", path, " ", img.get_size())

func _ready() -> void:
	var a := OS.get_cmdline_user_args()
	var r := Runner.new()
	get_tree().root.add_child.call_deferred(r)
	r.ready.connect(func(): r.run(a[0], a[1], a[2]), CONNECT_ONE_SHOT)
