extends Node
## Teste automatizado headless: gera os 3 mapas, testa raycast, dano, desabamento e colisão.
func _ready() -> void:
	var ok := true
	for m in TerrainGen.MAP_IDS:
		var w := VoxelWorld.new()
		add_child(w)
		var t0 := Time.get_ticks_msec()
		TerrainGen.generate(w, m, 777)
		var dt := Time.get_ticks_msec() - t0
		var solid := 0
		for c in w.chunks.values():
			if not c.empty: solid += 1
		print("[", m, "] gerado em ", dt, " ms; chunks não vazios: ", solid, "/", w.chunks.size(),
			"; bases=", w.map_info["bases"].size(), " pontos=", w.map_info["points"].size(),
			" veículos=", w.map_info["vehicles"].size())
		# raycast de cima para baixo no meio do mapa
		var s := w.size_blocks()
		var hit := w.raycast(Vector3(s.x / 2 + 0.5, s.y - 1, s.z / 2 + 0.5), Vector3.DOWN, 200.0)
		print("   raycast: ", hit)
		if hit.is_empty(): ok = false
		# dano e remoção
		var p: Vector3i = hit["pos"]
		var n := 0
		while not w.damage_block(p, 2.0) and n < 50: n += 1
		print("   golpes para quebrar bloco ", Blocks.NAMES[hit["id"]], ": ", n + 1)
		w.set_block(p, Blocks.AIR)
		if w.get_block(p) != Blocks.AIR: ok = false
		w.queue_free()
	# teste de desabamento: pilar flutuante
	var w2 := VoxelWorld.new()
	add_child(w2)
	TerrainGen.generate(w2, "battlefield", 5)
	var base := Vector3i(100, 40, 100)
	for y in 4:
		w2.set_block_raw(base + Vector3i(0, y, 0), Blocks.BRICK)
	var un := w2.find_unsupported([base + Vector3i(0, -1, 0)])
	print("[colapso] bloco flutuante detectado: ", un.size(), " (esperado 4)")
	if un.size() != 4: ok = false
	print("RESULTADO: ", "OK" if ok else "FALHOU")
	get_tree().quit(0 if ok else 1)
