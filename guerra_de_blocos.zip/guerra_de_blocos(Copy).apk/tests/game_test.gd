extends Node
## Teste de integração headless: roda uma partida offline e exercita os sistemas.
var fails := 0

func check(cond: bool, msg: String) -> void:
	print(("  OK   " if cond else "  FALHA ") + msg)
	if not cond:
		fails += 1

func run_mode(mode: String, map_id: String) -> void:
	print("== modo=%s mapa=%s" % [mode, map_id])
	Game.mode = mode
	Game.map_id = map_id
	Game.seed_value = 4321
	Game.bots_per_team = 2
	Game.in_match = true
	var scene: Node = load("res://scenes/maps/game.tscn").instantiate()
	add_child(scene)
	var ctrl := scene as GameController
	await get_tree().create_timer(2.5).timeout
	var lp := ctrl.local_player
	check(lp != null, "jogador local criado")
	if lp == null:
		scene.queue_free()
		return
	check(lp.is_on_floor(), "jogador pousou no chão (y=%.2f)" % lp.global_position.y)
	check(lp.global_position.y > 2.0, "jogador não atravessou o mapa")
	check(ctrl.vehicles_root.get_child_count() == 6, "6 veículos criados (%d)" % ctrl.vehicles_root.get_child_count())
	var n_players := ctrl.players_root.get_child_count()
	print("  jogadores+bots: ", n_players)
	if mode in ["team_war", "capture"]:
		check(n_players == 1 + 4, "bots criados (%d)" % n_players)
	if mode == "training":
		check(n_players == 7, "6 alvos + jogador (%d)" % n_players)
	# --- tiro em bloco
	var origin := lp.eye_pos()
	var hit := ctrl.world.raycast(origin, Vector3.DOWN, 5.0)
	check(not hit.is_empty(), "raycast para baixo acerta o chão")
	var cell: Vector3i = hit["pos"]
	var before := ctrl.world.get_block(cell)
	for i in 12:
		ctrl.fire_cd.clear()
		ctrl._srv_fire(lp.name, "rifle", origin, Vector3.DOWN)
	check(ctrl.world.get_block(cell) == Blocks.AIR, "tiros quebraram o bloco %s" % Blocks.NAMES[before])
	# --- construção
	lp.select_weapon(3)
	var bp := Vector3i(floori(lp.global_position.x) + 3, floori(lp.global_position.y) + 1, floori(lp.global_position.z))
	ctrl._srv_build(lp.name, 1, Blocks.PLANK, bp, 0.0)
	var planks: Array[Vector3i] = []
	for pcell in ctrl.built.keys():
		planks.append(pcell)
	check(planks.size() >= 1 and ctrl.world.get_block(planks[0]) == Blocks.PLANK, "parede construída (%d blocos)" % planks.size())
	bp = planks[0]
	check(int(ctrl.built_count.get(lp.name, 0)) > 0, "limite de construção contabilizado (%d)" % int(ctrl.built_count.get(lp.name, 0)))
	var mats_after := int(ctrl.inv[lp.name][Blocks.PLANK])
	check(mats_after < 60 or ctrl.unlimited_build, "material consumido (%d)" % mats_after)
	ctrl._srv_unbuild(lp.name, bp)
	check(ctrl.world.get_block(bp) == Blocks.AIR, "bloco recolhido")
	# --- explosão + desabamento
	var tpos := lp.global_position + Vector3(0, 6, 6)
	var floaty := Vector3i(floori(tpos.x), floori(tpos.y) + 10, floori(tpos.z))
	for y in 3:
		ctrl.world.set_block(floaty + Vector3i(0, y, 0), Blocks.BRICK)
	ctrl.world.edits.clear()
	var wall_base := floaty + Vector3i(0, -1, 0)
	ctrl.world.set_block(wall_base, Blocks.BRICK)
	ctrl._server_remove_blocks([wall_base], lp.name, tpos, false)
	check(ctrl.world.get_block(floaty) == Blocks.AIR, "estrutura flutuante desabou")
	var edits_before := ctrl.world.edits.size()
	ctrl.server_explosion(0, lp.global_position + Vector3(0, -1.5, 8), "launcher", lp.name)
	check(ctrl.world.edits.size() > edits_before, "explosão removeu blocos (%d edições)" % ctrl.world.edits.size())
	# --- veículo
	var v: Vehicle = ctrl.vehicles_root.get_child(0)
	lp.teleport(v.global_position + Vector3(3, 1, 0), 0.0)
	await get_tree().create_timer(0.5).timeout
	ctrl._srv_enter(lp.name, v.name)
	check(lp.seat_vehicle == v.name and lp.seat_idx == 0, "entrou no veículo como motorista")
	var p0 := v.global_position
	Input.action_press("move_forward")   # o jogador sentado repassa a entrada ao veículo
	for i in 90:
		await get_tree().physics_frame
	Input.action_release("move_forward")
	check(v.global_position.distance_to(p0) > 4.0, "veículo andou %.1f m" % v.global_position.distance_to(p0))
	ctrl._srv_exit(lp.name)
	check(lp.seat_vehicle == "", "saiu do veículo")
	# --- dano em jogador / respawn
	var bot: Player = null
	for n in ctrl.all_players():
		if n != lp:
			bot = n
			break
	if bot != null:
		ctrl.server_damage(bot.name, 9999.0, lp.name, "rifle")
		check(not bot.alive, "bot eliminado")
		check(lp.kills == 1 or mode == "sandbox", "abate contabilizado")
	if mode in ["team_war", "capture"]:
		await get_tree().create_timer(8.0).timeout
		if bot != null and is_instance_valid(bot):
			check(bot.alive, "bot reapareceu")
		var moved := false
		for n in ctrl.all_players():
			if n is Player and n != lp and n.global_position.distance_to(ctrl.spawn_pos_for(n.team)) > 3.0:
				moved = true
		check(moved, "bots se movimentaram")
	scene.queue_free()
	await get_tree().process_frame


func _ready() -> void:
	await get_tree().process_frame
	await run_mode("team_war", "city")
	await run_mode("capture", "battlefield")
	await run_mode("sandbox", "mountain")
	await run_mode("training", "city")
	await run_mode("survival", "battlefield")
	print("TOTAL DE FALHAS: ", fails)
	get_tree().quit(1 if fails > 0 else 0)
